#include "Test.h"
#include<string>
#include<vector>
#pragma warning(disable:4996)
Test::Test()
{
}

Test::~Test()
{
}
int Test::getDimension()
{
	return dimension;
}

double Test::getR()
{
	return R;
}

int Test::getK()
{
	return K;
}

int Test::getWindowSize()
{
	return windowSize;
}

int Test::getInFlow()
{
	return inFlow;
}

int Test::getOutFlow()
{
	return outFlow;
}

int Test::getQueryCycle()
{
	return queryCycle;
}

void Test::setDimension(int d)
{
	dimension = d;
}

void Test::setR(double r)
{
	R = r;
}

void Test::setK(int k)
{
	K = k;
}

void Test::setWindowSize(int w)
{
	windowSize = w;
}

void Test::setInFlow(int in)
{
	inFlow = in;
}

void Test::setOutFlow(int out)
{
	outFlow = out;
}

void Test::setQueryCycle(int c)
{
	queryCycle = c;
}


void Test::Init(vector<Test>& vecTestFile, int j)
{
	FILE* fp;
	string a = to_string(j);
	string s = "test" + a + ".txt";
	fp = fopen(s.data(), "r");
	double n;
	int i = 0;
	Test test;
	while (fscanf(fp, "%lf", &n) != EOF)
	{
		if (i % 6 == 0)
		{
			test.setDimension((int)n);
		}
		if (i % 6 == 1)
		{
			test.setR(n);
		}
		if (i % 6 == 2)
		{
			test.setK((int)n);
		}
		if (i % 6 == 3)
		{
			test.setWindowSize((int)n);
		}
		if (i % 6 == 4)
		{
			test.setInFlow((int)n);
		}
		if (i % 6 == 5)
		{
			test.setQueryCycle((int)n);
		}
		i++;
		if (i % 6 == 0 && i != 0)
		{
			test.setOutFlow(test.getInFlow());
			vecTestFile.push_back(test);
		}
	}
}