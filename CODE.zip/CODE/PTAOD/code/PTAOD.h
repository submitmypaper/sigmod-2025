#include <vector>
#include <list>
#include <queue>
#include <map>
#include <cassert>
#include <math.h>
#include <algorithm>
#include "Tstream.h"
#include "Test.h"
#include<stack>
#include <unordered_map>
#include<set>
#include<unordered_set>
typedef vector<double> Data;
class PTAOD {
public:
	struct Node {
		long addr = -1;
		list<int> dataList;
		unordered_map<long, Node*> childList;
		int NodeId;
		Node* parentNode = nullptr;
		vector<double> vecLeftDown;
		vector<double> vecRightUp;
		double sideLength;
		int height = 0;
	};
	struct dataObj {
		int id;
		vector<int> vecNeighborSlide;
		int dataSlideId = 0;
		bool dataState = false;
		int vecNeighborNum = 0;
		int AllNeighborNum = 0;
		list<int> temlist;
	};
	struct Slide {
		int slideId;
		list<dataObj*> warningTimeDataObj;
	};
	struct dataK{
		int dataId;
		double KR = DBL_MAX;
		multimap<double, int> neighbor;
	};
	PTAOD();
	~PTAOD();
	void setTreeSplitDataObjNum(int num);
	double calculateDistanceById(Tstream& tstream, Test& test, int id1, int id2);
	double calculateDistanceByCoordinate(Tstream& tstream, Test& test, int id, Data data);
	double calculateDistanceBetweenTwoData(Tstream& tstream, Test& test, Data data1, Data data2);
	void Init(Tstream& Tstream, Test& test);
	void setQD_TreeInfo(Tstream& Tstream, Test& test);
	void setSlideInfo(Tstream& Tstream, Test& test);
	void addDataObjToQD_Tree(Tstream& Tstream, Test& test);
	void splitQD_Tree(Tstream& Tstream, Test& test, Node* splitNode);
	long findAddrForData(Tstream& Tstream, Test& test, Node* node, int dataId, vector<int>& vecAddr);
	long findAddr(Tstream& Tstream, Test& test, vector<int>& vecAddr);
	void findChildNode(Tstream& Tstream, Test& test, long addr, Node* parentNode, int dataId, vector<int>& vecAddr);
	void findOutlier(Tstream& Tstream, Test& test);
	void findNeighborForDataObj(Tstream& Tstream, Test& test, dataObj* data, Node* curNode);
	void findNeighborForDataObj(Tstream& Tstream, Test& test, dataObj* data);
	double getMinDisToNode(Tstream& Tstream, Test& test, int dataId, Node* node);
	void dealDataObj(Tstream& Tstream, Test& test, dataObj* data);
	void cropVecNeighborSlide(Tstream& Tstream, Test& test, dataObj* data);
	void Update(Tstream& Tstream, Test& test);
	void addNewObjToTree(Tstream& Tstream, Test& test, int newObjId);
	void createNewChildNode(Tstream& Tstream, Test& test, long addr, Node* parentNode, int newObjId, vector<int>& vecAddr, Node*& chooseNode);
	void dealNeedCheckSplitNode(Tstream& Tstream, Test& test);
	void reFindObjInNode(Tstream& Tstream, Test& test, int objId, Node* node, Node*& targetNode);
	void deleteExpireObj(Tstream& Tstream, Test& test, list<int>& list);
	void splitTree(Tstream& Tstream, Test& test, Node* splitNode, Node*& chooseNode, int targetObjId);
	void UpdateFindChildNode(Tstream& Tstream, Test& test, long addr, Node* parentNode, int dataId, vector<int>& vecAddr, Node*& chooseNode, int targetObjId);
	void findNeighborForNewDataObj(Tstream& Tstream, Test& test);
	void updateFindNeighborForDataObj(Tstream& Tstream, Test& test, dataObj* data, Node* curNode);
	void dealOldSlide(Tstream& Tstream, Test& test, Slide& oldSlide);
	int calExpireSlideNum(Tstream& Tstream, Test& test, dataObj* data);
	void updateDataObjVecSlideNeighbor(Tstream& Tstream, Test& test, dataObj* data, unsigned short temNewNeighborNum);
	void reFindNeighborForWarningDataObj(Tstream& Tstream, Test& test, dataObj* data);
	void deleteEmptyNode(Tstream& Tstream, Test& test);
	void updateNodeInfo(Tstream& Tstream, Test& test);
	void changeRRRRR(Tstream& Tstream, Test& test);
	double findKNN(Tstream& Tstream, Test& test, int dataId);
	void calculateMemoryUsage(Tstream& tstream, Test& test, const int num);
	void addPreNeighborToMemoryUsage(Tstream& tstream, Test& test, dataObj* data);
	void checkExpireObj(Tstream& tstream, Test& test);
private:
	int treeSplitDataObjNum = 0;
	int NodeIdCount = 0;
	int SlideIdCount = 0;
	Node* QDTreeRoot = nullptr;
	vector<Slide> slideVec;
	list<pair<int, Node*>> needCheckSplitNode;
	list<pair<int, Node*>> needFindNeighborDataObj;
	list<int> outlierList;
	int outlierNum = 0;
	size_t totalMemoryUsage = 0;
};