#include "PTAOD.h"
#include<fstream>
#define DeterminThreshold 0.25
PTAOD::PTAOD()
{
}

PTAOD::~PTAOD()
{
}

void PTAOD::setTreeSplitDataObjNum(int num)
{
	treeSplitDataObjNum = num;
}

double PTAOD::calculateDistanceById(Tstream& tstream, Test& test, int id1, int id2)
{
	int dimension = test.getDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(tstream.getDataStream(id1 * dimension + i) - tstream.getDataStream(id2 * dimension + i), 2);
	}
	return sqrt(dis);
}

double PTAOD::calculateDistanceByCoordinate(Tstream& tstream, Test& test, int id, Data data)
{
	int dimension = test.getDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(tstream.getDataStream(id * dimension + i) - data[i], 2);
	}
	return sqrt(dis);
}

double PTAOD::calculateDistanceBetweenTwoData(Tstream& tstream, Test& test, Data data1, Data data2)
{
	int dimension = test.getDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(data1[i] - data2[i], 2);
	}
	return sqrt(dis);
}

void PTAOD::Init(Tstream& Tstream, Test& test)
{
	setQD_TreeInfo(Tstream, test);
	setSlideInfo(Tstream, test);
	addDataObjToQD_Tree(Tstream, test);
	findOutlier(Tstream, test);
}

void PTAOD::setQD_TreeInfo(Tstream& Tstream, Test& test)
{
	double side = Tstream.getmaxSide();
	QDTreeRoot = new Node;
	int dimension = test.getDimension();
	QDTreeRoot->height = 0;
	QDTreeRoot->NodeId = NodeIdCount++;
	for (int i = 0; i < dimension; ++i) {
		QDTreeRoot->vecLeftDown.push_back(Tstream.getEveryDimensionMinAndMax(i, 0));
		QDTreeRoot->vecRightUp.push_back(Tstream.getEveryDimensionMinAndMax(i, 0) + side);
	}
	QDTreeRoot->sideLength = side;

}

void PTAOD::setSlideInfo(Tstream& Tstream, Test& test)
{
	int slideNum = test.getWindowSize();
	slideVec.resize(slideNum);
	for (int i = 0; i < slideNum; ++i) {
		Slide slide;
		slide.slideId = SlideIdCount++;
		slideVec[i] = slide;
	}
}

void PTAOD::addDataObjToQD_Tree(Tstream& Tstream, Test& test)
{
	int dataNum = test.getWindowSize();
	for (int i = 0; i < dataNum; ++i) {
		QDTreeRoot->dataList.push_front(i);
	}
	splitQD_Tree(Tstream, test, QDTreeRoot);
}

void PTAOD::splitQD_Tree(Tstream& Tstream, Test& test, Node* splitNode)
{
	queue<Node*> queSplit;
	queSplit.push(splitNode);
	Node* temNode = nullptr;
	long addr = 0;
	vector<int> vecAddr(test.getDimension(), 0);
	while (!queSplit.empty()) {
		temNode = queSplit.front();
		for (auto dataId : temNode->dataList) {
			addr = findAddrForData(Tstream, test, temNode, dataId, vecAddr);
			findChildNode(Tstream, test, addr, temNode, dataId, vecAddr);
		}
		temNode->dataList.clear();
		for (auto child : temNode->childList) {
			if (child.second->dataList.size() > treeSplitDataObjNum) {
				queSplit.push(child.second);
			}
		}
		queSplit.pop();
	}
}

long PTAOD::findAddrForData(Tstream& Tstream, Test& test, Node* node, int dataId, vector<int>& vecAddr)
{
	double treeSide = node->sideLength / 2;
	for (int i = 0; i < test.getDimension(); ++i) {
		vecAddr[i] = (Tstream.getDataInDimension(dataId, test.getDimension(), i) - node->vecLeftDown[i]) / treeSide;
	}
	return findAddr(Tstream, test, vecAddr);
}

long PTAOD::findAddr(Tstream& Tstream, Test& test, vector<int>& vecAddr)
{
	long addr = 0;
	for (int i = 0; i < vecAddr.size(); ++i) {
		addr = (addr << 1) | vecAddr[i];
	}
	return addr;
}

void PTAOD::findChildNode(Tstream& Tstream, Test& test, long addr, Node* parentNode, int dataId, vector<int>& vecAddr)
{
	double treeSide = parentNode->sideLength / 2;
	bool flag = false;
	auto findAns = parentNode->childList.find(addr);
	if (findAns != parentNode->childList.end()) {
		findAns->second->dataList.push_back(dataId);
		flag = true;
	}
	if (!flag) {
		Node* newChildNode = new Node;
		newChildNode->addr = addr;
		newChildNode->dataList.push_back(dataId);
		newChildNode->NodeId = NodeIdCount++;
		newChildNode->parentNode = parentNode;
		for (int i = 0; i < test.getDimension(); ++i) {
			newChildNode->vecLeftDown.push_back(parentNode->vecLeftDown[i] + vecAddr[i] * treeSide);
			newChildNode->vecRightUp.push_back(parentNode->vecRightUp[i] - (1 - vecAddr[i]) * treeSide);
		}
		newChildNode->sideLength = newChildNode->vecRightUp[0] - newChildNode->vecLeftDown[0];
		newChildNode->height = parentNode->height + 1;
		parentNode->childList.emplace(addr, newChildNode);
	}
}

void PTAOD::findOutlier(Tstream& Tstream, Test& test)
{
	queue<Node*> temQueue;
	temQueue.push(QDTreeRoot);
	Node* temNode = nullptr;
	int slideNum = test.getWindowSize()/ test.getInFlow();
	while (!temQueue.empty()) {
		temNode = temQueue.front();
		if (temNode->dataList.size() == 0) {
			for (auto child : temNode->childList) {
				temQueue.push(child.second);
			}
		}
		else {
			for (auto dataId : temNode->dataList) {
				dataObj* data = new dataObj;
				data->id = dataId;
				data->dataSlideId = (dataId - Tstream.getDataStreamBegin()) / test.getInFlow();
				data->vecNeighborSlide.resize(slideNum);
				findNeighborForDataObj(Tstream, test, data, temNode);
				dealDataObj(Tstream, test, data);
			}
		}
		temQueue.pop();
	}
}

void PTAOD::findNeighborForDataObj(Tstream& Tstream, Test& test, dataObj* data, Node* curNode)
{
	queue<Node*> queNode;
	queNode.push(QDTreeRoot);
	Node* temNode = nullptr;
	double dis = 0;
	int begin = Tstream.getDataStreamBegin();
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				if (getMinDisToNode(Tstream, test, data->id, child.second) <= test.getR()) {
					queNode.push(child.second);
				}
			}
		}
		else {
			for (auto it = temNode->dataList.begin(); it != temNode->dataList.end(); ++it) {
				if (*it != data->id) {
					dis = calculateDistanceById(Tstream, test, *it, data->id);
					if (dis <= test.getR()) {
						int tem = (*it - begin) / test.getInFlow();
						data->AllNeighborNum++;
						if (tem < data->dataSlideId) {
							data->vecNeighborSlide[tem]++;
						}
						else {
							data->vecNeighborNum++;
							if (data->vecNeighborNum == test.getK()) {
								return;
							}
						}
					}
				}
			}
		}
		queNode.pop();
	}
}

void PTAOD::findNeighborForDataObj(Tstream& Tstream, Test& test, dataObj* data)
{
	queue<Node*> queNode;
	queNode.push(QDTreeRoot);
	Node* temNode = nullptr;
	double r = test.getR();
	double dis = 0;
	int databegin = Tstream.getDataStreamBegin();
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->childList.size() == 0) {
			for (auto it : temNode->dataList) {
				if (it < Tstream.getDataStreamBegin()) {
					break;
				}
				dis = calculateDistanceById(Tstream, test, data->id, it);
				if (dis <= r) {
					data->temlist.push_back(it);
					int tem = (it - databegin) / test.getInFlow();
					data->AllNeighborNum++;
					if (tem < data->dataSlideId) {
						data->vecNeighborSlide[tem]++;
					}
					else {
						data->vecNeighborNum++;
					}
					if (data->vecNeighborNum >= test.getK()) {
						return;
					}
				}
			}
		}
		else {
			for (auto child : temNode->childList) {
				if (getMinDisToNode(Tstream, test, data->id, child.second) <= r) {
					queNode.push(child.second);
				}
			}
		}
		queNode.pop();
	}
}

double PTAOD::getMinDisToNode(Tstream& Tstream, Test& test, int dataId, Node* node)
{
	double result = 0;
	for (int i = 0; i < test.getDimension(); i++)
	{
		double temp, temp1, temp2;
		temp = Tstream.getDataInDimension(dataId, test.getDimension(), i);
		temp1 = node->vecLeftDown[i];
		temp2 = node->vecRightUp[i];
		if (temp < temp1)
		{
			result += pow(abs(temp - temp1), 2);
		}
		else if (temp > temp2)
		{
			result += pow(abs(temp2 - temp), 2);
		}
	}
	result = sqrt(result);
	return result;
}

void PTAOD::dealDataObj(Tstream& Tstream, Test& test, dataObj* data)
{
	int k = test.getK();
	int slideNum = test.getWindowSize()/ test.getInFlow();
	if (data->vecNeighborNum >= k) {
		Tstream.setUpdateNeighborNumById(data->id, test.getK() + 1);
		delete data;
		return;
	}
	else {
		Tstream.setUpdateNeighborNumById(data->id, 0);
		if (data->AllNeighborNum >= k) {
			cropVecNeighborSlide(Tstream, test, data);
			for (int i = 0; i < data->dataSlideId; ++i) {
				if (data->vecNeighborSlide[i] != 0) {
					if (i <= (slideNum * DeterminThreshold)) {
						data->dataState = true;
						slideVec[i].warningTimeDataObj.push_back(data);
						return;
					}
					else {
						Tstream.setUpdateNeighborNumById(data->id, test.getK() + 1);
						delete data;
						return;
					}
				}
			}
		}
		else {
			outlierList.push_back(data->id);
			outlierNum++;
			if (data->dataSlideId > 0) {
				data->dataState = false;
				slideVec[0].warningTimeDataObj.push_back(data);
				return;
			}
			else {
				delete data;
				return;
			}
		}
		
	}
}

void PTAOD::cropVecNeighborSlide(Tstream& Tstream, Test& test, dataObj* data)
{
	int cutNum = test.getK() - data->vecNeighborNum;
	bool flag = false;
	for (int i = data->dataSlideId; i >= 0; --i) {
		if (flag) {
			data->vecNeighborSlide[i] = 0;
		}
		if (data->vecNeighborSlide[i] <= cutNum) {
			cutNum -= data->vecNeighborSlide[i];
		}
		else {
			data->vecNeighborSlide[i] = cutNum;
			cutNum = 0;

		}
		if (cutNum == 0) {
			flag = true;
		}
	}
	data->AllNeighborNum = test.getK();
}

void PTAOD::Update(Tstream& Tstream, Test& test)
{
	int dimension = test.getDimension();
	int windowSize = test.getWindowSize();
	int newEntryId = windowSize;
	clock_t startTime1, endTime1;
	startTime1 = clock();
	int numx = Tstream.getvecDataStreamNum(dimension) - (test.getWindowSize());
	int enddddd = numx / test.getInFlow();
	int countSize = 1;
	if (test.getInFlow() <= 100000) {
		countSize = 100000 / test.getInFlow();
	}
	for (int iii = 0; iii < enddddd; ++iii) {
		if (iii % countSize == 0 && iii != 0)
		{
			endTime1 = clock();
			cout << "Current cursor" << Tstream.getDataStreamBegin() << "     Time = " << (double)(endTime1 - startTime1) / CLOCKS_PER_SEC << "s" << endl;
			startTime1 = clock();
			deleteEmptyNode(Tstream, test);
		}
		Tstream.addDataStreamBegin(test.getInFlow());
		Tstream.addDataStreamTag(test.getInFlow());
		Slide oldSlide = slideVec[0];
		int inFlow = test.getInFlow();
		int slideNum = test.getWindowSize()/ inFlow;
		for (int i = 0; i < (slideNum - 1); ++i) {
			slideVec[i] = slideVec[i + 1];
		}
		Slide newSlide;
		newSlide.slideId = SlideIdCount++;
		slideVec[slideNum - 1] = newSlide;
		outlierNum = 0;
		for (int i = newEntryId; i < Tstream.getDataStreamTag(); ++i) {
			addNewObjToTree(Tstream, test, i);
		}
		checkExpireObj(Tstream, test);
		dealNeedCheckSplitNode(Tstream, test);
		findNeighborForNewDataObj(Tstream, test);
		dealOldSlide(Tstream, test, oldSlide);
		newEntryId = Tstream.getDataStreamTag();
	}
}

void PTAOD::addNewObjToTree(Tstream& Tstream, Test& test, int newObjId)
{
	Node* chooseNode = nullptr;
	Node* temNode = QDTreeRoot;
	long addr;
	vector<int> vecAddr(test.getDimension(), 0);
	bool flag = false;
	while (true) {
		flag = false;
		if (temNode->childList.size() == 0) {
			temNode->dataList.push_front(newObjId);
			chooseNode = temNode;
			needCheckSplitNode.emplace_back(make_pair(newObjId, chooseNode));
			return;
		}
		addr = findAddrForData(Tstream, test, temNode, newObjId, vecAddr);
		auto findAns = temNode->childList.find(addr);
		if (findAns != temNode->childList.end()) {
			temNode = findAns->second;
			flag = true;
		}
		if (!flag) {
			createNewChildNode(Tstream, test, addr, temNode, newObjId, vecAddr, chooseNode);
			needCheckSplitNode.emplace_back(make_pair(newObjId, chooseNode));
			return;
		}
	}
}

void PTAOD::createNewChildNode(Tstream& Tstream, Test& test, long addr, Node* parentNode, int newObjId, vector<int>& vecAddr, Node*& chooseNode)
{
	double treeSide = parentNode->sideLength / 2;
	Node* newChildNode = new Node;
	newChildNode->addr = addr;
	newChildNode->dataList.push_front(newObjId);
	newChildNode->height = parentNode->height + 1;
	newChildNode->parentNode = parentNode;
	newChildNode->NodeId = NodeIdCount++;
	for (int i = 0; i < test.getDimension(); ++i) {
		newChildNode->vecLeftDown.push_back(parentNode->vecLeftDown[i] + vecAddr[i] * treeSide);
		newChildNode->vecRightUp.push_back(parentNode->vecRightUp[i] - (1 - vecAddr[i]) * treeSide);
	}
	newChildNode->sideLength = newChildNode->vecRightUp[0] - newChildNode->vecLeftDown[0];
	parentNode->childList.emplace(addr, newChildNode);
	chooseNode = newChildNode;
}

void PTAOD::dealNeedCheckSplitNode(Tstream& Tstream, Test& test)
{
	for (auto it : needCheckSplitNode) {
		if (it.second->dataList.size() == 0) {
			Node* newTarNode = nullptr;
			reFindObjInNode(Tstream, test, it.first, it.second, newTarNode);
			needFindNeighborDataObj.emplace_back(make_pair(it.first, newTarNode));
		}
		else {
			deleteExpireObj(Tstream, test, it.second->dataList);
			if (it.second->dataList.size() > treeSplitDataObjNum) {
				Node* chooseNode = nullptr;
				splitTree(Tstream, test, it.second, chooseNode, it.first);
				needFindNeighborDataObj.emplace_back(make_pair(it.first, chooseNode));
			}
			else {
				needFindNeighborDataObj.emplace_back(make_pair(it.first, it.second));
			}
		}
	}
	needCheckSplitNode.clear();
}

void PTAOD::reFindObjInNode(Tstream& Tstream, Test& test, int objId, Node* node, Node*& targetNode)
{
	Node* temNode = node;
	long addr;
	vector<int> vecAddr(test.getDimension(), 0);
	while (true) {
		if (temNode->childList.size() == 0) {
			targetNode = temNode;
			return;
		}
		addr = findAddrForData(Tstream, test, temNode, objId, vecAddr);
		auto findAns = temNode->childList.find(addr);
		if (findAns != temNode->childList.end()) {
			temNode = findAns->second;
		}
	}
}

void PTAOD::deleteExpireObj(Tstream& Tstream, Test& test, list<int>& list)
{
	int windowBegin = Tstream.getDataStreamBegin();
	auto it = list.rbegin();
	for (; it != list.rend(); ++it) {
		if (*it >= windowBegin) {
			break;
		}
	}
	list.erase(it.base(), list.end());
}

void PTAOD::splitTree(Tstream& Tstream, Test& test, Node* splitNode, Node*& chooseNode, int targetObjId)
{
	queue<Node*> queSplit;
	queSplit.push(splitNode);
	Node* temNode = nullptr;
	long addr;
	vector<int> vecAddr(test.getDimension(), 0);
	while (!queSplit.empty()) {
		temNode = queSplit.front();
		for (auto dataId : temNode->dataList) {
			addr = findAddrForData(Tstream, test, temNode, dataId, vecAddr);
			UpdateFindChildNode(Tstream, test, addr, temNode, dataId, vecAddr, chooseNode, targetObjId);
		}
		temNode->dataList.clear();
		for (auto child : temNode->childList) {
			if (child.second->dataList.size() > treeSplitDataObjNum) {
				queSplit.push(child.second);
			}
		}
		queSplit.pop();
	}
}

void PTAOD::UpdateFindChildNode(Tstream& Tstream, Test& test, long addr, Node* parentNode, int dataId, vector<int>& vecAddr, Node*& chooseNode, int targetObjId)
{
	double treeSide = parentNode->sideLength / 2;
	bool flag = false;
	auto findAns = parentNode->childList.find(addr);
	if (findAns != parentNode->childList.end()) {
		findAns->second->dataList.push_back(dataId);
		if (dataId == targetObjId) {
			chooseNode = findAns->second;
		}
		flag = true;
	}
	if (!flag) {
		Node* newChildNode = new Node;
		newChildNode->addr = addr;
		newChildNode->dataList.push_back(dataId);
		newChildNode->NodeId = NodeIdCount++;
		newChildNode->parentNode = parentNode;
		for (int i = 0; i < test.getDimension(); ++i) {
			newChildNode->vecLeftDown.push_back(parentNode->vecLeftDown[i] + vecAddr[i] * treeSide);
			newChildNode->vecRightUp.push_back(parentNode->vecRightUp[i] - (1 - vecAddr[i]) * treeSide);
		}
		newChildNode->sideLength = newChildNode->vecRightUp[0] - newChildNode->vecLeftDown[0];
		newChildNode->height = parentNode->height + 1;
		parentNode->childList.emplace(addr, newChildNode);
		if (dataId == targetObjId) {
			chooseNode = newChildNode;
		}
	}
}

void PTAOD::findNeighborForNewDataObj(Tstream& Tstream, Test& test)
{
	int slideNum = test.getWindowSize()/ test.getInFlow();
	for (auto newObj : needFindNeighborDataObj) {
		dataObj* data = new dataObj;
		data->id = newObj.first;
		data->dataSlideId = (data->id - Tstream.getDataStreamBegin()) / test.getInFlow();
		data->vecNeighborSlide.resize(slideNum);
		updateFindNeighborForDataObj(Tstream, test, data, newObj.second);
		dealDataObj(Tstream, test, data);
	}
	needFindNeighborDataObj.clear();
}

void PTAOD::updateFindNeighborForDataObj(Tstream& Tstream, Test& test, dataObj* data, Node* curNode)
{
	queue<Node*> queNode;
	queNode.push(QDTreeRoot);
	Node* temNode = nullptr;
	double dis = 0;
	int begin = Tstream.getDataStreamBegin();
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				if (getMinDisToNode(Tstream, test, data->id, child.second) <= test.getR()) {
					queNode.push(child.second);
				}
			}
		}
		else {
			for (auto it = temNode->dataList.begin(); it != temNode->dataList.end();++it) {
				if (*it != data->id) {
					dis = calculateDistanceById(Tstream, test, *it, data->id);
					if (dis <= test.getR()) {
						int tem = (*it - begin) / test.getInFlow();
						data->AllNeighborNum++;
						if (tem < data->dataSlideId) {
							data->vecNeighborSlide[tem]++;
						}
						else {
							data->vecNeighborNum++;
							if (data->vecNeighborNum == test.getK()) {
								return;
							}
						}
					}
				}
			}
		}
		queNode.pop();
	}

}

void PTAOD::dealOldSlide(Tstream& Tstream, Test& test, Slide& oldSlide)
{
	int slideNum = test.getWindowSize() / test.getInFlow();
	int k = test.getK();
	int maxId = Tstream.getvecDataStreamNum(test.getDimension());
	for (auto warningDataObj : oldSlide.warningTimeDataObj) {
		if (warningDataObj->id >= 0 && warningDataObj->id < maxId) {
			if (warningDataObj->dataState) {
				warningDataObj->dataSlideId = (warningDataObj->id - Tstream.getDataStreamBegin()) / test.getInFlow();
				warningDataObj->AllNeighborNum = 0;
				warningDataObj->dataState = false;
				warningDataObj->temlist.clear();
				warningDataObj->vecNeighborNum = 0;
				warningDataObj->vecNeighborSlide.clear();
				warningDataObj->vecNeighborSlide.resize(slideNum);
				findNeighborForDataObj(Tstream, test, warningDataObj);
				dealDataObj(Tstream, test, warningDataObj);
			}
			else {
				reFindNeighborForWarningDataObj(Tstream, test, warningDataObj);
			}
		}
	}
}

int PTAOD::calExpireSlideNum(Tstream& Tstream, Test& test, dataObj* data)
{
	for (int i = 0; i < data->dataSlideId; ++i) {
		if (data->vecNeighborSlide[i] != 0) {
			return data->vecNeighborSlide[i];
		}
	}
	return data->vecNeighborSlide[data->dataSlideId];
}

void PTAOD::updateDataObjVecSlideNeighbor(Tstream& Tstream, Test& test, dataObj* data, unsigned short temNewNeighborNum)
{
	int temNum = temNewNeighborNum;
	data->vecNeighborNum += temNum;
	for (int i = 0; i < data->dataSlideId; ++i) {
		if (data->vecNeighborSlide[i] <= temNum) {
			temNum -= data->vecNeighborSlide[i];
			data->vecNeighborSlide[i] = 0;
		}
		else {
			data->vecNeighborSlide[i] -= temNum;
			temNum = 0;
			break;
		}
	}
	Tstream.setUpdateNeighborNumById(data->id, 0);
	int step = data->dataSlideId - (data->id - Tstream.getDataStreamBegin()) / test.getInFlow();
	for (int i = step; i < data->dataSlideId; ++i) {
		data->vecNeighborSlide[i - step] = data->vecNeighborSlide[i];
	}
	data->dataSlideId = (data->id - Tstream.getDataStreamBegin()) / test.getInFlow();
	int slideNum = test.getWindowSize()/ test.getInFlow();
	for (int i = data->dataSlideId; i < slideNum; ++i) {
		data->vecNeighborSlide[i] = 0;
	}
	for (int i = 0; i < data->dataSlideId; ++i) {
		if (data->vecNeighborSlide[i] != 0) {
			slideVec[i].warningTimeDataObj.push_back(data);
		}
	}
}

void PTAOD::reFindNeighborForWarningDataObj(Tstream& Tstream, Test& test, dataObj* data)
{
	queue<Node*> queueNode;
	queueNode.push(QDTreeRoot);
	Node* temNode = nullptr;
	int neighborNum = 0;
	int k = test.getK();
	int begin = Tstream.getDataStreamBegin();
	double dis = 0;
	double r = test.getR();
	while (!queueNode.empty()) {
		temNode = queueNode.front();
		if (temNode->dataList.size() != 0) {
			for (auto id : temNode->dataList) {
				if (id < begin) {
					break;
				}
				if (id != data->id) {
					dis = calculateDistanceById(Tstream, test, data->id, id);
					if (dis <= r) {
						neighborNum++;
						if (neighborNum >= k) {
							return;
						}
					}
				}
			}
		}
		else {
			for (auto child : temNode->childList) {
				if (getMinDisToNode(Tstream, test, data->id, child.second) <= r) {
					queueNode.push(child.second);
				}
			}
		}
		queueNode.pop();
	}
	if (neighborNum >= k) {
		return;
	}
	else {
		outlierNum++;
		return;
	}
}

PTAOD::Node* removeEmptyNodes(PTAOD::Node* node) {
	if (!node) {
		return nullptr;
	}
	std::vector<long> emptyChildKeys;
	for (auto& child : node->childList) {
		child.second = removeEmptyNodes(child.second);
		if (!child.second) {
			emptyChildKeys.push_back(child.first);
		}
	}
	for (long key : emptyChildKeys) {
		node->childList.erase(key);
	}
	if (node->dataList.empty() && node->childList.empty()) {
		delete node;
		return nullptr;
	}
	return node;
}

void PTAOD::deleteEmptyNode(Tstream& Tstream, Test& test)
{
	updateNodeInfo(Tstream, test);
	QDTreeRoot = removeEmptyNodes(QDTreeRoot);
}

void PTAOD::updateNodeInfo(Tstream& Tstream, Test& test)
{
	queue<Node*> queueNode;
	queueNode.push(QDTreeRoot);
	Node* temNode = nullptr;
	while (!queueNode.empty()) {
		temNode = queueNode.front();
		if (temNode->dataList.size() != 0) {
			deleteExpireObj(Tstream, test, temNode->dataList);
		}
		else {
			for (auto child : temNode->childList) {
				queueNode.push(child.second);
			}
		}
		queueNode.pop();
	}
}

void PTAOD::changeRRRRR(Tstream& Tstream, Test& test)
{
	bool flag = false;
	int dataNum = test.getWindowSize();
	int lowerBound = 0.005 * dataNum;
	int upperBound = 0.02 * dataNum;
	if (outlierList.size() <= upperBound && outlierList.size() >= lowerBound) {
		return;
	}
	int oldNum = outlierList.size();
	double oldR = test.getR();
	multimap<double, int, greater<double>> mmmmap;
	int num = 0;
	while (!flag) {
		num = 0;
		mmmmap.clear();
		if (outlierList.size() <= upperBound && outlierList.size() >= lowerBound) {
			flag = true;
			continue;
		}
		if (outlierList.size() > upperBound) {
			list<int> temList = outlierList;
			outlierList.clear();
			for (auto id : temList) {
				double kr = findKNN(Tstream, test, id);
				mmmmap.emplace(kr, id);
			}
			for (auto x : mmmmap) {
				num++;
				if (num == (0.01 * dataNum+1)) {
					test.setR(x.first);
					outlierList.clear();
					findOutlier(Tstream, test);
					return;
				}
			}
		}
		if (outlierList.size() < lowerBound) {
			outlierList.clear();
			double r = test.getR();
			test.setR(0.8 * r);
			findOutlier(Tstream, test);
		}
	}
}

double PTAOD::findKNN(Tstream& Tstream, Test& test, int dataId)
{
	dataK newd;
	newd.dataId = dataId;
	queue<Node*> queueNode;
	queueNode.push(QDTreeRoot);
	Node* temNode = nullptr;
	int neighborNum = 0;
	int k = test.getK();
	int begin = Tstream.getDataStreamBegin();
	double dis = 0;
	double r = test.getR();
	while (!queueNode.empty()) {
		temNode = queueNode.front();
		if (temNode->dataList.size() != 0) {
			for (auto id : temNode->dataList) {
				if (id < begin) {
					break;
				}
				if (id != newd.dataId) {
					dis = calculateDistanceById(Tstream, test, newd.dataId, id);
					if (dis <= newd.KR) {
						newd.neighbor.emplace(dis, id);
						if (newd.neighbor.size() > k) {
							newd.neighbor.erase(prev(newd.neighbor.end()));
						}
						if (newd.neighbor.size() == k) {
							newd.KR = prev(newd.neighbor.end())->first;
						}
					}
				}
			}
		}
		else {
			for (auto child : temNode->childList) {
				if (getMinDisToNode(Tstream, test, newd.dataId, child.second) <= newd.KR) {
					queueNode.push(child.second);
				}
			}
		}
		queueNode.pop();
	}
	return newd.KR;
}

void PTAOD::calculateMemoryUsage(Tstream& tstream, Test& test, const int num)
{
	totalMemoryUsage += sizeof(num);
}

void PTAOD::addPreNeighborToMemoryUsage(Tstream& tstream, Test& test, dataObj* data)
{
	for (int i = 0; i < data->dataSlideId;++i) {
		calculateMemoryUsage(tstream, test, data->vecNeighborSlide[i] * (i + 1) * test.getInFlow());
	}
}

void PTAOD::checkExpireObj(Tstream& tstream, Test& test)
{
	queue<Node*> queNode;
	queNode.push(QDTreeRoot);
	Node* temNode = nullptr;
	int begin = tstream.getDataStreamBegin();
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				queNode.push(child.second);
			}
		}
		else {
			for (auto it = temNode->dataList.begin(); it != temNode->dataList.end();) {
				if (*it < begin) {
					it = temNode->dataList.erase(it);
					continue;
				}
				it++;
			}
		}
		queNode.pop();
	}
}


