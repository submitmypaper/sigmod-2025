#include <iostream>
#include<fstream>
#include<stdio.h>
#include"Test.h"
#include"Tstream.h"
#include"PTAOD.h"
#include <iomanip>
#include <ctime>
#include"string"
using namespace std;
#pragma warning(disable:4996)
void printlogmain(Tstream& Tstream, Test& test, double time1, double time2) {
	ofstream data;
	data.open("log_mainPTAOD.txt", ofstream::app);
	data << "WindowSize��" << test.getWindowSize() << endl;
	data << "K��" << test.getK() << " " << "R��" << test.getR() << " " << endl;
	data << "InitTime��" << time1 << "s" << endl;
	data << "RunningTime��" << time2 << "s" << endl;
	data.close();
}
int main()
{
	clock_t startTime, endTime;
	double initTime;
	for (int j = 0; j < 6; j++) {
		Test t;
		Tstream Tstream;
		vector<Test> vecTestFile;
		t.Init(vecTestFile, j);
		Tstream.Init(vecTestFile[j], j);
		for (int i = 0; i < vecTestFile.size(); i++) {
			if (i != 0) {
				Tstream.resetupdateNeighborNum();
			}
			PTAOD ptaod;
			Tstream.setDataStreamBegin(0);
			Tstream.setDataStreamTag(vecTestFile[i].getWindowSize());
			startTime = clock();
			ptaod.setTreeSplitDataObjNum(vecTestFile[i].getQueryCycle());
			ptaod.Init(Tstream, vecTestFile[i]);
			endTime = clock();
			std::cout << std::fixed << std::setprecision(3);
			initTime = (double)(endTime - startTime) / CLOCKS_PER_SEC;
			cout << "Init Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << 's' << endl;
			startTime = clock();
			ptaod.Update(Tstream, vecTestFile[i]);
			endTime = clock();
			cout << "Running Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
			printlogmain(Tstream, vecTestFile[i], initTime, (double)(endTime - startTime) / CLOCKS_PER_SEC);
		}
	}
	return 0;
}