#include "Tstream.h"
#include <vector>
#include <list>
#include <queue>
#include <map>
#include <set>
#include <cassert>
#include <math.h>
#include <algorithm>
#include<stack>
#include<unordered_map>
#include <numeric> 
#include <string>
Tstream::Tstream()
{
}
Tstream::~Tstream()
{
}
void Tstream::readDataFile(Test& test, int j)
{
	FILE* fp1;
	double dlNumber;
	int dimension = test.getDimension();
	vector<double> minDimension(dimension, DBL_MAX);
	vector<double> maxDimension(dimension, 0.0);
	int i = 0;
	string a = to_string(j);
	string s = "SourceFile" + a + ".txt";
	if ((fp1 = fopen(s.data(), "r")) != NULL)
	{
		while (fscanf(fp1, "%lf", &dlNumber) != EOF)
		{
			if (dlNumber < minDimension[i % dimension]) {
				minDimension[i % dimension] = dlNumber;
			}
			if (dlNumber > maxDimension[i % dimension]) {
				maxDimension[i % dimension] = dlNumber;
			}
			i++;
			vecDataStream.push_back(dlNumber);
		}
	}
	maxSide = 0;
	everyDimensionMinAndMax.resize(2 * dimension);
	for (i = 0; i < dimension; ++i) {
		if (maxSide < (maxDimension[i] - minDimension[i])) {
			maxSide = maxDimension[i] - minDimension[i];
		}
		everyDimensionMinAndMax[i * 2] = minDimension[i];
		everyDimensionMinAndMax[i * 2 + 1] = maxDimension[i];
	}
	updateNeighborNum.resize(7340032, 0);
}

double Tstream::getDataStream(int intObjectNumber)
{
	return vecDataStream[intObjectNumber];
}

double Tstream::getDataInDimension(int id, int dimension, int targetDimension)
{
	return vecDataStream[dimension * id + targetDimension];
}

vector<double> Tstream::getData(int dataId, int dimension) {
	vector<double> ans;
	for (int i = 0; i < dimension; ++i) {
		ans.push_back(vecDataStream[dimension * dataId + i]);
	}
	return ans;
}

int Tstream::getDataStreamLength()
{
	return vecDataStream.size();
}

int Tstream::getDataStreamBegin()
{
	return dataStreamBegin;
}

int Tstream::getDataStreamTag()
{
	return dataStreamTag;
}

double Tstream::getmaxSide()
{
	return maxSide;
}

void Tstream::setDataStreamBegin(int begin)
{
	dataStreamBegin = begin;
}

void Tstream::setDataStreamTag(int tag)
{
	dataStreamTag = tag;
}

void Tstream::Init(Test& test, int j)
{
	readDataFile(test, j);
	setDataStreamTag(test.getWindowSize());
	setDataStreamBegin(0);
}

void Tstream::addDataStreamBegin(int outFlow)
{
	dataStreamBegin += outFlow;
}

void Tstream::addDataStreamTag(int inFlow)
{
	dataStreamTag += inFlow;
}

void Tstream::addUpdateNeighborNumById(Test& test, int id)
{
	if (updateNeighborNum[id] < (test.getK() + 1)) {
		updateNeighborNum[id]++;
	}
}

void Tstream::setUpdateNeighborNumById(int id, int num)
{
	updateNeighborNum[id] = num;
}

unsigned short Tstream::getUpdateNeighborNumById(int id)
{
	return updateNeighborNum[id];
}

double Tstream::getEveryDimensionMinAndMax(int dimension, int index)
{
	return everyDimensionMinAndMax[dimension * 2 + index];
}

int Tstream::getMinAndMaxIdNum(int dimension, int index)
{
	return MinAndMaxIdNum[dimension * 2 + index];
}

void Tstream::MinAndMaxIdNumResize(int dimension)
{
	MinAndMaxIdNum.resize(dimension * 2);
}

void Tstream::resetupdateNeighborNum()
{
	for (int i = 0; i < updateNeighborNum.size(); ++i) {
		updateNeighborNum[i] = 0;
	}
}

int Tstream::getvecDataStreamNum(int dimension)
{
	return vecDataStream.size() / dimension;
}

void Tstream::setMinAndMaxIdNum(int dimension, int num, int index)
{
	MinAndMaxIdNum[dimension * 2 + index] = num;
}

