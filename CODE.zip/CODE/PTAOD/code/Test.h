#pragma once
#include <vector>
#include <stdlib.h>
#include <iostream>
#pragma warning(disable:4996)
using namespace std;
class Test {
public:
	Test();
	~Test();
	int getDimension();
	double getR();
	int getWindowSize();
	int getInFlow();
	int getOutFlow();
	int getQueryCycle();
	int getK();
	int getThreshold();


	void setDimension(int d);
	void setR(double r);
	void setK(int k);
	void setWindowSize(int w);
	void setInFlow(int in);
	void setOutFlow(int out);
	void setQueryCycle(int c);
	void Init(vector<Test>& vecTestFile, int j);

private:
	int dimension = 0;
	double R = 0;
	int K = 0;
	int windowSize = 0;
	int inFlow = 0;
	int outFlow = 0;
	int queryCycle = 0;
};