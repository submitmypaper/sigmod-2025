#pragma once
#include <vector>
#include <math.h>
#include<string>
#include<list>
#include"Test.h"
using namespace std;
class TStream {

public:
	vector<vector<double>>dataStream;
	vector<int>S_change;
	int StreamFront = 0;


public:
	TStream() {

	}
	~TStream() {

	}
	void readFile(Test& test, int j, int changes) {
		this->StreamFront = test.GetWindowSize();
		FILE* fp;
		string a = to_string(j);
		string s = "SourceFile" + a + ".txt";
		double temp;
		vector<double>vecTemp(test.GetDimension());
		int flag = 0;
		if ((fp = fopen(s.data(), "r")) != NULL) {
			while (fscanf(fp, "%lf", &temp) != EOF) {
				vecTemp[flag] = temp;
				flag++;
				if (flag % test.GetDimension() == 0) {
					this->dataStream.push_back(vecTemp);
					vecTemp.clear();
					vecTemp = vector<double>(test.GetDimension());
					flag = 0;
				}
			}
		}
		s = "change_s.txt";
		int tempS;
		if ((fp = fopen(s.data(), "r")) != NULL) {
			while (fscanf(fp, "%d", &tempS) != EOF) {
				S_change.push_back(tempS);
			}
		}
	}
};