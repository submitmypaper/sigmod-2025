#pragma once
#include<algorithm>
#include<unordered_map>
#include<vector>
#include<set>

#pragma warning(disable:4996)

using namespace std;

#define lowerBound 0.005
#define upperBound 0.02
#define outliersRatio 0.01

class Point {
public:
	int id;
	int slideID;
	int nnSafeIn;
	int nnSafeOut;
	int backNeighbor;
	int warningSlideID;
	set<int>pointNeighbor;
	vector<double>value;
	int lastNNSlideID;

public:
	Point(int id, vector<double>value) {
		this->id = id;
		this->value = value;
		this->nnSafeIn = 0;
		this->nnSafeOut = 0;
		this->backNeighbor = 0;
		this->warningSlideID = -1;
		this->lastNNSlideID = -1;
	}
	~Point() {

	}

public:
	int getNN() {
	}
};