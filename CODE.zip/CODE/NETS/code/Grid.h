#pragma once
#include"Tuple.h"
#include"NET.h"

#define ll long long
class Slide {
public:
	vector<Point*>pointArray;
	int slideID = 0;

public:
	Slide() {}
	Slide(int id, vector<Point*>p) {
		this->slideID = id;
		this->pointArray = p;
	}
	Slide(int id) {
		this->slideID = id;
	}
	~Slide() {}
	void getNewPoint(Point* p) {
		pointArray.push_back(p);
	}
};
class Grid {
public:
	 vector<int>id;
	 int pointSum = 0;
	 unordered_map<int, Slide*>umSlide;
	 set<vector<int> >neighborGrid;
	 int safeness = 0;
	 bool operator - (const Grid& p)const {
		 int sub = 0;
		 for (int i = 0; i < id.size(); i++) {
			 sub += this->id[i] - p.id[i];
		 }
		 return abs(sub);
	 }

public:
	Grid() {
		
	}
	~Grid() {

	}

	void SetGridID(vector<int> id) {
		this->id = id;
	}

	void calInPointSum() {
		this->pointSum = 0;
		for (auto it = this->umSlide.begin(); it != this->umSlide.end(); ++it) {
			this->pointSum += it->second->pointArray.size();
		}
	}
	void updateInPointSum(int front) {
	}
	

};