#include"NET.h"
#include"Tuple.h"
#include"Grid.h"

#include"Test.h"
#include"Tstream.h"
#include<fstream>
using namespace std;


void printlogmain(TStream& tstream, Test& test, double time1, double time2) {
	
	ofstream data;
	data.clear();
	data.open("log_mainNETS.txt", ofstream::app);
	if (data.is_open()) {
		data << endl;
		data << "WindowSize:" << test.GetWindowSize() << endl;
		data << "K= " << test.GetK() << "  " << "R= " << test.GetR() << "  " << endl;
		data << "InitTime��" << time1 << "s" << endl;
		data << "RunningTime��" << time2 << "s" << endl;
		data.close();
	}
}
int main() {
	int changes = 0;
	TStream ts;
	Test t;
	vector<Test>vecTestFile;

	for (int j = 0; j < 6; j++) {
		t.Init(vecTestFile, j);
		ts.readFile(vecTestFile[0], j, changes);
		for (int i = 0; i < vecTestFile.size(); i++) {
			clock_t starttime, endtime;
			starttime = clock();
			NETS net = NETS(vecTestFile[i], ts);
			net.Init();
			endtime = clock();
			int ans = net.getOuliersNum();
			double time1 = (double)(endtime - starttime) / CLOCKS_PER_SEC;
			cout << "Init Time: " << (double)(endtime - starttime) / CLOCKS_PER_SEC << "s\n";

			starttime = clock();
			clock_t temp = starttime;
			while (net.streamFront < ts.dataStream.size()) {
				net.update();
				ans = net.getOuliersNum();
				if (net.oldestSlideID % 20 == 0 && net.oldestSlideID != 0) {
					cout << "Current Cursor Time: " << double(clock() - temp) / 1000 << "s\n";
					temp = clock();
				}
				if (net.SlideBegin[net.newestSlideID + 1] > ts.dataStream.size()) {
					break;
				}
			}

			endtime = clock();
			double time2 = (double)(endtime - starttime) / CLOCKS_PER_SEC;
			printlogmain(ts, vecTestFile[0], time1, time2);
		}
	}
	return 0;
}