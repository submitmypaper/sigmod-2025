#pragma once
#include"Tuple.h"
#include"Grid.h"
#include"Test.h"
#include"Tstream.h"
#include<time.h>
#include<fstream>
#include<chrono>
#include<queue>

vector<int>outliers;
float nnin = 0;
float nnout = 0;
float outcnt = 0;
float upd = 0;
float judgeG = 0;

namespace std {
	template <>
	struct hash<std::vector<int>> {
		size_t operator()(const std::vector<int>& v)const {
			size_t hash = 0;
			for (int i : v) {
				hash ^= std::hash<int>{}(i)+0x9e3779b9 + (hash << 6) + (hash >> 2);
			}
			return hash;
		}
	};
}

struct VectorIntEqual {
	bool operator()(const vector<int>& a, const vector<int>& b)const {
		return a == b;
	}
};

class NETS {
public:
	void calMemory() {
		memory += sizeof(this);
		for (auto it : SlideBegin) {
			memory += sizeof(it);
		}
		for (auto it : PointSet) {
			memory += sizeof(it);
			memory += sizeof(*(it.second));
		}
		for (auto it : outliers) {
			memory += sizeof(it);
		}
		for (auto it : grid_map) {
			memory += sizeof(it);
			memory += sizeof(*(it.second));
			for (auto its : it.second->umSlide) {
				memory+=sizeof(*(its.second));
			}
		}
	}
public:
	//int dim;
	unordered_map<vector<int>, Grid*, hash<vector<int>>, VectorIntEqual>grid_map;
	Test t;
	TStream ts;
	int SlideSize = 0;
	int dim = 0;
	int outliersNum = 0;
	int inFlow = 0;
	int K = 0;
	int streamFront = 0;
	int newestSlideID = 0;
	int oldestSlideID = 0;
	double edge = 0;
	double R = 0;

	vector<Point*>outliers;
	unordered_map<int, Point*>PointSet;
	unordered_map<int, int>SlideBegin;
	size_t memory = 0;

public:
	NETS(Test t, TStream ts) {
		this->R = t.GetR();
		this->ts = ts;
		this->t = t;
		this->newestSlideID = t.GetWindowSize() / (t.GetInFlow() * t.GetDimension()) - 1;
		this->oldestSlideID = 0;
		this->SlideSize = t.GetInFlow();
		this->dim = t.GetDimension();
		this->outliersNum = 0;
		this->inFlow = t.GetInFlow();
		this->K = t.GetK();
		this->streamFront = t.GetWindowSize() / t.GetDimension();
		this->edge = this->R / (sqrt(this->dim) * 1.0);
		
	};
	~NETS() {
	};

	void setTest(Test t) {
		this->t = t;
	}
	void setTstream(TStream ts) {
		this->ts = ts;
	}
	int getOuliersNum() {
		return outliersNum;
	}



	void judgeGrid(Grid* g) {
		if (g->pointSum > t.GetK()) {
			g->safeness = 1;
			return;
		}
		else {
			int sum = 0;
			for (auto it = g->neighborGrid.begin(); it != g->neighborGrid.end(); ++it) {
				sum += grid_map[*it]->pointSum;
				if (sum + g->pointSum > t.GetK()) {
					g->safeness = 0;
					return;
				}
			}
			g->safeness = -1;
		}
	}

	double calDist(vector<int>g, vector<double>p) {
		double dist = 0;
		for (int i = 0; i < this->dim; i++) {
			dist += pow(p[i] - g[i] * this->edge, 2);
		}
		return dist;
	}

	double calDist(int p1, int p2) {
		double dist = 0;
		for (int i = 0; i < dim; i++) {
			dist += pow(ts.dataStream[p1][i] - ts.dataStream[p2][i], 2);
		}
		return sqrt(dist);
	}

	double calGridDist(Grid* g1, Grid* g2) {
		double ans = 0;
		for (int i = 0; i < this->dim; i++) {
			ans += pow(g1->id[i] - g2->id[i], 2);
		}
		return ans;
	}

	void GetNeighborGrid(Grid* g) {
		int dim = t.GetDimension();
		for (auto it2 : grid_map) {
			if (g == it2.second) {
				continue;
			}
			if (calGridDist(g, it2.second) < 4 * this->dim) {
				g->neighborGrid.insert(it2.second->id);
				it2.second->neighborGrid.insert(g->id);
			}
		}
	}

	double distPoint(int p1ID, int p2ID) {
		double dist = 0;
		for (int i = 0; i < t.GetDimension(); i++) {
			dist += pow(ts.dataStream[p1ID][i] - ts.dataStream[p2ID][i], 2);
		}
		return dist;
	}

	bool judgeNeighborPoint(int p1, int p2) {
		if (distPoint(p1, p2) <= pow(this->R, 2)) {
			return true;
		}
		return false;
	}

	void calNNSafeIn(Grid* g) {

		if (g->safeness == 1 || g->safeness == -1) {
			return;
		}

		int needPointNum = this->K;
		vector<vector<int>>neighborGrid;

		for (auto it = g->umSlide.begin(); it != g->umSlide.end(); ++it) {
			int slideID = it->second->slideID;
			for (int i = 0; i < it->second->pointArray.size(); i++) {

				if (it->second->pointArray[i]->nnSafeIn != 0) {
					continue;
				}
				for (
					auto itNeighborGrid:g->neighborGrid) {
					if (grid_map[itNeighborGrid]->umSlide.find(slideID) != grid_map[itNeighborGrid]->umSlide.end()) {
						for (auto point : grid_map[itNeighborGrid]->umSlide[slideID]->pointArray) {

							if (judgeNeighborPoint(it->second->pointArray[i]->id, point->id)) {
								it->second->pointArray[i]->nnSafeIn++;
							}
							if (it->second->pointArray[i]->nnSafeIn + it->second->pointArray.size() - 1 >= needPointNum) {
								it->second->pointArray[i]->nnSafeIn += it->second->pointArray.size() - 1;
								it->second->pointArray[i]->warningSlideID = slideID;
								break;
							}
						}
					}
					if (it->second->pointArray[i]->nnSafeIn + it->second->pointArray.size() - 1 >= needPointNum) {
						break;
					}
				}
			}
		}
	}

	void calNNSafeOut(Grid* g) {
		if (g->safeness == 1 || g->safeness == -1) {
			return;
		}

		int needPointNum = this->K - g->pointSum + 1;
	
		for (auto itSlide = g->umSlide.begin(); itSlide != g->umSlide.end(); ++itSlide) {
			int slideID = itSlide->first;
			for (auto it = itSlide->second->pointArray.begin(); it != itSlide->second->pointArray.end(); ++it) {

				if ((*it)->warningSlideID >= oldestSlideID) {
					continue;
				}

				int needOut = needPointNum - (*it)->nnSafeIn;
				if (needOut <= 0) {
					(*it)->warningSlideID = this->oldestSlideID;
					continue;
				}
				int flag = 0;
				int frontNeighbor = 0;
				for (auto it1 = (*it)->pointNeighbor.begin(); it1 != (*it)->pointNeighbor.end(); ++it1) {
					if (*it1 >= this->oldestSlideID * this->SlideSize
						) {
						(*it)->pointNeighbor.erase((*it)->pointNeighbor.begin(), it1);
						flag++;
						break;
					}
				}
				if (flag == 0) {
					(*it)->pointNeighbor.clear();
				}
				(*it)->nnSafeOut = (*it)->pointNeighbor.size();
				if (needOut <= (*it)->nnSafeOut) {
					(*it)->warningSlideID = this->oldestSlideID;
					continue;
				}

				flag = 0;

				for (int j = newestSlideID; j >= this->oldestSlideID; j--)
				 {
					if (j == slideID) {
						continue;
					}
					for (auto itNeighborGrid : g->neighborGrid) {
						if (grid_map.find(itNeighborGrid) == grid_map.end()) {
							continue;
						}
						if (calDist(itNeighborGrid, (*it)->value) > pow(2 * this->R, 2)) {
							continue;
						}

						if (grid_map[itNeighborGrid]->umSlide.find(j) != grid_map[itNeighborGrid]->umSlide.end()) {
							for (auto itPoint = grid_map[itNeighborGrid]->umSlide[j]->pointArray.begin();
								itPoint != grid_map[itNeighborGrid]->umSlide[j]->pointArray.end();
								++itPoint) {
								if (judgeNeighborPoint((*itPoint)->id, (*it)->id)
									&& (*it)->pointNeighbor.find((*itPoint)->id) == (*it)->pointNeighbor.end()
									) {
									(*it)->nnSafeOut++;
									(*it)->pointNeighbor.insert((*itPoint)->id);
									if ((*itPoint)->id > (*it)->id) {
										(*it)->backNeighbor++;
									}
								}
								if (j > slideID) {
									if ((*it)->nnSafeIn + (*it)->backNeighbor + g->umSlide[slideID]->pointArray.size() > this->K) {
										(*it)->warningSlideID = slideID;
										flag++;
										break;
									}
								}
								else {
									if ((*it)->nnSafeOut >= needOut) {
										(*it)->warningSlideID = this->oldestSlideID;
										flag++;
										break;
									}
								}
							}
						}
						if (flag) {
							break;
						}
					}
					if (flag) {

						break;
					}
				}
			}
		}
	}


	void printOutliers(vector<int>out) {
		fstream data;
		data.open("outliers.txt", ofstream::app);
		data << "begin: " << this->streamFront - t.GetWindowSize() / this->dim << endl;
		for (auto it : out) {
			data << it << endl;
		}
		data << endl;
		data.close();
	}

	void calOutliersNum() {
		this->outliersNum = 0;
		vector<int>out;
		for (auto it = grid_map.begin(); it != grid_map.end(); ++it) {
			if (it->second->safeness == 1) {
				continue;
			}
			if (it->second->safeness == -1) {
				this->outliersNum += it->second->pointSum;
				for (auto its : it->second->umSlide) {
					for (auto itp : its.second->pointArray) {
						outliers.push_back(itp);
					}
				}
			}
			if (it->second->safeness == 0) {
				for (auto itSlide = it->second->umSlide.begin();
					itSlide != it->second->umSlide.end();
					++itSlide) {
					for (auto itPoint = itSlide->second->pointArray.begin();
						itPoint != itSlide->second->pointArray.end();
						++itPoint) {

						if ((*itPoint)->warningSlideID >= oldestSlideID) {
							continue;
						}
						else if ((*itPoint)->nnSafeIn + (*itPoint)->nnSafeOut + it->second->pointSum > this->K) {
							continue;
						}
						else {
							this->outliersNum++;
							outliers.push_back(*itPoint);
						}
					}
				}
			}
		}
		int windowsize = SlideBegin[newestSlideID + 1] - SlideBegin[oldestSlideID];
		int outWarning = windowsize * outliersRatio;
		vector<double>distv;
		if (outliersNum > windowsize * upperBound || outliersNum < lowerBound * windowsize) {
			priority_queue<double, vector<double>, greater<double>>dis;
			if (outliersNum < lowerBound * windowsize) {
				findGridUp(outWarning);
			}
			for (auto it : outliers) {
				double dist = getNNR(it);
				dis.push(dist);
				distv.push_back(dist);
				if (dis.size() > outWarning) {
					dis.pop();
				}
			}
			sort(distv.begin(), distv.end(), greater<double>());
			dis.pop();
			this->R = dis.top();
			this->edge = this->R / sqrt(dim * 1.0);
			reInit();
		}
		
	}

	void Init() {
		int startWindowSlideNum = t.GetWindowSize() / this->dim / this->SlideSize;
		int dataFront = 0;
		int num = 0;
		int sum = 0;
		SlideBegin[0] = 0;
		while (SlideBegin[num] < ts.dataStream.size()) {
			num++;
			SlideBegin[num] = SlideBegin[num - 1] + ts.S_change[num];
			
		}
		for (int i = 0; i < startWindowSlideNum; i++) {
			for (int j = SlideBegin[i]; j < SlideBegin[i + 1]; j++) {
				Point* p = new Point(j, ts.dataStream[j]);
				p->slideID = i;
				PointSet[j] = p;
				vector<int>GridID(dim);
				for (int tmp = 0; tmp < dim; tmp++) {
					GridID[tmp] = p->value[tmp] / edge + 1;
				}
				if (grid_map.find(GridID) == grid_map.end()) {
					Grid* g = new Grid;
					grid_map[GridID] = g;
					grid_map[GridID]->SetGridID(GridID);

					GetNeighborGrid(g);
				}

				if (grid_map[GridID]->umSlide.find(i) == grid_map[GridID]->umSlide.end()) {
					Slide* s = new Slide(i);
					grid_map[GridID]->umSlide[i] = s;
					grid_map[GridID]->umSlide[i]->slideID = i;
				}
				grid_map[GridID]->umSlide[i]->getNewPoint(p);
			}
			dataFront = SlideBegin[i + 1];
		}
		this->streamFront = dataFront;
		for (auto it = grid_map.begin(); it != grid_map.end(); ++it) {
			it->second->calInPointSum();
		}
		for (auto it = grid_map.begin(); it != grid_map.end(); ++it) {
			judgeGrid(it->second);
		}
		for (auto it = grid_map.begin(); it != grid_map.end(); ++it) {
			calNNSafeIn(it->second);
		}
		for (auto it = grid_map.begin(); it != grid_map.end(); ++it) {
			calNNSafeOut(it->second);
		}
		calOutliersNum();
	}

	void Init(Test t, TStream ts) {
		this->t = t;
		this->ts = ts;
		int StreamFront = t.GetWindowSize() / t.GetDimension();
		int StreamBack = 0;
		for (int i = StreamBack; i < StreamFront; i++) {
			int SlideID = i / this->SlideSize;
			Point* p = new Point(i, ts.dataStream[i]);
			vector<int>GridID(dim);
			for (int j = 0; j < dim; j++) {
				GridID[j] = p->value[j] / edge + 1;
			}
			if (grid_map.find(GridID) == grid_map.end()) {
				Grid* g = new Grid;
				grid_map[GridID] = g;
				grid_map[GridID]->SetGridID(GridID);
				GetNeighborGrid(g);
			}
			if (grid_map[GridID]->umSlide.find(SlideID) == grid_map[GridID]->umSlide.end()) {
				Slide* s = new Slide(SlideID);
				grid_map[GridID]->umSlide[SlideID] = s;
				grid_map[GridID]->umSlide[SlideID]->slideID = SlideID;
			}
			
			grid_map[GridID]->umSlide[SlideID]->getNewPoint(p);
		}
		for (auto it = grid_map.begin(); it != grid_map.end(); ++it) {
			it->second->calInPointSum();
		}
		for (auto it = grid_map.begin(); it != grid_map.end(); ++it) {
			judgeGrid(it->second);
		}
		for (auto it = grid_map.begin(); it != grid_map.end(); ++it) {
			calNNSafeIn(it->second);
		}
		for (auto it = grid_map.begin(); it != grid_map.end(); ++it) {
			calNNSafeOut(it->second);
		}
		calOutliersNum();
	}

	bool updateGrid(Grid* g) {
		if (g->umSlide.find(this->oldestSlideID) != g->umSlide.end()) {
			g->umSlide.erase(this->oldestSlideID);
		}
		g->calInPointSum();
		if (g->pointSum == 0) {
			for (auto it = g->neighborGrid.begin(); it != g->neighborGrid.end(); ++it) {
				grid_map[*it]->neighborGrid.erase(g->id);
			}
			grid_map.erase(g->id);
			return false;
		}
		return true;
	}

	void update() {
		int streamBack = this->streamFront;
		outliers.clear();
		this->newestSlideID += 1;
		this->streamFront = SlideBegin[newestSlideID + 1];;
		if (this->streamFront > this->ts.dataStream.size()) {
			return;
		}
		for (int i = streamBack ; i < this->streamFront; i++) {
			Point* p = new Point(i, ts.dataStream[i]);
			p->slideID = newestSlideID;
			PointSet[i] = p;
			vector<int>GridID(dim);
			for (int j = 0; j < dim; j++) {
				GridID[j] = p->value[j] / this->edge + 1;
			}
			if (grid_map.find(GridID) == grid_map.end()) {
				Grid* g = new Grid;
				grid_map[GridID] = g;
				grid_map[GridID]->SetGridID(GridID);
				GetNeighborGrid(g);
			}
			
			if (grid_map[GridID]->umSlide.find(this->newestSlideID) == grid_map[GridID]->umSlide.end()) {
				Slide* s = new Slide(this->newestSlideID);
				grid_map[GridID]->umSlide[this->newestSlideID] = s;
			}
			
			grid_map[GridID]->umSlide[this->newestSlideID]->getNewPoint(p);
		}

		for (auto it = grid_map.begin(), lastit = it; it != grid_map.end(); ++it) {
			bool flag = updateGrid(it->second);
			if (!flag) {
				--it;
			}
			
		}
		this->oldestSlideID += 1;

		for (auto it = grid_map.begin(); it != grid_map.end(); ++it) {
			judgeGrid(it->second);
		}

		for (auto it = grid_map.begin(); it != grid_map.end(); ++it) {
			calNNSafeIn(it->second);
		}

		for (auto it = grid_map.begin(); it != grid_map.end(); ++it) {
			calNNSafeOut(it->second);
		}

		calOutliersNum();
	}

	vector<int>calGridID(Point* p) {
		vector<int>ans;
		for (int i = 0; i < dim; i++) {
			ans.push_back(int(p->value[i] / edge + 1));
		}
		return ans;
	}
	double getNNR(Point* p) {
		priority_queue<double>nnDist;
		for (int i = SlideBegin[oldestSlideID]; i < SlideBegin[newestSlideID + 1]; i++) {
			if (i == p->id)continue;
			nnDist.push(calDist(p->id, i));
			if (nnDist.size() > this->K) {
				nnDist.pop();
			}
		}
		return nnDist.top();
	}

	void reInit() {
		for (auto it : grid_map) {
			delete it.second;
		}
		for (auto it : PointSet) {
			delete it.second;
		}
		outliers.clear();
		grid_map.clear();
		PointSet.clear();
		outliersNum = 0;
		streamFront = SlideBegin[oldestSlideID];
		for (int i = oldestSlideID; i <= newestSlideID; i++) {
			int temp = streamFront;
			streamFront = SlideBegin[i + 1];
			for (int j = temp; j < streamFront; j++) {
				Point* p = new Point(j, ts.dataStream[j]);
				p->slideID = i;
				PointSet[j] = p;
				vector<int>GridID(dim);
				for (int tmp = 0; tmp < dim; tmp++) {
					GridID[tmp] = p->value[tmp] / edge + 1;
				}

				if (grid_map.find(GridID) == grid_map.end()) {
					Grid* g = new Grid;
					g->SetGridID(GridID);
					grid_map[GridID] = g;
					GetNeighborGrid(g);
				}

				if (grid_map[GridID]->umSlide.find(i) == grid_map[GridID]->umSlide.end()) {
					Slide* s = new Slide(i);
					s->slideID = i;
					grid_map[GridID]->umSlide[i] = s;
				}

				grid_map[GridID]->umSlide[i]->pointArray.push_back(p);
			}
		}

		for (auto it = grid_map.begin(); it != grid_map.end(); ++it) {
			it->second->calInPointSum();
		}
		for (auto it : grid_map) {
			judgeGrid(it.second);
		}
		for (auto it : grid_map) {
			calNNSafeIn(it.second);
		}
		for (auto it : grid_map) {
			calNNSafeOut(it.second);
		}
		calOutliersNum();
	}

	struct cmp {
		bool operator()(Grid* g1, Grid* g2) {
			return g1->pointSum > g2->pointSum;
		}
	};
	void findGridUp(int bound) {
		outliers.clear();
		priority_queue<Grid*, vector<Grid*>, cmp>qTemp;
		for (auto it : grid_map) {
			qTemp.push(it.second);
		}
		while (outliers.size() < SlideBegin[newestSlideID + 1] - SlideBegin[oldestSlideID]) {
			for (auto its : qTemp.top()->umSlide) {
				for (auto itp : its.second->pointArray) {
					if (itp->id >= SlideBegin[oldestSlideID] && itp->id < SlideBegin[newestSlideID + 1]) {
						outliers.push_back(itp);
					}
				}
			}
			qTemp.pop();
		}
	}
};