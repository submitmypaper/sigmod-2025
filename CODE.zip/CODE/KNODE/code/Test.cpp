#include "Test.h"
#include<string>
#include<vector>
#pragma warning(disable:4996)
Test::Test()
{
}

Test::~Test()
{
}
int Test::getDimension()
{
	return dimension;
}

double Test::getR()
{
	return R;
}

int Test::getK()
{
	return K;
}

int Test::getVariableK()
{
	return 1*K;
}


int Test::getWindowSize()
{
	return windowSize;
}

int Test::getInFlow()
{
	return inFlow;
}

int Test::getOutFlow()
{
	return outFlow;
}

int Test::getSplitThreshold()
{
	return splitThreshold;
}

double Test::getrho()
{
	return rho;
}


void Test::setDimension(int d)
{
	dimension = d;
}

void Test::setR(double r)
{
	R = r;
}

void Test::setK(int k)
{
	K = k;
}

void Test::setSplitThreshold(int threshold)
{
	splitThreshold = threshold;
}



void Test::setWindowSize(int w)
{
	windowSize = w;
}

void Test::setInFlow(int in)
{
	inFlow = in;
}

void Test::setOutFlow(int out)
{
	outFlow = out;
}
void Test::setRho(double p)
{
	rho = p;
}
void Test::Init(vector<Test>& vecTestFile, int j)
{
	FILE* fp;
	string a = to_string(j);
	string s = "test" + a + ".txt";
	fp = fopen(s.data(), "r");
	double n;
	int i = 0;
	Test test;
	while (fscanf(fp, "%lf", &n) != EOF)
	{
		if (i % 7 == 0)
		{
			test.setDimension((int)n);
		}
		if (i % 7 == 1)
		{
			test.setR(n);
		}
		if (i % 7 == 2)
		{
			test.setK((int)n);
		}
		if (i % 7 == 3) {
			test.setSplitThreshold((int)n);
		}
		if (i % 7 == 4) {
			test.setRho(n);
		}
		if (i % 7 == 5) {
			test.setWindowSize(n);
		}
		if (i % 7 == 6) {
			test.setInFlow((int)n);
		}
		i++;
		if (i % 7 == 0 && i != 0)
		{
			test.setOutFlow(test.getInFlow());
			vecTestFile.push_back(test);
		}
	}
}