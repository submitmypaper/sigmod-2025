#include "KNode.h"
#include <iomanip>
#include <ctime>
#include<fstream>
#define lambda 2
#define rhoMin 0.1
#define NNl_ukSmallSize 0.5
#define deleteSize 0.25
void printRho(Tstream& Tstream, Test& test, int outlierSum) {
	ofstream data;
	data.open("printRho.txt", ofstream::app);
	data << "windowSize:" << test.getWindowSize() << endl;
	data << "K= " << test.getK() << " R= " << test.getR() << " rho= " << test.getrho() << endl;
	data << "Num= " << outlierSum << endl;
	data.close();
}
KNode::KNode()
{
}

KNode::~KNode()
{
}

void KNode::setQDTreeSplitNum(int QDtreeSplitNum)
{
	QDTreeSplitNum = QDtreeSplitNum;
}

void KNode::setDataMapCount(int count)
{
	dataMapCount = count;
}

double KNode::calculateDistanceById(Tstream& tstream, Test& test, int id1, int id2)
{
	int dimension = test.getDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(tstream.getDataStream(id1 * dimension + i) - tstream.getDataStream(id2 * dimension + i), 2);
	}
	return sqrt(dis);
}

double KNode::calculateDistanceByCoordinate(Tstream& tstream, Test& test, int id, Data data)
{
	int dimension = test.getDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(tstream.getDataStream(id * dimension + i) - data[i], 2);
	}
	return sqrt(dis);
}

double KNode::calculateDistanceBetweenTwoData(Tstream& tstream, Test& test, Data data1, Data data2)
{
	int dimension = test.getDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(data1[i] - data2[i], 2);
	}
	return sqrt(dis);
}

double KNode::getMinDisToNode(Tstream& Tstream, Test& test, int dataId, Node* node)
{
	double result = 0;
	for (int i = 0; i < test.getDimension(); ++i)
	{
		double temp, temp1, temp2;
		temp = Tstream.getDataInDimension(dataId, test.getDimension(), i);
		temp1 = node->vecLeftDown[i];
		temp2 = node->vecRightUp[i];
		if (temp < temp1)
		{
			result += pow(abs(temp - temp1), 2);
		}
		else if (temp > temp2)
		{
			result += pow(abs(temp2 - temp), 2);
		}
	}
	return sqrt(result);
}

double KNode::getMaxDisToNode(Tstream& Tstream, Test& test, int dataId, Node* node)
{
	double result = 0;
	Data d = Tstream.getData(dataId, test.getDimension());
	for (int i = 0; i < test.getDimension(); ++i)
	{
		if (d[i] < node->vecLeftDown[i]) {
			result += pow(node->vecRightUp[i] - d[i], 2);
		}
		else if (d[i] > node->vecRightUp[i]) {
			result += pow(d[i] - node->vecLeftDown[i], 2);
		}
		else {
			double distToLeft = fabs(d[i] - node->vecLeftDown[i]);
			double distToRight = fabs(d[i] - node->vecRightUp[i]);
			result += pow(max(distToLeft, distToRight), 2);
		}
	}
	return sqrt(result);
}

double KNode::getMinDisBetweenTwoNode(Tstream& Tstream, Test& test, Node* node1, Node* node2)
{
	int dim = test.getDimension();
	double distanceSquared = 0.0;
	for (int i = 0; i < dim; ++i) {
		if (node1->vecRightUp[i] < node2->vecLeftDown[i]) {
			distanceSquared += pow(node2->vecLeftDown[i] - node1->vecRightUp[i], 2);
		}
		else if (node2->vecRightUp[i] < node1->vecLeftDown[i]) {
			distanceSquared += pow(node1->vecLeftDown[i] - node2->vecRightUp[i], 2);
		}
	}
	return sqrt(distanceSquared);
}

void KNode::Init(Tstream& Tstream, Test& test)
{
	setQDTreeSplitNum(test.getSplitThreshold());
	slideNum = test.getWindowSize() / test.getDimension() / test.getInFlow();
	if (slideNum <= 5) {
		setDataMapCount(1);
	}
	else {
		setDataMapCount(slideNum / 4);
	}
	s_changeNum = Tstream.getS_changeSize() / dataMapCount + 1;
	setfindl_kupThreshold(Tstream, test);
	setTreeInfo(Tstream, test);
	addDataObjToTree(Tstream, test);
	findOutlier(Tstream, test);

	int dataNum = calWindowMaintainObjNum(Tstream, test);
	int lowerBound = 0.005 * dataNum;
	int upperBound = 0.02 * dataNum;
	if (changeRMap.size() < lowerBound || changeRMap.size() > upperBound) {
		checkChangeR(Tstream, test);
	}
}

void KNode::setTreeInfo(Tstream& Tstream, Test& test)
{
	double side = Tstream.getMaxSide();
	QDTreeRoot = new Node;
	int dimension = test.getDimension();
	QDTreeRoot->NodeId = NodeIdCount++;
	for (int i = 0; i < dimension; ++i) {
		QDTreeRoot->vecLeftDown.push_back(Tstream.getEveryDimensionMinAndMax(i, 0));
		QDTreeRoot->vecRightUp.push_back(Tstream.getEveryDimensionMinAndMax(i, 0) + side);
	}
	QDTreeRoot->sideLength = QDTreeRoot->vecRightUp[0] - QDTreeRoot->vecLeftDown[0];
	QDTreeRoot->diagonalLength = QDTreeRoot->sideLength * sqrt(test.getDimension());
}

void KNode::addDataObjToTree(Tstream& Tstream, Test& test)
{
	int dataNum = 0;
	for (int i = 0; i < slideNum; i++) {
		dataNum += Tstream.getS_change(i);
	}
	int dataBack = 0;
	int temp = 0;
	list<int> l;
	for (int i = 0; i < slideNum; ++i) {
		temp = dataBack;
		dataBack += Tstream.getS_change(i);
		for (int j = temp; j < dataBack; ++j) {
			PointSet[j] = i;
			int tem = i / dataMapCount;
			if (QDTreeRoot->dataMap.find(tem) != QDTreeRoot->dataMap.end()) {
				QDTreeRoot->dataMap[tem].push_front(j);
			}
			else {
				l.push_front(j);
				QDTreeRoot->dataMap[tem] = l;
				l.clear();
			}
		}
	}
	Tstream.setDataStreamBegin(0);
	Tstream.setDataStreamTag(dataBack);
	QDTreeRoot->maintainDataNum = dataNum;
	splitTree(Tstream, test, QDTreeRoot);
}

void KNode::splitTree(Tstream& Tstream, Test& test, Node* splitNode)
{
	queue<Node*> queSplit;
	queSplit.push(splitNode);
	Node* temNode = nullptr;
	long addr = 0;
	vector<int> vecAddr(test.getDimension(), 0);
	while (!queSplit.empty()) {
		temNode = queSplit.front();
		for (auto group : temNode->dataMap) {
			for (auto dataId : group.second) {
				addr = findAddrForData(Tstream, test, temNode, dataId, vecAddr);
				findChildNode(Tstream, test, addr, temNode, dataId, vecAddr);
			}
		}
		temNode->dataMap.clear();
		for (auto child : temNode->childList) {
			if (child.second->maintainDataNum > QDTreeSplitNum && child.second->diagonalLength >= rhoMin * test.getR()) {
				queSplit.push(child.second);
			}
		}
		queSplit.pop();
	}
}

void KNode::splitTree(Tstream& Tstream, Test& test, Node* splitNode, bool update)
{
	queue<Node*> queSplit;
	queSplit.push(splitNode);
	Node* temNode = nullptr;
	long addr = 0;
	vector<int> vecAddr(test.getDimension(), 0);
	int dataStreamBegin = Tstream.getDataStreamBegin();
	int maxSlideIdCount = slideNum - 1 + SlideIdCount;
	int endSlideIdCount = 0;
	(SlideIdCount - slideNum + 1) > 0 ? endSlideIdCount = (SlideIdCount - slideNum + 1) : endSlideIdCount = 0;
	while (!queSplit.empty()) {
		temNode = queSplit.front();
		for (auto group : temNode->dataMap) {
			for (auto dataId : group.second) {
				addr = findAddrForData(Tstream, test, temNode, dataId, vecAddr);
				findChildNode(Tstream, test, addr, temNode, dataId, vecAddr);
			}
		}
		temNode->dataMap.clear();
		for (auto child : temNode->childList) {
			if (child.second->maintainDataNum > QDTreeSplitNum && child.second->diagonalLength >= rhoMin * test.getR()) {
				queSplit.push(child.second);
			}
		}
		queSplit.pop();
	}
}

long KNode::findAddrForData(Tstream& Tstream, Test& test, Node* node, int& dataId, vector<int>& vecAddr)
{
	double treeSide = node->sideLength / 2;
	for (int i = 0; i < test.getDimension(); ++i) {
		vecAddr[i] = (Tstream.getDataInDimension(dataId, test.getDimension(), i) - node->vecLeftDown[i]) / treeSide;
	}
	return findAddr(Tstream, test, vecAddr);
}

long KNode::findAddr(Tstream& Tstream, Test& test, vector<int>& vecAddr)
{
	long addr = 0;
	for (int i = 0; i < vecAddr.size(); ++i) {
		addr = (addr << 1) | vecAddr[i];
	}
	return addr;
}

void KNode::findChildNode(Tstream& Tstream, Test& test, long& addr, Node* parentNode, int& dataId, vector<int>& vecAddr)
{
	auto findAns = parentNode->childList.find(addr);
	if (findAns != parentNode->childList.end()) {
		findAns->second->maintainDataNum++;
		int tem = PointSet[dataId] / dataMapCount;
		if (findAns->second->dataMap.find(tem) != findAns->second->dataMap.end()) {
			findAns->second->dataMap[tem].push_back(dataId);
		}
		else {
			creatPartition(Tstream, test, dataId, findAns->second);
		}
	}
	else {
		Node* newChildNode = new Node;
		newChildNode->addr = addr;
		creatPartition(Tstream, test, dataId, newChildNode);
		newChildNode->NodeId = NodeIdCount++;
		newChildNode->parentNode = parentNode;
		double treeSide = parentNode->sideLength / 2;
		for (int i = 0; i < test.getDimension(); ++i) {
			newChildNode->vecLeftDown.push_back(parentNode->vecLeftDown[i] + vecAddr[i] * treeSide);
			newChildNode->vecRightUp.push_back(parentNode->vecRightUp[i] - (1 - vecAddr[i]) * treeSide);
		}
		newChildNode->sideLength = newChildNode->vecRightUp[0] - newChildNode->vecLeftDown[0];
		newChildNode->diagonalLength = newChildNode->sideLength * sqrt(test.getDimension());
		newChildNode->maintainDataNum++;
		parentNode->childList.emplace(addr, newChildNode);
	}
}

void KNode::findOutlier(Tstream& Tstream, Test& test)
{
	findKnodeSet(Tstream, test);
	setl_kupToDescendentNodeOfKnode(Tstream, test);
	dealNodeInE_I(Tstream, test);
	dealNodeInE_L(Tstream, test);
}

void KNode::findKnodeSet(Tstream& Tstream, Test& test)
{
	queue<Node*> queNode;
	queNode.push(QDTreeRoot);
	Node* temNode = nullptr;
	int k = test.getK();
	double threshold = (1 + test.getrho()) * test.getR() / 2;
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->maintainDataNum > k) {
			if (temNode->childList.size() != 0) {
				for (auto child : temNode->childList) {
					queNode.push(child.second);
				}
			}
		}
		else {
			temNode->KnodeFlag = true;
			if (temNode->diagonalLength <= threshold) {
				KnodeSmall.push_back(temNode);
				createNodeNNl(Tstream, test, temNode);
			}
			else {
				KnodeLarge.push_back(temNode);
				createNodeNNl(Tstream, test, temNode);
			}
		}
		queNode.pop();
	}
	findE_IAndE_lInKnodeLarge(Tstream, test);
}

void KNode::createNodeNNl(Tstream& Tstream, Test& test, Node* targetNode)
{
	double u_k = targetNode->diagonalLength * 2;
	queue<Node*> queNode;
	queue<Node*> stackNode;
	stackNode.push(targetNode);
	Node* temNode = targetNode;
	int k = test.getK();
	double r = test.getR();
	addCurNodeLeafNodeToNNluk(Tstream, test, targetNode);
	double dis = 0;
	if ((targetNode->NNl_uk.size() + targetNode->NNl_ukSmall.size()) >= lambda * k) {
		return;
	}
	while (temNode->parentNode != nullptr) {
		temNode = temNode->parentNode;
		stackNode.push(temNode);
	}
	while (!stackNode.empty()) {
		if (stackNode.front()->parentNode != nullptr) {
			temNode = stackNode.front()->parentNode;
			for (auto it = temNode->childList.begin(); it != temNode->childList.end(); ++it) {
				if ((*it).second->NodeId != stackNode.front()->NodeId && getMinDisBetweenTwoNode(Tstream, test, (*it).second, targetNode) <= u_k) {
					queNode.push((*it).second);
				}
			}
		}
		stackNode.pop();
		while (!queNode.empty()) {
			temNode = queNode.front();
			dis = getMinDisBetweenTwoNode(Tstream, test, temNode, targetNode);
			if (dis <= u_k) {
				if (temNode->childList.size() != 0) {
					for (auto child : temNode->childList) {
						if (getMinDisBetweenTwoNode(Tstream, test, child.second, targetNode) <= u_k) {
							queNode.push(child.second);
						}
					}
				}
				else {
					if (temNode->diagonalLength <= (NNl_ukSmallSize * r)) {
						targetNode->NNl_ukSmall.emplace(temNode->NodeId, temNode);
					}
					else {
						targetNode->NNl_uk.emplace(temNode->NodeId, temNode);
					}
					if ((targetNode->NNl_uk.size() + targetNode->NNl_ukSmall.size()) >= lambda * k) {
						return;
					}
				}
			}
			queNode.pop();
		}
	}
}

void KNode::addCurNodeLeafNodeToNNluk(Tstream& Tstream, Test& test, Node* targetNode)
{
	queue<Node*> queNode;
	queNode.push(targetNode);
	double u_k = targetNode->diagonalLength * 2;
	Node* temNode = nullptr;
	int k = test.getK();
	double dis = 0;
	double r = test.getR();
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				if (getMinDisBetweenTwoNode(Tstream, test, child.second, targetNode) <= u_k) {
					queNode.push(child.second);
				}
			}
		}
		else {
			if (temNode->diagonalLength <= (NNl_ukSmallSize * r)) {
				targetNode->NNl_ukSmall.emplace(temNode->NodeId, temNode);
			}
			else {
				targetNode->NNl_uk.emplace(temNode->NodeId, temNode);
			}
			if ((targetNode->NNl_uk.size() + targetNode->NNl_ukSmall.size()) >= lambda * k) {
				return;
			}
		}
		queNode.pop();
	}
}

void KNode::findE_IAndE_lInKnodeLarge(Tstream& Tstream, Test& test)
{
	Node* temNode = nullptr;
	double threshold = test.getR() * test.getrho() / 2;
	for (auto KNode : KnodeLarge) {
		queue<Node*> queKNode;
		queKNode.push(KNode);
		while (!queKNode.empty()) {
			temNode = queKNode.front();
			if (temNode->childList.size() == 0) {
				if (temNode->diagonalLength > threshold) {
					if (temNode->maintainDataNum != 0) {
						E_L.emplace(temNode->NodeId, temNode);
					}
				}
				else {
					if (temNode->maintainDataNum != 0) {
						E_I.emplace(temNode->NodeId, temNode);
					}
				}
			}
			else {
				if (temNode->diagonalLength > threshold) {
					for (auto child : temNode->childList) {
						queKNode.push(child.second);
					}
				}
				else {
					if (temNode->maintainDataNum != 0) {
						E_I.emplace(temNode->NodeId, temNode);
					}
				}
			}
			queKNode.pop();
		}
	}
}

void KNode::findE_IAndE_lInKnodeLarge(Tstream& Tstream, Test& test, list<Node*>& newKnodeLarge)
{
	Node* temNode = nullptr;
	double threshold = test.getR() * test.getrho() / 2;
	for (auto KNode : newKnodeLarge) {
		queue<Node*> queKNode;
		queKNode.push(KNode);
		while (!queKNode.empty()) {
			temNode = queKNode.front();
			if (temNode->childList.size() == 0) {
				if (temNode->diagonalLength > threshold) {
					if (temNode->maintainDataNum != 0) {
						E_L.emplace(temNode->NodeId, temNode);
					}
				}
				else {
					if (temNode->maintainDataNum != 0) {
						E_I.emplace(temNode->NodeId, temNode);
					}
				}
			}
			else {
				if (temNode->diagonalLength > threshold) {
					for (auto child : temNode->childList) {
						queKNode.push(child.second);
					}
				}
				else {
					if (temNode->maintainDataNum != 0) {
						E_I.emplace(temNode->NodeId, temNode);
					}
				}
			}
			queKNode.pop();
		}
	}
}

void KNode::setl_kupToDescendentNodeOfKnode(Tstream& Tstream, Test& test)
{
	for (auto KNode : KnodeSmall) {
		findl_kupInKnode(Tstream, test, KNode);
	}
	for (auto KNode : KnodeLarge) {
		findl_kupInKnode(Tstream, test, KNode);
	}
}

void KNode::findl_kupInKnode(Tstream& Tstream, Test& test, Node* KNode)
{
	queue<Node*> queNode;
	queNode.push(KNode);
	Node* temNode = nullptr;
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->diagonalLength <= findl_kupThreshold) {
			findKNN(Tstream, test, temNode, KNode->NNl_uk, KNode->NNl_ukSmall);
		}
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				queNode.push(child.second);
			}
		}
		queNode.pop();
	}
}

void KNode::findKNN(Tstream& Tstream, Test& test, Node* targetNode, maplist<int, Node*>& nodeMap, maplist<int, Node*>& nodeMapSmall)
{
	multimap<double, int> knnMap;
	vector<int> indexVec(s_changeNum);
	double dis = 0;
	double minDis = DBL_MAX;
	bool flag = false;
	for (auto node : nodeMapSmall) {
		flag = false;
		dis = getMinDisBetweenTwoNode(Tstream, test, targetNode, node.second);
		if (dis < minDis) {
			for (auto group : node.second->dataMap) {
				if (flag) {
					break;
				}
				for (auto id : group.second) {
					if (dis < minDis) {
						knnMap.emplace(dis, group.first);
						indexVec[group.first]++;
						if (knnMap.size() > (test.getK() + 1)) {
							auto it = knnMap.end();
							it--;
							indexVec[it->second]--;
							knnMap.erase(it);
							minDis = knnMap.rbegin()->first;
						}
					}
					else {
						flag = true;
						break;
					}
				}
			}
		}
	}
	for (auto node : nodeMap) {
		flag = false;
		dis = getMinDisBetweenTwoNode(Tstream, test, targetNode, node.second);
		if (dis < minDis) {
			for (auto group : node.second->dataMap) {
				if (flag) {
					break;
				}
				for (auto id : group.second) {
					if (dis < minDis) {
						knnMap.emplace(dis, group.first);
						indexVec[group.first]++;
						if (knnMap.size() > (test.getK() + 1)) {
							auto it = knnMap.end();
							it--;
							indexVec[it->second]--;
							knnMap.erase(it);
							minDis = knnMap.rbegin()->first;
						}
					}
					else {
						flag = true;
						break;
					}
				}
			}
		}
	}
	targetNode->l_kup = knnMap.rbegin()->first;
	for (int i = SlideIdCount / dataMapCount; i < s_changeNum; ++i) {
		if (indexVec[i] != 0) {
			targetNode->warningTime = i * dataMapCount + 1;
			break;
		}
	}
}

void KNode::dealNodeInE_I(Tstream& Tstream, Test& test)
{
	double r = test.getR();
	for (auto node : E_I) {
		if (node.second->l_kup > r) {
			tighteningl_kup(Tstream, test, node.second);
			if (node.second->l_kup > r) {
				printOutlier(Tstream, test, node.second);
			}
			updateParentNodel_kupAnde_t(Tstream, test, node.second);
		}
	}
}

void KNode::dealNodeInE_L(Tstream& Tstream, Test& test)
{
	double r = test.getR();
	for (auto node : E_L) {
		if (node.second->diagonalLength > findl_kupThreshold) {
			for (auto group : node.second->dataMap) {
				for (auto id : group.second) {
					createONrByNode(Tstream, test, id, node.second);
				}
			}
		}
		else {
			if (node.second->l_kup > r || ((node.second->l_kup + 2 * node.second->diagonalLength) > (1 + test.getrho()) * r)) {
				tighteningl_kup(Tstream, test, node.second);
				if (node.second->l_kup > r) {
					printOutlier(Tstream, test, node.second);
					continue;
				}
				updateParentNodel_kupAnde_t(Tstream, test, node.second);
				if (node.second->l_kup <= r && (node.second->l_kup + 2 * node.second->diagonalLength) > (1 + test.getrho()) * r) {
					for (auto group : node.second->dataMap) {
						for (auto id : group.second) {
							createONrByNode(Tstream, test, id, node.second);
						}
					}
				}
			}
		}
	}

}

void KNode::tighteningl_kup(Tstream& Tstream, Test& test, Node* node)
{
	queue<Node*> queNode;
	Node* temNode = node;
	double dis = 0;
	double minDis = DBL_MAX;
	double r = test.getR();
	int k = test.getK();
	unordered_multimap<double, Node*> NNr;
	int totalObjnum = 0;
	totalObjnum += node->maintainDataNum;
	queue<Node*> stackNode;
	stackNode.push(node);
	while (temNode->parentNode != nullptr) {
		temNode = temNode->parentNode;
		stackNode.push(temNode);
	}
	while (!stackNode.empty()) {
		if (stackNode.front()->parentNode != nullptr) {
			temNode = stackNode.front()->parentNode;
			for (auto it = temNode->childList.begin(); it != temNode->childList.end(); ++it) {
				if ((*it).second->NodeId != stackNode.front()->NodeId && getMinDisBetweenTwoNode(Tstream, test, (*it).second, node) <= r) {
					queNode.push((*it).second);
				}
			}
		}
		stackNode.pop();
		while (!queNode.empty()) {
			temNode = queNode.front();
			dis = getMinDisBetweenTwoNode(Tstream, test, temNode, node);
			if (dis <= r) {
				if (temNode->diagonalLength == node->diagonalLength) {
					NNr.emplace(dis, temNode);
					totalObjnum += temNode->maintainDataNum;
				}
				else {
					if (temNode->childList.size() != 0) {
						for (auto child : temNode->childList) {
							if (getMinDisBetweenTwoNode(Tstream, test, child.second, node) <= r) {
								queNode.push(child.second);
							}
						}
					}
					else {
						NNr.emplace(dis, temNode);
						totalObjnum += temNode->maintainDataNum;
					}
				}
			}
			queNode.pop();
		}
	}
	bool flag = false;
	if (totalObjnum >= (k + 1)) {
		multimap<double, int> knnMap;
		vector<int> indexVec(s_changeNum);
		calNodel_kInNode(Tstream, test, node, knnMap, node, minDis, indexVec);
		for (auto nodeInNNr : NNr) {
			if (nodeInNNr.second->childList.size() != 0 && getMinDisBetweenTwoNode(Tstream, test, node, nodeInNNr.second) < minDis) {
				calNodel_kInNode(Tstream, test, node, knnMap, nodeInNNr.second, minDis, indexVec);
			}
			else {
				flag = false;
				dis = getMinDisBetweenTwoNode(Tstream, test, node, nodeInNNr.second);
				if (dis < minDis) {
					for (auto group : nodeInNNr.second->dataMap) {
						if (flag) {
							break;
						}
						for (auto id : group.second) {
							if (dis < minDis) {
								knnMap.emplace(dis, group.first);
								indexVec[group.first]++;
								if (knnMap.size() > (test.getK() + 1)) {
									auto it = knnMap.end();
									it--;
									indexVec[it->second]--;
									knnMap.erase(it);
									minDis = knnMap.rbegin()->first;
								}
							}
							else {
								flag = true;
								break;
							}
						}
					}
				}
			}
		}
		node->l_kup = knnMap.rbegin()->first;
		for (int i = SlideIdCount / dataMapCount; i < indexVec.size(); ++i) {
			if (indexVec[i] != 0) {
				node->warningTime = i * dataMapCount + 1;
				break;
			}
		}
	}
	else {
		node->warningTime = SlideIdCount + 1;
	}
}

void KNode::calNodel_kInNode(Tstream& Tstream, Test& test, Node* targetNode, multimap<double, int>& knnMap, Node* nodeInNNr, double& minDis, vector<int>& indexVec)
{
	queue<Node*> queNode;
	queNode.push(nodeInNNr);
	double dis = 0;
	Node* temNode = nullptr;
	bool flag = false;
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				if (getMinDisBetweenTwoNode(Tstream, test, targetNode, child.second) < minDis) {
					queNode.push(child.second);
				}
			}
		}
		else {
			dis = getMinDisBetweenTwoNode(Tstream, test, targetNode, temNode);
			flag = false;
			for (auto group : temNode->dataMap) {
				if (flag) {
					break;
				}
				for (auto neighborId : group.second) {
					if (dis < minDis) {
						knnMap.emplace(dis, group.first);
						indexVec[group.first]++;
						if (knnMap.size() > (test.getK() + 1)) {
							auto it = knnMap.end();
							it--;
							indexVec[it->second]--;
							knnMap.erase(it);
							minDis = knnMap.rbegin()->first;
						}
					}
					else {
						flag = true;
						break;
					}
				}
			}
		}
		queNode.pop();
	}
}

void KNode::updateParentNodel_kupAnde_t(Tstream& Tstream, Test& test, Node* node)
{
	if (node->KnodeFlag) {
		return;
	}
	Node* temNode = node->parentNode;
	while (temNode != nullptr && !temNode->KnodeFlag) {
		if (temNode->l_kup > node->l_kup) {
			temNode->l_kup = node->l_kup;
			temNode->warningTime = node->warningTime;
			temNode = temNode->parentNode;
		}
		else {
			break;
		}
		
	}
	if (temNode != nullptr) {
		if (temNode->l_kup > node->l_kup) {
			temNode->l_kup = node->l_kup;
			temNode->warningTime = node->warningTime;
		}
	}
}

void KNode::createONrByNode(Tstream& Tstream, Test& test, int& objId, Node* targetNode)
{
	double r = test.getR();
	dataObj* obj = new dataObj;
	obj->id = objId;
	obj->oNrdataObjVec.resize(s_changeNum);
	double disMax = 0;
	vector<int> groupIndex(s_changeNum);
	int neighborNum = 0;
	int posIndex = getPosIndex(Tstream, test);
	Node* kNode = targetNode;
	while (!kNode->KnodeFlag) {
		kNode = kNode->parentNode;
	}
	for (auto it = kNode->NNl_ukSmall.begin(); it != kNode->NNl_ukSmall.end();) {
		if (neighborNum >= test.getK()) {
			break;
		}
		if (it->second->maintainDataNum != 0) {
			disMax = getMaxDisToNode(Tstream, test, objId, it->second);
			if ((disMax + it->second->l_kup) <= r) {
				obj->l_k = it->second->l_kup;
				obj->warningTime = it->second->warningTime;
				warningObjMap.emplace(objId, obj);
				return;
			}
			if (getMinDisToNode(Tstream, test, objId, it->second) <= r && disMax <= (1 + test.getrho()) * r) {
				obj->oNrNodeList.push_back(it->second);
				addRhoNeighbor(Tstream, test, it->second, obj, groupIndex, neighborNum, posIndex);
			}
		}
		else {
			it = kNode->NNl_ukSmall.erase(it);
			continue;
		}
		it++;
	}
	for (auto it = kNode->NNl_uk.begin(); it != kNode->NNl_uk.end();) {
		if (neighborNum >= test.getK()) {
			break;
		}
		if (it->second->maintainDataNum != 0) {
			if (getMinDisToNode(Tstream, test, objId, it->second) <= r && getMaxDisToNode(Tstream, test, objId, it->second) <= (1 + test.getrho()) * r) {
				obj->oNrNodeList.push_back(it->second);
				addRhoNeighbor(Tstream, test, it->second, obj, groupIndex, neighborNum, posIndex);
			}
		}
		else {
			it = kNode->NNl_uk.erase(it);
			continue;
		}
		it++;
	}
	if (neighborNum < test.getK()) {
		delete obj;
		reFindONr(Tstream, test, objId, targetNode, posIndex);
	}
	else {
		obj->l_k = test.getR();
		int countNum = test.getK();
		int lastIndex = PointSet[Tstream.getDataStreamTag() - 1] / dataMapCount;
		int startIndex = getStartIndex(Tstream, test);
		for (int i = lastIndex; i >= startIndex; --i) {
			countNum -= groupIndex[i];
			if (countNum <= 0) {
				if (i * dataMapCount < PointSet[obj->id]) {
					obj->warningTime = i * dataMapCount + 1;
				}
				else {
					obj->warningTime = INT_MAX;
				}
				break;
			}
		}
		warningObjMap.emplace(obj->id, obj);	
	}
}

void KNode::addRhoNeighbor(Tstream& Tstream, Test& test, Node* rhoNode, dataObj* obj, vector<int>& groupIndex, int& neighborNum, int& index)
{
	queue<Node*> queNode;
	queNode.push(rhoNode);
	Node* temNode = nullptr;
	int windowBegin = Tstream.getDataStreamBegin();
	while (!queNode.empty()) {
		if (neighborNum >= (test.getK() + 0)) {
			return;
		}
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				if (child.second->maintainDataNum != 0) {
					queNode.push(child.second);
				}
			}
		}
		else {
			for (auto group = temNode->dataMap.begin(); group != temNode->dataMap.end();) {
				if (neighborNum >= (test.getK() + 0)) {
					return;
				}
				if (group->first > index) {
					groupIndex[group->first] += group->second.size();
					neighborNum += group->second.size();
				}
				else if (group->first == index) {
					auto temobj = group->second.rbegin();
					for (; temobj != group->second.rend(); ++temobj) {
						if (*temobj >= windowBegin) {
							break;
						}
					}
					group->second.erase(temobj.base(), group->second.end());
					if (group->second.size() == 0) {
						group = temNode->dataMap.erase(group);
						continue;
					}
					else {
						groupIndex[group->first] += group->second.size();
						neighborNum += group->second.size();
					}
				}
				group++;
			}
		}
		queNode.pop();
	}
}

void KNode::addRhoNeighbor(Tstream& Tstream, Test& test, Node* rhoNode, dataObj* obj, vector<int>& groupIndex, int& neighborNum, int& beginIndex, int& endIndex)
{
	queue<Node*> queNode;
	queNode.push(rhoNode);
	Node* temNode = nullptr;
	int windowBegin = Tstream.getDataStreamBegin();
	while (!queNode.empty()) {
		if (neighborNum >= (test.getK() + 0)) {
			return;
		}
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				if (child.second->maintainDataNum != 0) {
					queNode.push(child.second);
				}
			}
		}
		else {
			for (auto group = temNode->dataMap.begin(); group != temNode->dataMap.end();) {
				if (neighborNum >= (test.getK() + 0)) {
					break;
				}
				if (group->first < endIndex) {
					if (group->first > beginIndex) {
						groupIndex[group->first] += group->second.size();
						neighborNum += group->second.size();
					}
					else if (group->first == beginIndex) {
						auto dataobj = group->second.rbegin();
						for (; dataobj != group->second.rend(); ++dataobj) {
							if (*dataobj >= windowBegin) {
								break;
							}
						}
						group->second.erase(dataobj.base(), group->second.end());
						if (group->second.size() == 0) {
							group = temNode->dataMap.erase(group);
							continue;
						}
						else {
							groupIndex[group->first] += group->second.size();
							neighborNum += group->second.size();
						}
					}
					else {
						group = temNode->dataMap.erase(group);
						continue;
					}
				}
				group++;
			}
		}
		queNode.pop();
	}
}

void KNode::reFindONr(Tstream& Tstream, Test& test, int& objId, Node* targetNode, int& index)
{
	queue<Node*> queNode;
	queue<Node*> stackNode;
	stackNode.push(targetNode);
	Node* temNode = targetNode;
	double r = test.getR();
	dataObj* obj = new dataObj;
	obj->id = objId;
	obj->oNrdataObjVec.resize(s_changeNum);
	double dis = 0;
	vector<int> groupIndex(s_changeNum);
	int neighborNum = 0;
	list<Node*> NodeList;
	int startIndex = getStartIndex(Tstream, test);
	addNeighborInIntermediateNode(Tstream, test, obj, targetNode, groupIndex, neighborNum, index, NodeList);
	if (neighborNum >= (test.getK() + 0)) {
		obj->l_k = test.getR();
		int countNum = test.getK() + 0;
		int lastIndex = PointSet[Tstream.getDataStreamTag() - 1] / dataMapCount;
		for (int i = lastIndex; i >= startIndex; --i) {
			countNum -= groupIndex[i];
			if (countNum <= 0) {
				if (i * dataMapCount < PointSet[obj->id]) {
					obj->warningTime = i * dataMapCount + 1;
				}
				else {
					obj->warningTime = INT_MAX;
				}
				break;
			}
		}
		warningObjMap.emplace(obj->id, obj);
		return;
	}
	else {
		while (temNode->parentNode != nullptr) {
			temNode = temNode->parentNode;
			stackNode.push(temNode);
		}
		while (!stackNode.empty()) {
			if (stackNode.front()->parentNode != nullptr) {
				temNode = stackNode.front()->parentNode;
				for (auto it = temNode->childList.begin(); it != temNode->childList.end(); ++it) {
					if ((*it).second->NodeId != stackNode.front()->NodeId && getMinDisBetweenTwoNode(Tstream, test, (*it).second, targetNode) <= r) {
						queNode.push((*it).second);
					}
				}
			}
			stackNode.pop();
			while (!queNode.empty()) {
				temNode = queNode.front();
				if (temNode->maintainDataNum > 0) {
					addNeighborInIntermediateNode(Tstream, test, obj, temNode, groupIndex, neighborNum, index, NodeList);
				}
				queNode.pop();
			}
		}
		if (neighborNum < (test.getK() + 0)) {
			for (auto nodeInONr : obj->oNrNodeList) {
				addRhoNeighbor(Tstream, test, nodeInONr, obj, groupIndex, neighborNum, startIndex, index);
				if (neighborNum >= (test.getK() + 0)) {
					break;
				}
			}
			for (auto leafNode : NodeList) {
				for (auto group : leafNode->dataMap) {
					if (neighborNum >= (test.getK() + 0)) {
						break;
					}
					if (group.first < index) {
						if (group.first > startIndex) {
							for (auto id : group.second) {
								if (id != objId && calculateDistanceById(Tstream, test, id, objId) <= r) {
									groupIndex[group.first]++;
									obj->oNrdataObjVec[group.first]++;
									neighborNum++;
								}
							}
						}
						else if (group.first == startIndex) {
							for (auto id : group.second) {
								if (id < Tstream.getDataStreamBegin()) {
									break;
								}
								if (id != objId && calculateDistanceById(Tstream, test, id, objId) <= r) {
									groupIndex[group.first]++;
									obj->oNrdataObjVec[group.first]++;
									neighborNum++;
								}
							}
						}
					}
				}
			}
			if (neighborNum < (test.getK() + 0)) {
				changeRMap.emplace(obj->id, targetNode);
			}
			else {
				obj->l_k = test.getR();
				int countNum = test.getK() + 0;
				int lastIndex = PointSet[Tstream.getDataStreamTag() - 1] / dataMapCount;
				for (int i = lastIndex; i >= startIndex; --i) {
					countNum -= groupIndex[i];
					if (countNum <= 0) {
						if (i * dataMapCount < PointSet[obj->id]) {
							obj->warningTime = i * dataMapCount + 1;
						}
						else {
							obj->warningTime = INT_MAX;
						}
						break;
					}
				}
				warningObjMap.emplace(obj->id, obj);
				
			}
			return;
		}
		else {
			obj->l_k = test.getR();
			int countNum = test.getK() + 0;
			int lastIndex = PointSet[Tstream.getDataStreamTag() - 1] / dataMapCount;
			for (int i = lastIndex; i >= startIndex; --i) {
				countNum -= groupIndex[i];
				if (countNum <= 0) {
					if (i * dataMapCount < PointSet[obj->id]) {
						obj->warningTime = i * dataMapCount + 1;
					}
					else {
						obj->warningTime = INT_MAX;
					}
					break;
				}
			}
			warningObjMap.emplace(obj->id, obj);
			return;
		}
	}	
}

void KNode::reFindONr(Tstream& Tstream, Test& test, int& objId, Node* targetNode)
{
	int startIndex = getStartIndex(Tstream, test);
	queue<Node*> queNode;
	queue<Node*> stackNode;
	stackNode.push(targetNode);
	Node* temNode = targetNode;
	double r = test.getR();
	dataObj* obj = new dataObj;
	obj->id = objId;
	obj->oNrdataObjVec.resize(s_changeNum);
	double dis = 0;
	vector<int> groupIndex(s_changeNum);
	int neighborNum = 0;
	addNeighborInIntermediateNode(Tstream, test, obj, targetNode, groupIndex, neighborNum, startIndex);
	if (neighborNum >= (test.getK() + 0)) {
		obj->l_k = test.getR();
		int countNum = test.getK() + 0;
		int lastIndex = PointSet[Tstream.getDataStreamTag() - 1] / dataMapCount;
		for (int i = lastIndex; i >= startIndex; --i) {
			countNum -= groupIndex[i];
			if (countNum <= 0) {
				if (i * dataMapCount < PointSet[obj->id]) {
					obj->warningTime = i * dataMapCount + 1;
				}
				else {
					obj->warningTime = INT_MAX;
				}
				break;
			}
		}
		warningObjMap.emplace(obj->id, obj);
		return;
	}
	else {
		while (temNode->parentNode != nullptr) {
			temNode = temNode->parentNode;
			stackNode.push(temNode);
		}
		while (!stackNode.empty()) {
			if (stackNode.front()->parentNode != nullptr) {
				temNode = stackNode.front()->parentNode;
				for (auto it = temNode->childList.begin(); it != temNode->childList.end(); ++it) {
					if ((*it).second->NodeId != stackNode.front()->NodeId && getMinDisBetweenTwoNode(Tstream, test, (*it).second, targetNode) <= r) {
						queNode.push((*it).second);
					}
				}
			}
			stackNode.pop();
			while (!queNode.empty()) {
				temNode = queNode.front();
				if (temNode->maintainDataNum > 0) {
					addNeighborInIntermediateNode(Tstream, test, obj, temNode, groupIndex, neighborNum, startIndex);
				}
				queNode.pop();
			}
		}
		if (neighborNum < (test.getK() + 0)) {
			changeRMap.emplace(obj->id, targetNode);
			return;
		}
		else {
			obj->l_k = test.getR();
			int countNum = test.getK() + 0;
			int lastIndex = PointSet[Tstream.getDataStreamTag() - 1] / dataMapCount;
			for (int i = lastIndex; i >= startIndex; --i) {
				countNum -= groupIndex[i];
				if (countNum <= 0) {
					if (i * dataMapCount < PointSet[obj->id]) {
						obj->warningTime = i * dataMapCount + 1;
					}
					else {
						obj->warningTime = INT_MAX;
					}
					break;
				}
			}
			warningObjMap.emplace(obj->id, obj);
			return;
		}
	}
}

KNode::Node* removeEmptyNodes(KNode::Node* node) {
	if (!node) {
		return nullptr;
	}
	std::vector<long> emptyChildKeys;
	for (auto& child : node->childList) {
		child.second = removeEmptyNodes(child.second);
		if (!child.second) {
			emptyChildKeys.push_back(child.first);
		}
	}
	for (long key : emptyChildKeys) {
		node->childList.erase(key);
	}
	if (node->maintainDataNum == 0 && node->childList.empty()) {
		return nullptr;
	}
	return node;
}

void KNode::Update(Tstream& Tstream, Test& test)
{
	int dimension = test.getDimension();
	int newEntryId = Tstream.getDataStreamTag();
	clock_t startTime1, endTime1;
	startTime1 = clock();
	int enddddd = Tstream.getS_changeSize() - slideNum;
	int countSize = slideNum;
	int deleteNullNodeCount = slideNum * deleteSize;
	if (deleteNullNodeCount == 0) {
		deleteNullNodeCount = 1;
	}
	bool ffffff = false;
	for (int iii = 0; iii < enddddd; ++iii) {
		ffffff = false;
		if (iii % countSize == 0 && iii != 0)
		{
			endTime1 = clock();
			double time = (double)(endTime1 - startTime1) / CLOCKS_PER_SEC;
			cout << "Current cursor" << Tstream.getDataStreamBegin() << "     Time = " << time << "s" << endl;
			startTime1 = clock();
		}
		Tstream.addDataStreamBegin(Tstream.getS_change(iii));
		Tstream.addDataStreamTag(Tstream.getS_change(SlideIdCount + slideNum));
		if (Tstream.getDataStreamTag() >= Tstream.getVecDataStreamNum(dimension)) {
			break;
		}
		Tstream.addSlideTimes();
		SlideIdCount++;
		newCreateNodeList.clear();
		addNewObjToTree(Tstream, test, newEntryId, Tstream.getDataStreamTag());
		newEntryId = Tstream.getDataStreamTag();
		if (iii % deleteNullNodeCount == 0 && iii != 0) {
			updateNodeInfo(Tstream, test, QDTreeRoot);
			QDTreeRoot = removeEmptyNodes(QDTreeRoot);
			clearWarningObjMap(Tstream, test);
			findKnodeSetInUpdate(Tstream, test, QDTreeRoot);
			ffffff = true;
		}
		changeRMap.clear();
		if (!ffffff) {
			findKNodeForNewCreateNode(Tstream, test);
		}
		updateDealE_IAndE_LNode(Tstream, test);
		int dataNum = calWindowMaintainObjNum(Tstream, test);
		int lowerBound = 0.005 * dataNum;
		int upperBound = 0.02 * dataNum;
		if (changeRMap.size() < lowerBound || changeRMap.size() > upperBound) {
			if (!ffffff) {
				updateNodeInfo(Tstream, test, QDTreeRoot, true);
			}
			checkChangeR(Tstream, test);
		}
		
	}
}

void KNode::addNewObjToTree(Tstream& Tstream, Test& test, int objBeginId, int objEndId)
{
	Node* temNode = nullptr;
	vector<int> vecAddr(test.getDimension(), 0);
	for (int i = objBeginId; i < objEndId; ++i) {
		temNode = QDTreeRoot;
		PointSet[i] = SlideIdCount + slideNum - 1;
		while (true) {
			if (temNode->childList.size() != 0) {
				long addr = findAddrForData(Tstream, test, temNode, i, vecAddr);
				auto findAns = temNode->childList.find(addr);
				if (findAns != temNode->childList.end()) {
					temNode = findAns->second;
				}
				else {
					createNewChildNode(Tstream, test, addr, temNode, i, vecAddr);
					break;
				}
			}
			else {
				int tem = PointSet[i] / dataMapCount;
				if (temNode->dataMap.find(tem) != temNode->dataMap.end()) {
					temNode->dataMap[tem].push_front(i);
				}
				else {
					creatPartition(Tstream, test, i, temNode);
				}
				temNode->maintainDataNum++;
				break;
			}
		}
	}
}

void KNode::createNewChildNode(Tstream& Tstream, Test& test, long& addr, Node* parentNode, int& newObjId, vector<int>& vecAddr)
{
	double treeSide = parentNode->sideLength / 2;
	Node* newChildNode = new Node;
	newChildNode->addr = addr;
	int tem = PointSet[newObjId] / dataMapCount;
	list<int> l;
	l.push_back(newObjId);
	newChildNode->dataMap.emplace(tem, l);
	newChildNode->maintainDataNum++;
	newChildNode->parentNode = parentNode;
	newChildNode->NodeId = NodeIdCount++;
	for (int i = 0; i < test.getDimension(); ++i) {
		newChildNode->vecLeftDown.push_back(parentNode->vecLeftDown[i] + vecAddr[i] * treeSide);
		newChildNode->vecRightUp.push_back(parentNode->vecRightUp[i] - (1 - vecAddr[i]) * treeSide);
	}
	newChildNode->sideLength = newChildNode->vecRightUp[0] - newChildNode->vecLeftDown[0];
	newChildNode->diagonalLength = newChildNode->sideLength * sqrt(test.getDimension());
	parentNode->childList.emplace(addr, newChildNode);
	newCreateNodeList.push_back(newChildNode);
}

void KNode::updateNodeInfo(Tstream& Tstream, Test& test, Node* node)
{
	stack<pair<Node*, bool>> s;
	s.push(make_pair(node, false));
	bool visited;
	Node* temNode = nullptr;
	while (!s.empty()) {
		temNode = s.top().first;
		visited = s.top().second;
		s.pop();
		if (temNode->childList.size() == 0) {
			deleteExpireObj(Tstream, test, temNode->dataMap);
			temNode->maintainDataNum = 0;
			for (auto group : temNode->dataMap) {
				temNode->maintainDataNum += group.second.size();
			}
			if (temNode->maintainDataNum > QDTreeSplitNum && temNode->diagonalLength >= rhoMin * test.getR()) {
				splitTree(Tstream, test, temNode, true);
			}
			continue;
		}
		if (visited) {
			temNode->maintainDataNum = 0;
			for (auto child : temNode->childList) {
				if (child.second->maintainDataNum != 0) {
					temNode->maintainDataNum += child.second->maintainDataNum;
				}
			}
		}
		else {
			s.push(make_pair(temNode, true));
			for (auto child : temNode->childList) {
				s.push(make_pair(child.second, false));
			}
		}
	}
}

void KNode::updateNodeInfo(Tstream& Tstream, Test& test, Node* node, bool changeRflag)
{
	stack<pair<Node*, bool>> s;
	s.push(make_pair(node, false));
	bool visited;
	Node* temNode = nullptr;
	while (!s.empty()) {
		temNode = s.top().first;
		visited = s.top().second;
		s.pop();
		if (temNode->childList.size() == 0) {
			deleteExpireObj(Tstream, test, temNode->dataMap);
			temNode->maintainDataNum = 0;
			for (auto group : temNode->dataMap) {
				temNode->maintainDataNum += group.second.size();
			}
			continue;
		}
		if (visited) {
			temNode->maintainDataNum = 0;
			for (auto child : temNode->childList) {
				if (child.second->maintainDataNum != 0) {
					temNode->maintainDataNum += child.second->maintainDataNum;
				}
			}
		}
		else {
			s.push(make_pair(temNode, true));
			for (auto child : temNode->childList) {
				s.push(make_pair(child.second, false));
			}
		}
	}
}

void KNode::deleteExpireObj(Tstream& Tstream, Test& test, unordered_map<int, list<int>>& dataMap)
{
	int windowBegin = Tstream.getDataStreamBegin();
	int startIndex = getStartIndex(Tstream, test);
	for (auto it = dataMap.begin(); it != dataMap.end();) {
		if (it->first < startIndex) {
			it = dataMap.erase(it);
			continue;
		}
		else if (it->first == startIndex) {
			auto data = it->second.rbegin();
			for (; data != it->second.rend(); ++data) {
				if (*data >= windowBegin) {
					break;
				}
			}
			it->second.erase(data.base(), it->second.end());
			if (it->second.size() == 0) {
				it = dataMap.erase(it);
				continue;
			}
		}
		it++;
	}
}

void KNode::clearWarningObjMap(Tstream& Tstream, Test& test)
{
	int begin = Tstream.getDataStreamBegin();
	dataObj* deleteObj = nullptr;
	for (auto it = warningObjMap.begin(); it != warningObjMap.end();) {
		if (it->first < begin) {
			deleteObj = it->second;
			it = warningObjMap.erase(it);
			delete deleteObj;
			deleteObj = nullptr;
			continue;
		}
		it++;
	}
}

void KNode::findKnodeSetInUpdate(Tstream& Tstream, Test& test, Node* root)
{
	queue<Node*> queNode;
	queNode.push(root);
	Node* temNode = nullptr;
	int k = test.getK();
	list<Node*> newKnodeSet;
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->maintainDataNum > k) {
			if (temNode->childList.size() != 0) {
				for (auto child : temNode->childList) {
					queNode.push(child.second);
				}
			}
		}
		else {
			if (temNode->maintainDataNum != 0) {
				newKnodeSet.push_back(temNode);
			}
			
		}
		queNode.pop();
	}
	checkNewKnodeSet(Tstream, test, newKnodeSet);
	KnodeSmall.clear();
	KnodeLarge.clear();
	E_I.clear();
	E_L.clear();
	double threshold = (1 + test.getrho()) * test.getR() / 2;
	for (auto KNode : newKnodeSet) {
		if (KNode->diagonalLength <= threshold) {
			KnodeSmall.push_back(KNode);
		}
		else {
			KnodeLarge.push_back(KNode);
		}
	}
	findE_IAndE_lInKnodeLarge(Tstream, test);
}

void KNode::checkNewKnodeSet(Tstream& Tstream, Test& test, list<Node*>& newKnodeSet)
{
	list<Node*> finallKnodeSet;
	unordered_map<int, Node*> oldKnodeMap;
	list<Node*> changeKnodeFlag;
	for (auto newKnode = newKnodeSet.begin(); newKnode != newKnodeSet.end(); ++newKnode) {
		if (!(*newKnode)->KnodeFlag) {
			Node* oldKnode = nullptr;
			if (judgeNewKnodeInfo(Tstream, test, *newKnode, oldKnode)) {
				if (oldKnode->maintainDataNum > (test.getK() * 2 + 1)) {
					changeKnodeFlag.push_back(oldKnode);
					(*newKnode)->KnodeFlag = true;
					if ((*newKnode)->NNl_uk.size() == 0 && (*newKnode)->NNl_ukSmall.size() == 0) {
						createNNl_ukByOldKnodeForNewKnode(Tstream, test, *newKnode, oldKnode);
					}
					finallKnodeSet.push_back(*newKnode);
				}
				else {
					if (oldKnodeMap.find(oldKnode->NodeId) == oldKnodeMap.end()) {
						oldKnodeMap.emplace(oldKnode->NodeId, oldKnode);
					}
				}
			}
			else {
				(*newKnode)->KnodeFlag = true;
				if ((*newKnode)->childList.size() == 0) {
					if ((*newKnode)->NNl_uk.size() == 0 && (*newKnode)->NNl_ukSmall.size() == 0) {
						createNodeNNl(Tstream, test, (*newKnode));
					}
				}
				else {
					if ((*newKnode)->NNl_uk.size() == 0 && (*newKnode)->NNl_ukSmall.size() == 0) {
						changeKnodeInfo(Tstream, test, *newKnode);
					}
					else {
						changeKnodeInfo(Tstream, test, *newKnode, true);
					}
				}
				finallKnodeSet.push_back(*newKnode);
			}
		}
		else {
			finallKnodeSet.push_back(*newKnode);
		}

	}
	for (auto it : oldKnodeMap) {
		finallKnodeSet.push_back(it.second);
	}
	for (auto it : changeKnodeFlag) {
		it->KnodeFlag = false;
	}
	newKnodeSet.clear();
	newKnodeSet = finallKnodeSet;
}

bool KNode::judgeNewKnodeInfo(Tstream& Tstream, Test& test, Node* newKnode, Node*& oldKnode)
{
	bool flag = false;
	Node* temNode = newKnode->parentNode;
	while (temNode->parentNode != nullptr) {
		if (temNode->KnodeFlag) {
			oldKnode = temNode;
			return true;
		}
		temNode = temNode->parentNode;
	}
	return false;
}

void KNode::createNNl_ukByOldKnodeForNewKnode(Tstream& Tstream, Test& test, Node* newKnode, Node* oldKnode)
{
	double dis;
	double u_k = 2 * newKnode->diagonalLength;
	int k = test.getK();
	double r = test.getR();
	queue<Node*> queNode;
	for (auto it = oldKnode->NNl_ukSmall.begin(); it != oldKnode->NNl_ukSmall.end();) {
		if ((*it).second->maintainDataNum == 0) {
			it = oldKnode->NNl_ukSmall.erase(it);
			continue;
		}
		dis = getMinDisBetweenTwoNode(Tstream, test, (*it).second, newKnode);
		if (dis <= u_k) {
			if ((*it).second->childList.size() != 0) {
				queNode.push((*it).second);
			}
			else {
				newKnode->NNl_ukSmall.emplace((*it).second->NodeId, (*it).second);
			}
		}
		it++;
	}
	for (auto it = oldKnode->NNl_uk.begin(); it != oldKnode->NNl_uk.end();) {
		if ((*it).second->maintainDataNum == 0) {
			it = oldKnode->NNl_uk.erase(it);
			continue;
		}
		dis = getMinDisBetweenTwoNode(Tstream, test, (*it).second, newKnode);
		if (dis <= u_k) {
			if ((*it).second->childList.size() != 0) {
				queNode.push((*it).second);
			}
			else {
				newKnode->NNl_uk.emplace((*it).second->NodeId, (*it).second);
			}
		}
		it++;
	}
	if ((newKnode->NNl_uk.size() + newKnode->NNl_ukSmall.size()) >= lambda * k) {
		return;
	}
	Node* temNode = nullptr;
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				if (getMinDisBetweenTwoNode(Tstream, test, child.second, newKnode) <= u_k) {
					queNode.push(child.second);
				}
			}
		}
		else {
			if (temNode->diagonalLength <= (NNl_ukSmallSize * r)) {
				newKnode->NNl_ukSmall.emplace(temNode->NodeId, temNode);
			}
			else {
				newKnode->NNl_uk.emplace(temNode->NodeId, temNode);
			}
			if ((newKnode->NNl_uk.size() + newKnode->NNl_ukSmall.size()) >= lambda * k) {
				return;
			}
		}
		queNode.pop();
	}
}

void KNode::changeKnodeInfo(Tstream& Tstream, Test& test, Node* newKnode)
{
	queue<Node*> queNode;
	queNode.push(newKnode);
	Node* temNode = nullptr;
	map<int, Node*, greater<int>> map;
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				if (child.second->KnodeFlag) {
					map.emplace(child.second->NNl_uk.size() + child.second->NNl_ukSmall.size(), child.second);
					child.second->KnodeFlag = false;
				}
				else {
					queNode.push(child.second);
				}
			}
		}
		else {
			if (temNode->KnodeFlag) {
				map.emplace(temNode->NNl_uk.size() + temNode->NNl_ukSmall.size(), temNode);
				temNode->KnodeFlag = false;
			}
		}
		queNode.pop();
	}
	if (map.size() == 0) {
		createNodeNNl(Tstream, test, newKnode);
	}
	else {
		newKnode->NNl_uk = map.begin()->second->NNl_uk;
		newKnode->NNl_ukSmall = map.begin()->second->NNl_ukSmall;
	}
}

void KNode::changeKnodeInfo(Tstream& Tstream, Test& test, Node* newKnode, bool flag)
{
	queue<Node*> queNode;
	queNode.push(newKnode);
	Node* temNode = nullptr;
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				if (child.second->KnodeFlag) {
					child.second->KnodeFlag = false;
				}
				else {
					queNode.push(child.second);
				}
			}
		}
		else {
			if (temNode->KnodeFlag) {
				temNode->KnodeFlag = false;
			}
		}
		queNode.pop();
	}
}

void KNode::findKNodeForNewCreateNode(Tstream& Tstream, Test& test)
{
	int flag = 0;
	double threshold = (1 + test.getrho()) * test.getR() / 2;
	list<Node*> newKnodeLarge;
	for (auto newNode : newCreateNodeList) {
		flag = 0;
		Node* KNode = newNode;
		while (KNode != nullptr) {
			if (E_I.find(KNode->NodeId) != E_I.end()) {
				flag = 2;
				break;
			}
			if (KNode->KnodeFlag) {
				flag = 1;
				break;
			}
			KNode = KNode->parentNode;
		}
		if (flag==0) {
			if (newNode->maintainDataNum > test.getK()) {
				splitTree(Tstream, test, newNode, true);
				createNodeNNl(Tstream, test, newNode);
				findNewKnodeLargeInNewNode(Tstream, test, newNode, newKnodeLarge);
			}
			else {
				newNode->KnodeFlag = true;
				createNodeNNl(Tstream, test, newNode);
				if (newNode->diagonalLength <= threshold) {
					KnodeSmall.push_back(newNode);
				}
				else {
					newKnodeLarge.push_back(newNode);
				}
			}
		}
		else {
			if (flag == 1 && KNode->diagonalLength > threshold) {
				if (newNode->maintainDataNum > test.getK()) {
					splitTree(Tstream, test, newNode, true);
					createNodeNNl(Tstream, test, newNode);
					findNewKnodeLargeInNewNode(Tstream, test, newNode, newKnodeLarge);
				}
				else {
					createNodeNNl(Tstream, test, newNode);
					if (newNode->diagonalLength <= threshold) {
						KnodeSmall.push_back(newNode);
					}
					else {
						newKnodeLarge.push_back(newNode);
					}
				}
			}
		}
	}
	findE_IAndE_lInKnodeLarge(Tstream, test, newKnodeLarge);
}

void KNode::findNewKnodeLargeInNewNode(Tstream& Tstream, Test& test, Node* newNode, list<Node*>& newKnodeLarge)
{
	queue<Node*> queNode;
	queNode.push(newNode);
	Node* temNode = nullptr;
	int k = test.getK();
	double threshold = (1 + test.getrho()) * test.getR() / 2;
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->maintainDataNum > k) {
			if (temNode->childList.size() != 0) {
				for (auto child : temNode->childList) {
					queNode.push(child.second);
				}
			}
		}
		else {
			temNode->KnodeFlag = true;
			if (temNode->diagonalLength <= threshold) {
				KnodeSmall.push_back(temNode);
				createNNl_ukByOldKnodeForNewKnode(Tstream, test, temNode, newNode);
			}
			else {
				newKnodeLarge.push_back(temNode);
				createNNl_ukByOldKnodeForNewKnode(Tstream, test, temNode, newNode);
			}
		}
		queNode.pop();
	}
}

void KNode::updateDealE_IAndE_LNode(Tstream& Tstream, Test& test)
{
	double r = test.getR();
	int startIndex = getStartIndex(Tstream, test);
	int dataStreamBegin = Tstream.getDataStreamBegin();
	int endSlideIdCount = (SlideIdCount - slideNum + 1) > 0 ? (SlideIdCount - slideNum + 1) : 0;
	for (auto nodeInE_I : E_I) {
		if (nodeInE_I.second->l_kup > r || nodeInE_I.second->warningTime <= SlideIdCount) {
			updateTightenl_kup(Tstream, test, nodeInE_I.second, test.getR());
			if (nodeInE_I.second->l_kup > r) {
				printOutlier(Tstream, test, nodeInE_I.second);
			}
			updateParentNodel_kupAnde_t(Tstream, test, nodeInE_I.second);
		}
	}
	for (auto nodeInE_L : E_L) {
		if (nodeInE_L.second->diagonalLength> findl_kupThreshold) {
			for (auto group : nodeInE_L.second->dataMap) {
				if (group.first >= startIndex) {
					for (auto id : group.second) {
						if (id >= dataStreamBegin) {
							auto it = warningObjMap.find(id);
							if (it != warningObjMap.end()) {
								if (it->second->l_k > r || it->second->warningTime <= SlideIdCount) {
									reSetl_kupForObj(Tstream, test, it->second, nodeInE_L.second);
								}
							}
							else {
								createONrByNode(Tstream, test, id, nodeInE_L.second);
							}
						}
					}
				}
			}
		}
		else {
			if (nodeInE_L.second->l_kup <= r && ((nodeInE_L.second->l_kup + 2 * nodeInE_L.second->diagonalLength) <= (1 + test.getrho()) * r)) {
				if (nodeInE_L.second->warningTime <= SlideIdCount) {
					updateTightenl_kup(Tstream, test, nodeInE_L.second, test.getR());
					if (nodeInE_L.second->l_kup > r) {
						printOutlier(Tstream, test, nodeInE_L.second);
					}
					updateParentNodel_kupAnde_t(Tstream, test, nodeInE_L.second);
				}
			}
			else {
				updateTightenl_kup(Tstream, test, nodeInE_L.second, (1 + test.getrho()) * r - 2 * nodeInE_L.second->diagonalLength);
				if (nodeInE_L.second->l_kup > r) {
					printOutlier(Tstream, test, nodeInE_L.second);
				}
				updateParentNodel_kupAnde_t(Tstream, test, nodeInE_L.second);
				if (nodeInE_L.second->l_kup <= r && (nodeInE_L.second->l_kup + 2 * nodeInE_L.second->diagonalLength) > (1 + test.getrho()) * r) {
					for (auto group : nodeInE_L.second->dataMap) {
						if (group.first >= startIndex) {
							for (auto id : group.second) {
								if (id >= dataStreamBegin) {
									auto it = warningObjMap.find(id);
									if (it != warningObjMap.end()) {
										if (it->second->l_k > r || it->second->warningTime <= SlideIdCount) {
											reSetl_kupForObj(Tstream, test, it->second, nodeInE_L.second);
										}
									}
									else {
										createONrByNode(Tstream, test, id, nodeInE_L.second);
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

void KNode::updateTightenl_kup(Tstream& Tstream, Test& test, Node* node, double l_kthreshold)
{
	Node* kNode = node;
	while (!kNode->KnodeFlag) {
		kNode = kNode->parentNode;
	}
	multimap<double, int> knnMap;
	double dis = 0;
	double minDis = DBL_MAX;
	double r = test.getR();
	vector<int> indexVec(s_changeNum);
	int startIndex = getStartIndex(Tstream, test);
	int begin = Tstream.getDataStreamBegin();
	bool flag = false;
	for (auto it = kNode->NNl_ukSmall.begin(); it != kNode->NNl_ukSmall.end();) {
		if (minDis <= l_kthreshold) {
			break;
		}
		if ((*it).second->maintainDataNum != 0) {
			if ((*it).second->childList.size() != 0) {
				reSetl_kupInIntermediateNode(Tstream, test, node, (*it).second, knnMap, indexVec, minDis, l_kthreshold);
			}
			else {
				flag = false;
				dis = getMinDisBetweenTwoNode(Tstream, test, node, (*it).second);
				if (dis < minDis) {
					for (auto group = (*it).second->dataMap.begin(); group != (*it).second->dataMap.end();) {
						if (flag) {
							break;
						}
						if (group->first < startIndex) {
							group = (*it).second->dataMap.erase(group);
							continue;
						}
						for (auto id = group->second.begin(); id != group->second.end(); ++id) {
							if (*id < begin) {
								break;
							}
							if (dis < minDis) {
								knnMap.emplace(dis, group->first);
								indexVec[group->first]++;
								if (knnMap.size() > (test.getK() + 1)) {
									auto tem = knnMap.end();
									tem--;
									indexVec[tem->second]--;
									knnMap.erase(tem);
									minDis = knnMap.rbegin()->first;
								}
							}
							else {
								flag = true;
								break;
							}
						}
						group++;
					}
				}
			}
		}
		else {
			it = kNode->NNl_ukSmall.erase(it);
			continue;
		}
		it++;
	}
	for (auto it = kNode->NNl_uk.begin(); it != kNode->NNl_uk.end();) {
		if (minDis <= l_kthreshold) {
			break;
		}
		if ((*it).second->maintainDataNum != 0) {
			if ((*it).second->childList.size() != 0) {
				reSetl_kupInIntermediateNode(Tstream, test, node, (*it).second, knnMap, indexVec, minDis, l_kthreshold);
			}
			else {
				flag = false;
				dis = getMinDisBetweenTwoNode(Tstream, test, node, (*it).second);
				if (dis < minDis) {
					for (auto group = (*it).second->dataMap.begin(); group != (*it).second->dataMap.end();) {
						if (flag) {
							break;
						}
						if (group->first < startIndex) {
							group = (*it).second->dataMap.erase(group);
							continue;
						}
						else {
							for (auto id = group->second.begin(); id != group->second.end(); ++id) {
								if (*id < begin) {
									break;
								}
								if (dis < minDis) {
									knnMap.emplace(dis, group->first);
									indexVec[group->first]++;
									if (knnMap.size() > (test.getK() + 1)) {
										auto tem = knnMap.end();
										tem--;
										indexVec[tem->second]--;
										knnMap.erase(tem);
										minDis = knnMap.rbegin()->first;
									}
								}
								else {
									flag = true;
									break;
								}
							}
						}
						group++;
					}
				}
			}
		}
		else {
			it = kNode->NNl_uk.erase(it);
			continue;
		}
		it++;
	}
	if (minDis <= r) {
		node->l_kup = knnMap.rbegin()->first;
		for (int i = SlideIdCount / dataMapCount; i < indexVec.size(); ++i) {
			if (indexVec[i] != 0) {
				node->warningTime = i * dataMapCount + 1;
				break;
			}
		}
	}
	else {
		reCall_kupOfNode(Tstream, test, node, kNode, l_kthreshold);
	}
}

void KNode::reSetl_kupInIntermediateNode(Tstream& Tstream, Test& test, Node* targetNode, Node* intermediateNode, multimap<double, int>& knnMap, vector<int>& indexVec, double& minDis, double l_kthreshold)
{
	queue<Node*> queNode;
	queNode.push(intermediateNode);
	Node* temNode = nullptr;
	double dis = 0;
	int startIndex = getStartIndex(Tstream, test);
	int begin = Tstream.getDataStreamBegin();
	bool flag = false;
	while (!queNode.empty()) {
		if (minDis <= l_kthreshold) {
			break;
		}
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				if (getMinDisBetweenTwoNode(Tstream, test, targetNode, child.second) < minDis) {
					queNode.push(child.second);
				}
			}
		}
		else {
			flag = false;
			dis = getMinDisBetweenTwoNode(Tstream, test, targetNode, temNode);
			for (auto group = temNode->dataMap.begin(); group != temNode->dataMap.end();) {
				if (flag) {
					break;
				}
				if (group->first < startIndex) {
					group = temNode->dataMap.erase(group);
					continue;
				}
				else {
					for (auto id = group->second.begin(); id != group->second.end(); ++id) {
						if (*id < begin) {
							break;
						}
						if (dis < minDis) {
							knnMap.emplace(dis, group->first);
							indexVec[group->first]++;
							if (knnMap.size() > (test.getK() + 1)) {
								auto tem = knnMap.end();
								tem--;
								indexVec[tem->second]--;
								knnMap.erase(tem);
								minDis = knnMap.rbegin()->first;
							}
						}
						else {
							flag = true;
							break;
						}
					}
				}
				group++;
			}
		}
		queNode.pop();
	}
}

void KNode::reSetl_kupInIntermediateNode(Tstream& Tstream, Test& test, Node* targetNode, Node* intermediateNode, multimap<double, int>& knnMap, vector<int>& indexVec, double& minDis, double l_kthreshold, unordered_map<int, Node*>& leafNodeMap)
{
	queue<Node*> queNode;
	queNode.push(intermediateNode);
	double dis = 0;
	Node* temNode = nullptr;
	int startIndex = getStartIndex(Tstream, test);
	int begin = Tstream.getDataStreamBegin();
	bool flag = false;
	while (!queNode.empty()) {
		if (minDis <= l_kthreshold) {
			break;
		}
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				if (getMinDisBetweenTwoNode(Tstream, test, targetNode, child.second) < minDis) {
					queNode.push(child.second);
				}
			}
		}
		else {
			flag = false;
			dis = getMinDisBetweenTwoNode(Tstream, test, targetNode, temNode);
			for (auto group = temNode->dataMap.begin(); group != temNode->dataMap.end();) {
				if (flag) {
					break;
				}
				if (group->first < startIndex) {
					group = temNode->dataMap.erase(group);
					continue;
				}
				else {
					for (auto neighborId = group->second.begin(); neighborId != group->second.end(); ++neighborId) {
						if (*neighborId < begin) {
							break;
						}
						if (dis < minDis) {
							knnMap.emplace(dis, group->first);
							indexVec[group->first]++;
							if (dis <= test.getR() && leafNodeMap.find(temNode->NodeId) == leafNodeMap.end()) {
								leafNodeMap.emplace(temNode->NodeId, temNode);
							}
							if (knnMap.size() > (test.getK() + 1)) {
								auto tem = knnMap.end();
								tem--;
								indexVec[tem->second]--;
								knnMap.erase(tem);
								minDis = knnMap.rbegin()->first;
							}
						}
						else {
							flag = true;
							break;
						}
					}
				}
				group++;
			}
		}
		queNode.pop();
	}
}

void KNode::reCall_kupOfNode(Tstream& Tstream, Test& test, Node* node, Node* kNode, double l_kthreshold)
{
	queue<Node*> queNode;
	queNode.push(QDTreeRoot);
	Node* temNode = nullptr;
	double dis = 0;
	double r = test.getR();
	int k = test.getK();
	unordered_multimap<double, Node*> NNr;
	int totalObjnum = 0;
	int startIndex = getStartIndex(Tstream, test);
	int begin = Tstream.getDataStreamBegin();
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->maintainDataNum != 0) {
			dis = getMinDisBetweenTwoNode(Tstream, test, temNode, node);
			if (dis <= r) {
				if (temNode->diagonalLength == node->diagonalLength) {
					NNr.emplace(dis, temNode);
					totalObjnum += temNode->maintainDataNum;
				}
				else {
					if (temNode->childList.size() != 0) {
						for (auto child : temNode->childList) {
							if (getMinDisBetweenTwoNode(Tstream, test, child.second, node) <= r) {
								queNode.push(child.second);
							}
						}
					}
					else {
						NNr.emplace(dis, temNode);
						totalObjnum += temNode->maintainDataNum;
					}
				}
			}
		}
		queNode.pop();
	}
	if (totalObjnum >= (k + 1)) {
		multimap<double, int> knnMap;
		unordered_map<int, Node*> leafNodeMap;
		vector<int> indexVec(s_changeNum);
		double dis = 0;
		double minDis = DBL_MAX;
		bool flag = false;
		for (auto nodeInNNr : NNr) {
			if (minDis <= l_kthreshold) {
				break;
			}
			dis = getMinDisBetweenTwoNode(Tstream, test, node, nodeInNNr.second);
			if (dis < minDis) {
				if (nodeInNNr.second->childList.size() != 0) {
					reSetl_kupInIntermediateNode(Tstream, test, node, nodeInNNr.second, knnMap, indexVec, minDis, l_kthreshold, leafNodeMap);
				}
				else {
					flag = false;
					if (dis < minDis) {
						for (auto group = nodeInNNr.second->dataMap.begin(); group != nodeInNNr.second->dataMap.end();) {
							if (flag) {
								break;
							}
							if (group->first < startIndex) {
								group = nodeInNNr.second->dataMap.erase(group);
								continue;
							}
							else {
								for (auto id = group->second.begin(); id != group->second.end(); ++id) {
									if (*id < begin) {
										break;
									}
									if (dis < minDis) {
										knnMap.emplace(dis, group->first);
										indexVec[group->first]++;
										if (dis <= r && leafNodeMap.find(nodeInNNr.second->NodeId) == leafNodeMap.end()) {
											leafNodeMap.emplace(nodeInNNr.second->NodeId, nodeInNNr.second);
										}
										if (knnMap.size() > (k + 1)) {
											auto tem = knnMap.end();
											tem--;
											indexVec[tem->second]--;
											knnMap.erase(tem);
											minDis = knnMap.rbegin()->first;
										}
									}
									else {
										flag = true;
										break;
									}
								}
							}
							group++;
						}
					}
				}
			}
		}
		if (knnMap.size() >= (k + 1)) {
			node->l_kup = knnMap.rbegin()->first;
			for (int i = SlideIdCount / dataMapCount; i < indexVec.size(); ++i) {
				if (indexVec[i] != 0) {
					node->warningTime = i * dataMapCount + 1;
					break;
				}
			}
			for (auto leafNode : leafNodeMap) {
				if (leafNode.second->maintainDataNum != 0) {
					if (leafNode.second->diagonalLength <= (NNl_ukSmallSize * r)) {
						if (kNode->NNl_ukSmall.find(leafNode.second->NodeId) == kNode->NNl_ukSmall.end()) {
							if (kNode->NNl_ukSmall.size() >= lambda * test.getK()) {
								kNode->NNl_ukSmall.erase(kNode->NNl_ukSmall.begin());
								kNode->NNl_ukSmall.emplace(leafNode.second->NodeId, leafNode.second);
							}
							else {
								kNode->NNl_uk.emplace(leafNode.second->NodeId, leafNode.second);
							}
						}
					}
					else {
						if (kNode->NNl_uk.find(leafNode.second->NodeId) == kNode->NNl_uk.end()) {
							if (kNode->NNl_uk.size() >= lambda * test.getK()) {
								kNode->NNl_uk.erase(kNode->NNl_uk.begin());
								kNode->NNl_uk.emplace(leafNode.second->NodeId, leafNode.second);
							}
							else {
								kNode->NNl_uk.emplace(leafNode.second->NodeId, leafNode.second);
							}
						}
					}
				}
			}
		}
		else {
			node->warningTime = SlideIdCount + 1;
		}
	}
	else {
		node->warningTime = SlideIdCount + 1;
	}
}

void KNode::reSetl_kupForObj(Tstream& Tstream, Test& test, dataObj* Obj, Node* targetNode)
{
	vector<int> groupIndex(s_changeNum);
	int neighborNum = 0;
	for (auto norNode = Obj->oNrNodeList.begin(); norNode != Obj->oNrNodeList.end();) {
		if (neighborNum >= test.getK()) {
			break;
		}
		if ((*norNode)->maintainDataNum != 0) {
			{
				if (getMinDisToNode(Tstream, test, Obj->id, *norNode) <= test.getR() && getMaxDisToNode(Tstream, test, Obj->id, *norNode) <= ((1 + test.getrho()) * test.getR())) {
					findObjl_kInNode(Tstream, test, *norNode, groupIndex, neighborNum);
				}
				else {
					norNode = Obj->oNrNodeList.erase(norNode);
					continue;
				}
			}
		}
		else {
			norNode = Obj->oNrNodeList.erase(norNode);
			continue;
		}
		norNode++;
	}
	int lastIndex = PointSet[Tstream.getDataStreamTag() - 1] / dataMapCount;
	int startIndex = getStartIndex(Tstream, test);
	if (Obj->oNrdataObjVec.size() != 0) {
		for (auto temIndex = startIndex + 1; temIndex <= lastIndex; ++temIndex) {
			groupIndex[temIndex] += Obj->oNrdataObjVec[temIndex];
			neighborNum += Obj->oNrdataObjVec[temIndex];
		}
	}
	if (neighborNum >= test.getK()) {
		Obj->l_k = test.getR();
		int countNum = test.getK() + 0;
		for (int i = lastIndex; i >= startIndex; --i) {
			countNum -= groupIndex[i];
			if (countNum <= 0) {
				if (i * dataMapCount < PointSet[Obj->id]) {
					Obj->warningTime = i * dataMapCount + 1;
				}
				else {
					Obj->warningTime = INT_MAX;
				}
				break;
			}
		}
	}
	else {
		warningObjMap.erase(Obj->id);
		int temid = Obj->id;
		delete Obj;
		createONrByNode(Tstream, test, temid, targetNode);
	}
}

void KNode::reSetl_kupForObj(Tstream& Tstream, Test& test, dataObj* Obj, Node* targetNode, bool changeR)
{
	vector<int> groupIndex(s_changeNum);
	int neighborNum = 0;
	for (auto norNode = Obj->oNrNodeList.begin(); norNode != Obj->oNrNodeList.end();) {
		if (neighborNum >= test.getK()) {
			break;
		}
		if ((*norNode)->maintainDataNum != 0) {
			{
				if (getMinDisToNode(Tstream, test, Obj->id, *norNode) <= test.getR() && getMaxDisToNode(Tstream, test, Obj->id, *norNode) <= ((1 + test.getrho()) * test.getR())) {
					findObjl_kInNode(Tstream, test, *norNode, groupIndex, neighborNum);
				}
				else {
					norNode = Obj->oNrNodeList.erase(norNode);
					continue;
				}
			}
		}
		else {
			norNode = Obj->oNrNodeList.erase(norNode);
			continue;
		}
		norNode++;
	}
	int lastIndex = PointSet[Tstream.getDataStreamTag() - 1] / dataMapCount;
	int startIndex = getStartIndex(Tstream, test);
	if (neighborNum >= test.getK()) {
		Obj->l_k = test.getR();
		int countNum = test.getK() + 0;
		for (int i = lastIndex; i >= startIndex; --i) {
			countNum -= groupIndex[i];
			if (countNum <= 0) {
				if (i * dataMapCount < PointSet[Obj->id]) {
					Obj->warningTime = i * dataMapCount + 1;
				}
				else {
					Obj->warningTime = INT_MAX;
				}
				break;
			}
		}
	}
	else {
		warningObjMap.erase(Obj->id);
		int temid = Obj->id;
		delete Obj;
		createONrByNode(Tstream, test, temid, targetNode);
	}
}

void KNode::findObjl_kInNode(Tstream& Tstream, Test& test, Node* node, vector<int>& groupIndex, int& neighborNum)
{
	queue<Node*> queNode;
	queNode.push(node);
	Node* temNode = nullptr;
	int startIndex = getStartIndex(Tstream, test);
	int windowBegin = Tstream.getDataStreamBegin();
	while (!queNode.empty()) {
		if (neighborNum >= (test.getK() + 0)) {
			break;
		}
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				if (child.second->maintainDataNum != 0) {
					queNode.push(child.second);
				}
			}
		}
		else {
			for (auto group = temNode->dataMap.begin(); group != temNode->dataMap.end();) {
				if (neighborNum >= (test.getK())) {
					break;
				}
				if (group->first > startIndex) {
					groupIndex[group->first] += group->second.size();
					neighborNum += group->second.size();
				}
				else if (group->first == startIndex) {
					auto dataobj = group->second.rbegin();
					for (; dataobj != group->second.rend(); ++dataobj) {
						if (*dataobj >= windowBegin) {
							break;
						}
					}
					group->second.erase(dataobj.base(), group->second.end());
					if (group->second.size() == 0) {
						group = temNode->dataMap.erase(group);
						continue;
					}
					else {
						groupIndex[group->first] += group->second.size();
						neighborNum += group->second.size();
					}
				}
				else {
					group = temNode->dataMap.erase(group);
					continue;
				}
				group++;
			}
		}
		queNode.pop();
	}
}

int KNode::getPosIndex(Tstream& Tstream, Test& test)
{
	return (SlideIdCount + slideNum  / 2) / dataMapCount;
}

int KNode::getStartIndex(Tstream& Tstream, Test& test)
{
	return SlideIdCount / dataMapCount;
}

void KNode::creatPartition(Tstream& Tstream, Test& test, int dataId, Node* targetNode)
{
	list<int> l;
	int tem = PointSet[dataId] / dataMapCount;
	l.push_back(dataId);
	targetNode->dataMap.emplace(tem, l);
}

void KNode::setfindl_kupThreshold(Tstream& Tstream, Test& test)
{
	findl_kupThreshold = (1 + test.getrho()) * test.getR() / 2;
}

void KNode::reFindInkNode(Tstream& Tstream, Test& test, dataObj* obj, Node* targetNode, Node* kNode, vector<int>& groupIndex, int& neighborNum, int& endIndex)
{
	double r = test.getR();
	int startIndex = getStartIndex(Tstream, test);
	for (auto it = kNode->NNl_ukSmall.begin(); it != kNode->NNl_ukSmall.end();) {
		if (neighborNum >= test.getK()) {
			break;
		}
		if (getMinDisToNode(Tstream, test, obj->id, it->second) <= r && getMaxDisToNode(Tstream, test, obj->id, it->second) <= (1 + test.getrho()) * r) {
			addRhoNeighbor(Tstream, test, it->second, obj, groupIndex, neighborNum, startIndex, endIndex);
		}
		else {
			addNeighborInNode(Tstream, test, obj, it->second, groupIndex, neighborNum);
		}
		it++;
	}
	for (auto it = kNode->NNl_uk.begin(); it != kNode->NNl_uk.end();) {
		if (neighborNum >= test.getK()) {
			break;
		}
		if (getMinDisToNode(Tstream, test, obj->id, it->second) <= r && getMaxDisToNode(Tstream, test, obj->id, it->second) <= (1 + test.getrho()) * r) {
			addRhoNeighbor(Tstream, test, it->second, obj, groupIndex, neighborNum, startIndex, endIndex);
		}
		else {
			addNeighborInNode(Tstream, test, obj, it->second, groupIndex, neighborNum);
		}
		it++;
	}
	if (neighborNum < test.getK()) {
		int objId = obj->id;
		delete obj;
		reFindONr(Tstream, test, objId, targetNode, endIndex);
	}
	else {
		obj->l_k = test.getR();
		int countNum = test.getK() + 0;
		int lastIndex = PointSet[Tstream.getDataStreamTag() - 1] / dataMapCount;
		for (int i = lastIndex; i >= startIndex; --i) {
			countNum -= groupIndex[i];
			if (countNum <= 0) {
				if (i * dataMapCount < PointSet[obj->id]) {
					obj->warningTime = i * dataMapCount + 1;
				}
				else {
					obj->warningTime = INT_MAX;
				}
				break;
			}
		}
		warningObjMap.emplace(obj->id, obj);
	}
}

void KNode::addNeighborInNode(Tstream& Tstream, Test& test, dataObj* obj, Node* node, vector<int>& groupIndex, int& neighborNum)
{
	queue<Node*> queNode;
	queNode.push(node);
	Node* temNode = nullptr;
	double r = test.getR();
	int startIndex = getStartIndex(Tstream, test);
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				if (child.second->maintainDataNum != 0 && getMinDisToNode(Tstream, test, obj->id, child.second) <= r) {
					queNode.push(child.second);
				}
			}
		}
		else {
			for (auto group = temNode->dataMap.begin(); group != temNode->dataMap.end();) {
				if (neighborNum >= test.getK()) {
					break;
				}
				if (group->first > startIndex) {
					for (auto id : group->second) {
						if (calculateDistanceById(Tstream, test, id, obj->id) <= r) {
							groupIndex[group->first]++;
							obj->oNrdataObjVec[group->first]++;
							neighborNum++;
						}
					}
				}
				else if (group->first == startIndex) {
					for (auto id : group->second) {
						if (id < Tstream.getDataStreamBegin()) {
							break;
						}
						if (calculateDistanceById(Tstream, test, id, obj->id) <= r) {
							groupIndex[group->first]++;
							obj->oNrdataObjVec[group->first]++;
							neighborNum++;
						}
					}
				}
				else {
					group = temNode->dataMap.erase(group);
					continue;
				}
				group++;
			}
		}
		queNode.pop();
	}
}

void KNode::addNeighborInIntermediateNode(Tstream& Tstream, Test& test, dataObj* obj, Node* node, vector<int>& groupIndex, int& neighborNum, int& posIndex)
{
	queue<Node*> queNode;
	queNode.push(node);
	Node* temNode = nullptr;
	double r = test.getR();
	int startIndex = getStartIndex(Tstream, test);
	while (!queNode.empty()) {
		if (neighborNum >= (test.getK() + 0)) {
			break;
		}
		temNode = queNode.front();
		if (temNode->maintainDataNum != 0) {
			if (getMinDisToNode(Tstream, test, obj->id, temNode) <= r && getMaxDisToNode(Tstream, test, obj->id, temNode) <= (1 + test.getrho()) * r) {
				obj->oNrNodeList.push_back(temNode);
				addRhoNeighbor(Tstream, test, temNode, obj, groupIndex, neighborNum, posIndex);
			}
			else {
				if (temNode->childList.size() != 0) {
					for (auto child : temNode->childList) {
						if (child.second->maintainDataNum != 0 && getMinDisToNode(Tstream, test, obj->id, child.second) <= r) {
							queNode.push(child.second);
						}
					}
				}
				else {
					for (auto group : temNode->dataMap) {
						if (neighborNum >= (test.getK() + 0)) {
							break;
						}
						if (group.first > posIndex) {
							for (auto id : group.second) {
								if (id != obj->id && calculateDistanceById(Tstream, test, id, obj->id) <= r) {
									groupIndex[group.first]++;
									obj->oNrdataObjVec[group.first]++;
									neighborNum++;
								}
							}
						}
						else if (group.first == posIndex) {
							for (auto id : group.second) {
								if (id < Tstream.getDataStreamBegin()) {
									break;
								}
								if (id != obj->id && calculateDistanceById(Tstream, test, id, obj->id) <= r) {
									groupIndex[group.first]++;
									obj->oNrdataObjVec[group.first]++;
									neighborNum++;
								}
							}
						}
					}
				}
			}
		}
		queNode.pop();
	}
}

void KNode::addNeighborInIntermediateNode(Tstream& Tstream, Test& test, dataObj* obj, Node* node, vector<int>& groupIndex, int& neighborNum, int& posIndex, list<Node*>& NodeList)
{
	queue<Node*> queNode;
	queNode.push(node);
	Node* temNode = nullptr;
	double r = test.getR();
	int startIndex = getStartIndex(Tstream, test);
	while (!queNode.empty()) {
		if (neighborNum >= (test.getK() + 0)) {
			break;
		}
		temNode = queNode.front();
		if (temNode->maintainDataNum != 0) {
			if (getMinDisToNode(Tstream, test, obj->id, temNode) <= r && getMaxDisToNode(Tstream, test, obj->id, temNode) <= (1 + test.getrho()) * r) {
				obj->oNrNodeList.push_back(temNode);
				addRhoNeighbor(Tstream, test, temNode, obj, groupIndex, neighborNum, posIndex);
			}
			else {
				if (temNode->childList.size() != 0) {
					for (auto child : temNode->childList) {
						if (child.second->maintainDataNum != 0 && getMinDisToNode(Tstream, test, obj->id, child.second) <= r) {
							queNode.push(child.second);
						}
					}
				}
				else {
					NodeList.push_back(temNode);
					for (auto group : temNode->dataMap) {
						if (neighborNum >= (test.getK() + 0)) {
							break;
						}
						if (group.first > posIndex) {
							for (auto id : group.second) {
								if (id!= obj->id && calculateDistanceById(Tstream, test, id, obj->id) <= r) {
									groupIndex[group.first]++;
									obj->oNrdataObjVec[group.first]++;
									neighborNum++;
								}
							}
						}
						else if (group.first == posIndex) {
							for (auto id : group.second) {
								if (id < Tstream.getDataStreamBegin()) {
									break;
								}
								if (id != obj->id && calculateDistanceById(Tstream, test, id, obj->id) <= r) {
									groupIndex[group.first]++;
									obj->oNrdataObjVec[group.first]++;
									neighborNum++;
								}
							}
						}
					}
				}
			}
		}
		queNode.pop();
	}
}

void KNode::printOutlier(Tstream& Tstream, Test& test, Node* node)
{
	queue<Node*> queNode;
	queNode.push(node);
	Node* temNode = nullptr;
	int startIndex = SlideIdCount / dataMapCount;
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				queNode.push(child.second);
			}
		}
		else {
			for (auto group = temNode->dataMap.begin(); group != temNode->dataMap.end();) {
				if (group->first >= startIndex) {
					for (int id : group->second) {
						if (id < Tstream.getDataStreamBegin()) {
							break;
						}
						changeRMap.emplace(id, temNode);
					}
				}
				group++;
			}
		}
		queNode.pop();
	}
}

void KNode::checkChangeR(Tstream& Tstream, Test& test)
{
	int dataNum = calWindowMaintainObjNum(Tstream, test);
	int lowerBound = 0.005 * dataNum;
	int upperBound = 0.02 * dataNum;
	int count = 0.01 * dataNum + 1;
	int count2 = 0.01 * dataNum + 1;
	
	int outlierNum = changeRMap.size();
	while (true) {
		if (changeRMap.size() < lowerBound) {
			double oldR = test.getR();
			unordered_set<Node*> LeafSet;
			findLeafSet(Tstream, test, LeafSet, count2);
			multimap<double, int, greater<double>> Map;
			for (auto leafNode : LeafSet) {
				for (auto group : leafNode->dataMap) {
					for (auto id : group.second) {
						Map.emplace(findKNNForOutlier(Tstream, test, id, leafNode), id);
					}
				}
			}
			int num = 0;
			for (auto it : Map) {
				num++;
				if (num == count) {
					double newR = (it.first + oldR) / 2;
					test.setR(newR);
					break;
				}
			}
			changeRMap.clear();
			reDealKnodeSmall(Tstream, test);
			reDealE_I(Tstream, test);
			changeRReFindOutlier(Tstream, test);
			if (changeRMap.size() >= lowerBound && changeRMap.size() <= upperBound) {
				num = 0;
				for (multimap<double, int, greater<double>>::iterator it = Map.begin(); it != Map.end(); ++it) {
					num++;
					if (num < count) {
						if (warningObjMap.find(it->second) != warningObjMap.end()) {
							warningObjMap[it->second]->warningTime = SlideIdCount + 1;
							warningObjMap[it->second]->l_k = it->first;
						}
						else {
							dataObj* newObj = new dataObj;
							newObj->id = it->second;
							newObj->l_k = it->first;
							newObj->warningTime = SlideIdCount + 1;
							warningObjMap.emplace(newObj->id, newObj);
						}
					}
					else {
						if (warningObjMap.find(it->second) != warningObjMap.end()) {
							warningObjMap[it->second]->l_k = it->first;
						}
					}
				}
				Tstream.addChangeTimes();
				return;
			}
		}
		else if (changeRMap.size() > upperBound) {
			double oldR = test.getR();
			multimap<double, int, greater<double>> Map;
			for (auto outlier : changeRMap) {
				Map.emplace(findKNNForOutlier(Tstream, test, outlier.first, outlier.second), outlier.first);
			}
			int num = 0;
			for (auto it : Map) {
				num++;
				if (num == count) {
					test.setR(it.first / (1 + 0.1 * test.getrho()));
					setfindl_kupThreshold(Tstream, test);
				}
				if (num < count) {
					if (warningObjMap.find(it.second) != warningObjMap.end()) {
						warningObjMap[it.second]->warningTime = SlideIdCount + 1;
						warningObjMap[it.second]->l_k = it.first;
					}
					else {
						dataObj* newObj = new dataObj;
						newObj->id = it.second;
						newObj->l_k = it.first;
						newObj->warningTime = SlideIdCount + 1;
						warningObjMap.emplace(newObj->id, newObj);
					}
				}
				else {
					if (warningObjMap.find(it.second) != warningObjMap.end()) {
						warningObjMap[it.second]->l_k = it.first;
					}
				}
			}
			Tstream.addChangeTimes();
			reDealE_L(Tstream, test);
			return;
		}
	}
}

double KNode::findKNNForOutlier(Tstream& Tstream, Test& test, int outlierId, Node* targetNode)
{
	multiset<double> neighborSet;
	double kR = DBL_MAX;
	queue<Node*> queNode;
	queue<Node*> stackNode;
	stackNode.push(targetNode);
	Node* temNode = targetNode;
	addTargetObjToNeighborSet(Tstream, test, outlierId, targetNode, kR, neighborSet);
	while (temNode->parentNode != nullptr) {
		temNode = temNode->parentNode;
		stackNode.push(temNode);
	}
	while (!stackNode.empty()) {
		if (stackNode.front()->parentNode != nullptr) {
			temNode = stackNode.front()->parentNode;
			for (auto it = temNode->childList.begin(); it != temNode->childList.end(); ++it) {
				if ((*it).second->NodeId != stackNode.front()->NodeId && getMinDisBetweenTwoNode(Tstream, test, (*it).second, targetNode) <= kR) {
					queNode.push((*it).second);
				}
			}
		}
		stackNode.pop();
		while (!queNode.empty()) {
			temNode = queNode.front();
			if (temNode->maintainDataNum > 0) {
				addTargetObjToNeighborSet(Tstream, test, outlierId, temNode, kR, neighborSet);
			}
			queNode.pop();
		}
	}
	if (neighborSet.size() == test.getK()) {
		return *(--neighborSet.end());
	}
}

void KNode::addTargetObjToNeighborSet(Tstream& Tstream, Test& test, int& outlierId, Node* node, double& kR, multiset<double>& neighborSet)
{
	queue<Node*> queNode;
	queNode.push(node);
	Node* temNode = nullptr;
	int startIndex = getStartIndex(Tstream, test);
	int begin = Tstream.getDataStreamBegin();
	double dis = 0;
	int k = test.getK();
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				if (child.second->maintainDataNum != 0 && getMinDisToNode(Tstream, test, outlierId, child.second) < kR) {
					queNode.push(child.second);
				}
			}
		}
		else {
			for (auto group : temNode->dataMap) {
				if (group.first > startIndex) {
					for (auto id : group.second) {
						if (id != outlierId) {
							dis = calculateDistanceById(Tstream, test, id, outlierId);
							if (dis < kR) {
								neighborSet.emplace(dis);
								if (neighborSet.size() > k) {
									neighborSet.erase(--neighborSet.end());
									kR = *(--neighborSet.end());
								}
							}
						}
					}
				}
				else if (group.first == startIndex) {
					for (auto id : group.second) {
						if (id < begin) {
							break;
						}
						if (id != outlierId) {
							dis = calculateDistanceById(Tstream, test, id, outlierId);
							if (dis < kR) {
								neighborSet.emplace(dis);
								if (neighborSet.size() > k) {
									neighborSet.erase(--neighborSet.end());
									kR = *(--neighborSet.end());
								}
							}
						}
					}
				}
			}
		}
		queNode.pop();
	}
}

void KNode::findLeafSet(Tstream& Tstream, Test& test, unordered_set<Node*>& LeafSet, int& count)
{
	queue<Node*> queNode;
	queNode.push(QDTreeRoot);
	Node* temNode = nullptr;
	double dis = 0;
	int temCount = 0;
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				if (child.second->maintainDataNum != 0) {
					queNode.push(child.second);
				}
			}
		}
		else {
			LeafSet.emplace(temNode);
			temCount += temNode->maintainDataNum;
			if (temCount >= count) {
				return;
			}
		}
		queNode.pop();
	}
}

void KNode::initKnodeFlag(Tstream& Tstream, Test& test) {
	queue<Node*> queNode;
	queNode.push(QDTreeRoot);
	Node* temNode = nullptr;
	while (!queNode.empty()) {
		temNode = queNode.front();
		temNode->KnodeFlag = false;
		if (temNode->maintainDataNum != 0) {
			if (temNode->childList.size() != 0) {
				for (auto child : temNode->childList) {
					queNode.push(child.second);
				}
			}
		}
		queNode.pop();
	}
}

void KNode::LOGOutlier(Tstream& Tstream, Test& test, set<int>& temSet)
{
	ofstream data;
	data.open("outlier.txt", ofstream::app);
	data << "begin= " << Tstream.getDataStreamBegin() << endl;
	for (auto id : temSet) {
		data << id << endl;
	}
	data.close();
}

void KNode::findObj(Tstream& Tstream, Test& test, Node* node, int targetObjId)
{
	queue<Node*> queNode;
	queNode.push(node);
	Node* temNode = nullptr;
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				queNode.push(child.second);
			}
		}
		else {
			for (auto group : temNode->dataMap) {
				for (auto id : group.second) {
					if (id == targetObjId) {
						cout << endl;
					}
				}
			}
		}
		queNode.pop();
	}
}

void KNode::reDealKnodeSmall(Tstream& Tstream, Test& test)
{
	list<Node*> newKnodeLarge;
	double threshold = (1 + test.getrho()) * test.getR() / 2;
	for (auto kNodeS = KnodeSmall.begin(); kNodeS != KnodeSmall.end();) {
		if ((*kNodeS)->diagonalLength > threshold) {
			newKnodeLarge.push_back(*kNodeS);
			kNodeS = KnodeSmall.erase(kNodeS);
			continue;
		}
		kNodeS++;
	}
	findE_IAndE_lInKnodeLarge(Tstream, test, newKnodeLarge);
}

void KNode::reDealE_I(Tstream& Tstream, Test& test)
{
	double threshold = test.getR() * test.getrho() / 2;
	Node* temNode = nullptr;
	unordered_map<int, Node*> newE_I;
	for (auto NodeInE_I : E_I) {
		queue<Node*> queKNode;
		if (NodeInE_I.second->diagonalLength <= threshold) {
			newE_I.emplace(NodeInE_I.first, NodeInE_I.second);
			continue;
		}
		queKNode.push(NodeInE_I.second);
		while (!queKNode.empty()) {
			temNode = queKNode.front();
			if (temNode->childList.size() == 0) {
				if (temNode->diagonalLength > threshold) {
					if (temNode->maintainDataNum != 0) {
						E_L.emplace(temNode->NodeId, temNode);
					}
				}
				else {
					if (temNode->maintainDataNum != 0) {
						newE_I.emplace(temNode->NodeId, temNode);
					}
				}
			}
			else {
				if (temNode->diagonalLength > threshold) {
					for (auto child : temNode->childList) {
						queKNode.push(child.second);
					}
				}
				else {
					if (temNode->maintainDataNum != 0) {
						newE_I.emplace(temNode->NodeId, temNode);
					}
				}
			}
			queKNode.pop();
		}
	}
	E_I.clear();
	E_I = newE_I;
}

void KNode::reDealE_L(Tstream& Tstream, Test& test)
{
	double threshold = test.getR() * test.getrho() / 2;
	Node* temNode = nullptr;
	unordered_map<int, Node*> newE_L;
	for (auto NodeInE_L : E_L) {
		queue<Node*> queKNode;
		if (NodeInE_L.second->diagonalLength > threshold) {
			newE_L.emplace(NodeInE_L.first, NodeInE_L.second);
			continue;
		}
		queKNode.push(NodeInE_L.second);
		while (!queKNode.empty()) {
			temNode = queKNode.front();
			if (temNode->childList.size() == 0) {
				if (temNode->diagonalLength > threshold) {
					if (temNode->maintainDataNum != 0) {
						newE_L.emplace(temNode->NodeId, temNode);
					}
				}
				else {
					if (temNode->maintainDataNum != 0) {
						E_I.emplace(temNode->NodeId, temNode);
					}
				}
			}
			else {
				if (temNode->diagonalLength > threshold) {
					for (auto child : temNode->childList) {
						queKNode.push(child.second);
					}
				}
				else {
					if (temNode->maintainDataNum != 0) {
						E_I.emplace(temNode->NodeId, temNode);
					}
				}
			}
			queKNode.pop();
		}
	}
	E_L.clear();
	E_L = newE_L;
}

void KNode::changeRReFindOutlier(Tstream& Tstream, Test& test)
{
	double r = test.getR();
	int startIndex = getStartIndex(Tstream, test);
	int dataStreamBegin = Tstream.getDataStreamBegin();
	int endSlideIdCount = (SlideIdCount - slideNum + 1) > 0 ? (SlideIdCount - slideNum + 1) : 0;
	for (auto nodeInE_I : E_I) {
		if (nodeInE_I.second->l_kup > r || nodeInE_I.second->warningTime <= SlideIdCount) {
			updateTightenl_kup(Tstream, test, nodeInE_I.second, test.getR());
			if (nodeInE_I.second->l_kup > r) {
				printOutlier(Tstream, test, nodeInE_I.second);
			}
			updateParentNodel_kupAnde_t(Tstream, test, nodeInE_I.second);
		}
	}
	for (auto nodeInE_L : E_L) {
		if (nodeInE_L.second->diagonalLength > findl_kupThreshold) {
			for (auto group : nodeInE_L.second->dataMap) {
				if (group.first >= startIndex) {
					for (auto id : group.second) {
						if (id >= dataStreamBegin) {
							auto it = warningObjMap.find(id);
							if (it != warningObjMap.end()) {
								if (it->second->l_k > r || it->second->warningTime <= SlideIdCount) {
									reSetl_kupForObj(Tstream, test, it->second, nodeInE_L.second, true);
								}
							}
							else {
								createONrByNode(Tstream, test, id, nodeInE_L.second);
							}
						}
					}
				}
			}
		}
		else {
			if (nodeInE_L.second->l_kup <= r && ((nodeInE_L.second->l_kup + 2 * nodeInE_L.second->diagonalLength) <= (1 + test.getrho()) * r)) {
				if (nodeInE_L.second->warningTime <= SlideIdCount) {
					updateTightenl_kup(Tstream, test, nodeInE_L.second, test.getR());
					if (nodeInE_L.second->l_kup > r) {
						printOutlier(Tstream, test, nodeInE_L.second);
					}
					updateParentNodel_kupAnde_t(Tstream, test, nodeInE_L.second);
				}
			}
			else {
				updateTightenl_kup(Tstream, test, nodeInE_L.second, (1 + test.getrho()) * r - 2 * nodeInE_L.second->diagonalLength);
				if (nodeInE_L.second->l_kup > r) {
					printOutlier(Tstream, test, nodeInE_L.second);
				}
				updateParentNodel_kupAnde_t(Tstream, test, nodeInE_L.second);
				if (nodeInE_L.second->l_kup <= r && (nodeInE_L.second->l_kup + 2 * nodeInE_L.second->diagonalLength) > (1 + test.getrho()) * r) {
					for (auto group : nodeInE_L.second->dataMap) {
						if (group.first >= startIndex) {
							for (auto id : group.second) {
								if (id >= dataStreamBegin) {
									auto it = warningObjMap.find(id);
									if (it != warningObjMap.end()) {
										if (it->second->l_k > r || it->second->warningTime <= SlideIdCount) {
											reSetl_kupForObj(Tstream, test, it->second, nodeInE_L.second, true);
										}
									}
									else {
										createONrByNode(Tstream, test, id, nodeInE_L.second);
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

int KNode::calWindowMaintainObjNum(Tstream& Tstream, Test& test)
{
	int count = 0;
	for (int i = SlideIdCount; i < SlideIdCount+slideNum; ++i) {
		count += Tstream.getS_change(i);
	}
	return count;
}

void KNode::calTreeIndexSize(Tstream& Tstream, Test& test)
{
	queue<Node*> queNode;
	queNode.push(QDTreeRoot);
	Node* temNode = nullptr;
	while (!queNode.empty()) {
		temNode = queNode.front();
		addIndexSize(*temNode);
		if (temNode->childList.size() != 0) {
			for (auto child : temNode->childList) {
				queNode.push(child.second);
			}
		}
		queNode.pop();
	}
}
