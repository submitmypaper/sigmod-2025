#include <iostream>
#include<fstream>
#include<stdio.h>
#include"Test.h"
#include"Tstream.h"
#include"KNode.h"
#include <iomanip>
#include <ctime>
#include"string"
using namespace std;
#pragma warning(disable:4996)
void printlogmain(Tstream& Tstream, Test& test, double time1, double time2) {
	ofstream data;
	data.open("log_mainKNode.txt", ofstream::app);
	data << "WindowSize:" << test.getWindowSize() << endl;
	data << "K= " << test.getK() << " R= " << test.getR() << " rho= " << test.getrho() << endl;
	data << "InitTime��" << time1 << "s" << endl;
	data << "RunningTime��" << time2 << "s" << endl;
	data.close();
}
int main()
{
	clock_t startTime, endTime, createTime;
	double initTime;
	for (int j = 0; j < 6; j++) {
		Test t;
		Tstream Tstream;
		vector<Test> vecTestFile;
		t.Init(vecTestFile, j);
		Tstream.Init(vecTestFile[j], j);
		for (int i = 0; i < vecTestFile.size(); i++) {
			if (i != 0) {
				Tstream.resetUpdateNeighborNum();
			}
			KNode kNode;
			startTime = clock();
			kNode.Init(Tstream, vecTestFile[i]);
			endTime = clock();
			initTime = (double)(endTime - startTime) / CLOCKS_PER_SEC;
			std::cout << std::fixed << std::setprecision(3);
			cout << "Init Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << 's' << endl;
			startTime = clock();
			kNode.Update(Tstream, vecTestFile[i]);
			endTime = clock();
			cout << "Running Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
			printlogmain(Tstream, vecTestFile[i], initTime, (double)(endTime - startTime) / CLOCKS_PER_SEC);
		}
	}
	return 0;
}