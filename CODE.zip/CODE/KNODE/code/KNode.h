#include <vector>
#include <list>
#include <queue>
#include <map>
#include <cassert>
#include <math.h>
#include <algorithm>
#include "Tstream.h"
#include "Test.h"
#include<stack>
#include <unordered_map>
#include<set>
#include<unordered_set>
typedef vector<double> Data;
template<typename _Kty, typename _Ty>
class maplist : public list<pair<_Kty, _Ty>>
{
public:
	typedef list<pair<_Kty, _Ty>> _Mybase;
	typedef typename _Mybase::iterator iterator;

	void erase(const _Kty& k)
	{
		auto itFind = find_if(__super::begin(), __super::end(), [&](const pair<_Kty, _Ty>& it)->bool {return(it.first == k); });
		if (itFind != __super::end()) { __super::erase(itFind); }
	}
	iterator find(const _Kty& k)
	{
		return find_if(__super::begin(), __super::end(), [&](const pair<_Kty, _Ty>& it)->bool {return(it.first == k); });
	}
	_Ty& operator[](const _Kty& k)
	{
		auto itFind = find_if(__super::begin(), __super::end(), [&](const pair<_Kty, _Ty>& it)->bool {return(it.first == k); });
		if (itFind == __super::end())
		{
			itFind = __super::insert(__super::end(), make_pair(k, _Ty()));
		}
		return itFind->second;
	}
	iterator erase(iterator it)
	{
		return __super::erase(it); 
	}
	template<typename... Args>
	iterator emplace(const _Kty& key, Args&&... args)
	{
		auto itFind = find(key);
		if (itFind == __super::end())
		{
			return __super::insert(__super::end(), make_pair(key, _Ty(std::forward<Args>(args)...)));
		}
		return itFind;
	}
};
class KNode {
public:
	struct Node {
		long addr = -1;
		int NodeId = 0;
		unordered_map<int, list<int>> dataMap;  
		unordered_map<long, Node*> childList;
		Node* parentNode = nullptr;
		vector<double> vecLeftDown;
		vector<double> vecRightUp;
		double sideLength;
		double diagonalLength;
		bool KnodeFlag = false; 
		maplist<int, Node*> NNl_uk;
		maplist<int, Node*> NNl_ukSmall;
		double l_kup = DBL_MAX;
		int warningTime = 0; 
		int maintainDataNum = 0;
	};
	struct dataObj {
		int id;
		double l_k = DBL_MAX;
		int warningTime = 0;
		vector<int> oNrdataObjVec;
		list<Node*> oNrNodeList;
	};
	KNode();
	~KNode();
	void setQDTreeSplitNum(int QDtreeSplitNum);
	void setDataMapCount(int count);
	double calculateDistanceById(Tstream& tstream, Test& test, int id1, int id2);
	double calculateDistanceByCoordinate(Tstream& tstream, Test& test, int id, Data data);
	double calculateDistanceBetweenTwoData(Tstream& tstream, Test& test, Data data1, Data data2);
	double getMinDisToNode(Tstream& Tstream, Test& test, int dataId, Node* node);
	double getMaxDisToNode(Tstream& Tstream, Test& test, int dataId, Node* node);
	double getMinDisBetweenTwoNode(Tstream& Tstream, Test& test, Node* node1, Node* node2);

	void Init(Tstream& Tstream, Test& test);
	void setTreeInfo(Tstream& Tstream, Test& test);
	void addDataObjToTree(Tstream& Tstream, Test& test);
	void splitTree(Tstream& Tstream, Test& test, Node* splitNode);
	void splitTree(Tstream& Tstream, Test& test, Node* splitNode, bool update);
	long findAddrForData(Tstream& Tstream, Test& test, Node* node, int& dataId, vector<int>& vecAddr);
	long findAddr(Tstream& Tstream, Test& test, vector<int>& vecAddr);
	void findChildNode(Tstream& Tstream, Test& test, long& addr, Node* parentNode, int& dataId, vector<int>& vecAddr);
	void findOutlier(Tstream& Tstream, Test& test);
	void findKnodeSet(Tstream& Tstream, Test& test);
	void createNodeNNl(Tstream& Tstream, Test& test, Node* targetNode);
	void addCurNodeLeafNodeToNNluk(Tstream& Tstream, Test& test, Node* targetNode);
	void findE_IAndE_lInKnodeLarge(Tstream& Tstream, Test& test);
	void findE_IAndE_lInKnodeLarge(Tstream& Tstream, Test& test, list<Node*>& newKnodeLarge);
	void setl_kupToDescendentNodeOfKnode(Tstream& Tstream, Test& test);
	void findl_kupInKnode(Tstream& Tstream, Test& test, Node* KNode);
	void findKNN(Tstream& Tstream, Test& test, Node* targetNode, maplist<int, Node*>& nodeMap, maplist<int, Node*>& nodeMapSmall);
	void dealNodeInE_I(Tstream& Tstream, Test& test);
	void dealNodeInE_L(Tstream& Tstream, Test& test);
	void tighteningl_kup(Tstream& Tstream, Test& test, Node* node);
	void calNodel_kInNode(Tstream& Tstream, Test& test, Node* targetNode, multimap<double, int>& knnMap, Node* nodeInNNr, double& minDis, vector<int>& indexVec);
	void updateParentNodel_kupAnde_t(Tstream& Tstream, Test& test, Node* node);
	void createONrByNode(Tstream& Tstream, Test& test, int& objId, Node* targetNode);
	void addRhoNeighbor(Tstream& Tstream, Test& test, Node* rhoNode, dataObj* obj, vector<int>& groupIndex, int& neighborNum, int& index);
	void addRhoNeighbor(Tstream& Tstream, Test& test, Node* rhoNode, dataObj* obj, vector<int>& groupIndex, int& neighborNum, int& beginIndex, int& endIndex);
	void reFindONr(Tstream& Tstream, Test& test, int& objId, Node* targetNode, int& index);
	void reFindONr(Tstream& Tstream, Test& test, int& objId, Node* targetNode);

	void Update(Tstream& Tstream, Test& test);
	void addNewObjToTree(Tstream& Tstream, Test& test, int objBeginId, int objEndId);
	void createNewChildNode(Tstream& Tstream, Test& test, long& addr, Node* parentNode, int& newObjId, vector<int>& vecAddr);
	void updateNodeInfo(Tstream& Tstream, Test& test, Node* node);
	void updateNodeInfo(Tstream& Tstream, Test& test, Node* node, bool changeRflag);
	void deleteExpireObj(Tstream& Tstream, Test& test, unordered_map<int, list<int>>& dataMap);
	void clearWarningObjMap(Tstream& Tstream, Test& test);
	void findKnodeSetInUpdate(Tstream& Tstream, Test& test, Node* root);
	void checkNewKnodeSet(Tstream& Tstream, Test& test, list<Node*>& newKnodeSet);
	bool judgeNewKnodeInfo(Tstream& Tstream, Test& test, Node* newKnode, Node*& oldKnode);
	void createNNl_ukByOldKnodeForNewKnode(Tstream& Tstream, Test& test, Node* newKnode, Node* oldKnode);
	void changeKnodeInfo(Tstream& Tstream, Test& test, Node* newKnode);
	void changeKnodeInfo(Tstream& Tstream, Test& test, Node* newKnode, bool flag);
	void findKNodeForNewCreateNode(Tstream& Tstream, Test& test);
	void findNewKnodeLargeInNewNode(Tstream& Tstream, Test& test, Node* newNode, list<Node*>& newKnodeLarge);
	void updateDealE_IAndE_LNode(Tstream& Tstream, Test& test);
	void updateTightenl_kup(Tstream& Tstream, Test& test, Node* node, double l_kthreshold);
	void reSetl_kupInIntermediateNode(Tstream& Tstream, Test& test, Node* targetNode, Node* intermediateNode, multimap<double, int>& knnMap, vector<int>& indexVec, double& minDis, double l_kthreshold);
	void reSetl_kupInIntermediateNode(Tstream& Tstream, Test& test, Node* targetNode, Node* intermediateNode, multimap<double, int>& knnMap, vector<int>& indexVec, double& minDis, double l_kthreshold, unordered_map<int, Node*>& leafNodeMap);
	void reCall_kupOfNode(Tstream& Tstream, Test& test, Node* node, Node* kNode, double l_kthreshold);
	void reSetl_kupForObj(Tstream& Tstream, Test& test, dataObj* Obj, Node* targetNode);
	void reSetl_kupForObj(Tstream& Tstream, Test& test, dataObj* Obj, Node* targetNode, bool changeR);
	void findObjl_kInNode(Tstream& Tstream, Test& test, Node* node, vector<int>& groupIndex, int& neighborNum);
	int getPosIndex(Tstream& Tstream, Test& test);
	int getStartIndex(Tstream& Tstream, Test& test);
	void creatPartition(Tstream& Tstream, Test& test, int dataId, Node* targetNode);
	void setfindl_kupThreshold(Tstream& Tstream, Test& test);
	void reFindInkNode(Tstream& Tstream, Test& test, dataObj* obj, Node* targetNode, Node* kNode, vector<int>& groupIndex, int& neighborNum, int& endIndex);
	void addNeighborInNode(Tstream& Tstream, Test& test, dataObj* obj, Node* node, vector<int>& groupIndex, int& neighborNum);
	void addNeighborInIntermediateNode(Tstream& Tstream, Test& test, dataObj* obj, Node* node, vector<int>& groupIndex, int& neighborNum, int& posIndex);
	void addNeighborInIntermediateNode(Tstream& Tstream, Test& test, dataObj* obj, Node* node, vector<int>& groupIndex, int& neighborNum, int& posIndex, list<Node*>& NodeList);
	void printOutlier(Tstream& Tstream, Test& test, Node* node);
	void checkChangeR(Tstream& Tstream, Test& test);
	double findKNNForOutlier(Tstream& Tstream, Test& test, int outlierId, Node* targetNode);
	void addTargetObjToNeighborSet(Tstream& Tstream, Test& test, int& outlierId, Node* node, double& kR, multiset<double>& neighborSet);
	void findLeafSet(Tstream& Tstream, Test& test, unordered_set<Node*>& LeafSet, int& count);

	void initKnodeFlag(Tstream& Tstream, Test& test);
	void LOGOutlier(Tstream& Tstream, Test& test, set<int>& temSet);
	void findObj(Tstream& Tstream, Test& test, Node* node, int targetObjId);
	void reDealKnodeSmall(Tstream& Tstream, Test& test);
	void reDealE_I(Tstream& Tstream, Test& test);
	void reDealE_L(Tstream& Tstream, Test& test);
	void changeRReFindOutlier(Tstream& Tstream, Test& test);
	int calWindowMaintainObjNum(Tstream& Tstream, Test& test);
	void calTreeIndexSize(Tstream& Tstream, Test& test);
	template<typename T>
	void addIndexSize(const T& var);
private:
	int QDTreeSplitNum = 0;
	int NodeIdCount = 0;
	int SlideIdCount = 0;
	int slideNum = 0;
	int s_changeNum = 0;
	Node* QDTreeRoot = nullptr;
	list<Node*> KnodeSmall;
	list<Node*> KnodeLarge;
	unordered_map<int, Node*> E_I;
	unordered_map<int, Node*> E_L;
	int dataMapCount = 0;
	unordered_map<int, dataObj*> warningObjMap;

	list<Node*> newCreateNodeList;
	unordered_set<int> mtreeObjSet;
	double findl_kupThreshold;
	unordered_map<int, Node*> changeRMap;
	unordered_map<int, int>PointSet;
	size_t  indexSize = 0;
};

template<typename T>
inline void KNode::addIndexSize(const T& var)
{
	indexSize += sizeof(var);
}
