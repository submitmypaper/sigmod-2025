#pragma once
#include <vector>
#include <math.h>
#include"Test.h"
using namespace std;
class Tstream {
public:
	Tstream();
	~Tstream();

	void readDataFile(Test& test, int j);
	double getDataStream(int intObjectNumber);
	double getDataInDimension(int id, int dimension, int targetDimension);
	vector<double> getData(int dataId, int dimension);
	int getDataStreamLength();
	int getDataStreamBegin();
	int getDataStreamTag();
	double getMaxSide();
	void setDataStreamBegin(int begin);
	void setDataStreamTag(int tag);
	void Init(Test& test, int j);
	void addDataStreamBegin(int outFlow);
	void addDataStreamTag(int inFlow);
	void addUpdateNeighborNumById(Test& test, int id);
	void setUpdateNeighborNumById(int id, int num);
	unsigned short getUpdateNeighborNumById(int id);
	double getEveryDimensionMinAndMax(int dimension, int index);
	void setMinAndMaxIdNum(int dimension, int num, int index);
	int getMinAndMaxIdNum(int dimension, int index);
	void MinAndMaxIdNumResize(int dimension);
	void resetUpdateNeighborNum();
	int getVecDataStreamNum(int dimension);
	vector<double> getCentralCoordinate();
	double getFirstRadius();
	void setS_change();
	int getS_change(int idx);
	int getS_changeSize();
	void addChangeTimes();
	int getChangeTimes();
	void addSlideTimes();
	int getSlideTimes();
private:
	double maxSide;
	vector<double> vecDataStream;
	vector<unsigned short>	updateNeighborNum;
	int dataStreamBegin = 0;
	int dataStreamTag = 0;
	vector<double> everyDimensionMinAndMax;
	vector<int> MinAndMaxIdNum;
	vector<double> centralCoordinate;
	double firstRadius = 0;
	vector<int>S_change;
	int ChangeTimes = 0;
	int slideTimes = 0;
};