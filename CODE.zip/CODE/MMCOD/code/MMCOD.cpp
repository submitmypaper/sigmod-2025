#include "MMCOD.h"
#include<string>
#include <algorithm>
#include "TStream.h"
#include<fstream>
using namespace std;

bool compareGreater(double a, double b) {
	return a > b;
}

double MMCODFindOutlier::calculateDistanceById(TStream& tstream, Test& test, int id1, int id2) {
	int dimension = test.GetDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(tstream.GetDataStream(id1 * dimension + i) - tstream.GetDataStream(id2 * dimension + i), 2);
	}
	return sqrt(dis);
}

double MMCODFindOutlier::calculateDistanceBycoordinate(TStream& tstream, Test& test, int id, vector<double> data) {
	int dimension = test.GetDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(tstream.GetDataStream(id * dimension + i) - data[i], 2);
	}
	return sqrt(dis);
}

double MMCODFindOutlier::calculateDistanceBetweenTwoData(TStream& tstream, Test& test, Data data1, Data data2)
{
	int dimension = test.GetDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(data1[i] - data2[i], 2);
	}
	return sqrt(dis);
}

vector<double> MMCODFindOutlier::GetDataCoordinate(TStream& tstream, Test& test, int id)
{
	int dimension = test.GetDimension();
	vector<double>coordinates;
	for (int j = 0; j < dimension; j++) {
		coordinates.push_back(tstream.getDataInDimension(id, dimension, j));
	}
	return coordinates;
}

MMCODFindOutlier::~MMCODFindOutlier()
{
}

MMCODFindOutlier::MMCODFindOutlier() {

}

void MMCODFindOutlier::InitCircle(TStream& tstream, Test& test)
{
	slideNum = test.GetWindowSize() / test.GetDimension() / test.GetInFlow();
	slideVec.resize(slideNum);
	CreateCircle(tstream, test);
	PutDataInCircle(tstream, test);
	DealCirCle(tstream, test);
	CheckPDFormCircle(tstream, test);
	splitmTree(tstream, test);
	BulitMtree = true;
	findOutlier(tstream, test);
}

void MMCODFindOutlier::CreateCircle(TStream& tstream, Test& test)
{
	int dim = test.GetDimension();
	int slidesum = test.GetWindowSize() / dim / test.GetInFlow();
	double R = test.GetR();
	int dataFront = 0;
	int dataBack = 0;
	vector<double>coordinates;
	for (int i = 0; i < slidesum; i++) {
		int start = dataBack;
		dataBack += tstream.GetInflow(i);
		for (int j = start; j < dataBack; j++) {
			bool flag = false;
			coordinates.clear();
			coordinates = GetDataCoordinate(tstream, test, j);
			for (auto& Circle : CircleSet_12R) {
				if (calculateDistanceBycoordinate(tstream, test, j, Circle.second->CenterCircle) <= 0.5 * R) {
					flag = true;
					break;
				}
			}
			if (!flag) {
				CircleObj* newCircle = new CircleObj;
				newCircle->Cid = j;
				newCircle->radius = 0.5 * R;
				newCircle->CenterCircle = coordinates;
				newCircle->depth = 0;
				CircleSet_12R.emplace(j, newCircle);
			}
		}
	}
}

void MMCODFindOutlier::PutDataInCircle(TStream& tstream, Test& test)
{
	int dimension = test.GetDimension();
	int slideSum = test.GetWindowSize() / dimension / test.GetInFlow();
	double R = test.GetR();
	vector<double>coordinates;
	int dataFront = 0;
	int dataBack = 0;
	for (int i = 0; i < slideSum; i++) {
		int temp = dataBack;
		int inflow = tstream.GetInflow(i);
		WindowBegin.emplace(i, dataBack);
		dataBack += inflow;
		for (int j = temp; j < dataBack; j++) {
			DataObj* data = new DataObj;
			data->id = j;
			data->slideID = i;
			data->LaterNei.clear();
			data->PreNei.clear();
			PointSet[j] = data;
			coordinates.clear();
			coordinates = GetDataCoordinate(tstream, test, j);
			for (auto& Circle : CircleSet_12R) {
				double dis = calculateDistanceBycoordinate(tstream, test, j, Circle.second->CenterCircle);
				if (dis <= 0.5 * R) {
					Circle.second->Datalist.push_back(data);
					data->Circle_R.push_back(Circle.second->Cid);
				}
				else if (dis <= 1.5 * R) {
					data->Circle_32R.push_back(Circle.second->Cid);
				}
			}
		}
		
		tstream.AddDataStreamTag(inflow);
	}
}

void MMCODFindOutlier::CheckPDFormCircle(TStream& tstream, Test& test)
{
	double R = test.GetR();
	int K = test.GetK();
	double dis = 0;
	for (auto it = PD.begin(); it != PD.end(); it++) {
		for (auto it1 = next(it); it1 != PD.end(); it1++) {
			dis = calculateDistanceById(tstream, test, (*it)->id, (*it1)->id);
			if (dis <= 0.5 * R) {
				distanceMap[(*it)].insert(*it1);
				distanceMap[(*it1)].insert(*it);
			}
			if (dis <= R) {
				if ((*it)->id > (*it1)->id) {
					(*it)->PreNei.insert((*it1)->id);
					(*it1)->LaterNei.insert((*it)->id);
				}
				else {
					(*it)->LaterNei.insert((*it1)->id);
					(*it1)->PreNei.insert((*it)->id);
				}
			}
		}
	}
	for (auto it = PD.begin(); it != PD.end(); ) {
		DataObj* current = *it;
		int neighbors = distanceMap[current].size();
		if (neighbors >= K + 1) {
			FormNewCircle(tstream, test, (*it));
			it = PD.begin();
		}
		else {
			++it;
		}
	}
}

void MMCODFindOutlier::DealCirCle(TStream& tstream, Test& test)
{
	int K = test.GetK();
	for (auto it = CircleSet_12R.begin(); it != CircleSet_12R.end(); it++) {
		if ((*it).second->Datalist.size() < K + 1) {
			for (auto data : (*it).second->Datalist) {
				data->Circle_R.remove((*it).second->Cid);
				if (data->Circle_R.size() == 0) {
					PD.push_back(data);
				}
			}
			CircleSet_12R.erase(it--);
		}
		else {
			int i = (*it).second->Datalist.size() - K - 1;
			auto time = next((*it).second->Datalist.begin(), i);
			int j = (*time)->slideID - SlideStart;
			slideVec[j].needDealCircleObj.push_back((*it).second->Cid);
		}
	}
}

void MMCODFindOutlier::splitmTree(TStream& tstream, Test& test)
{
	int dimension = test.GetDimension();
	int R = test.GetR();
	queue<CircleObj*> needSplitNode;
	root = new CircleObj;
	root->CenterCircle = tstream.GetCentralCoordinate();
	root->distoparent = 0;
	root->parentNode = nullptr;
	root->radius = tstream.GetRadious();
	root->maxRadius = root->radius;
	root->depth = 0;
	InitRoot(tstream, test, root);
	vector<double> subTreeCoordinate;
	needSplitNode.push(root);
	double dis;
	double disMin;
	CircleObj* splitNode = nullptr;
	CircleObj* chooseNode = nullptr;
	CircleObj* tempNode = nullptr;
	while (!needSplitNode.empty()) {
		subTreeCoordinate.clear();
		splitNode = needSplitNode.front();
		while (splitNode->NodeList.size() != 0) {
			if (splitNode->childrenNode.size() == 8)
				break;
			ChoosemTreeSubNode(tstream, test, subTreeCoordinate, splitNode);
			for (int i = 0; i < subTreeCoordinate.size() / dimension; ++i) {
				CreateNode(tstream, test, subTreeCoordinate, splitNode, i);
			}
			subTreeCoordinate.clear();
			AddDataObjToChildNode(tstream, test, splitNode);
		}
		if (splitNode->NodeList.size() != 0) {
			for (auto cp = splitNode->NodeList.begin(); cp != splitNode->NodeList.end();) {
				chooseNode = nullptr;
				disMin = DBL_MAX;
				for (auto child : splitNode->childrenNode) {
					dis = calculateDistanceBetweenTwoData(tstream, test, (*cp)->CenterCircle, child->CenterCircle);
					if (dis < disMin) {
						disMin = dis;
						chooseNode = child;
					}
				}
				if (chooseNode != nullptr) {
					chooseNode->NodeList.push_back(*cp);
					(*cp)->parentNode = chooseNode;
					(*cp)->depth = chooseNode->depth + 1;
					(*cp)->distoparent = calculateDistanceBetweenTwoData(tstream, test, (*cp)->CenterCircle, chooseNode->CenterCircle);
					chooseNode->radius = max(chooseNode->radius, disMin + (*cp)->radius);
					splitNode->NodeList.erase(cp++);
				}
			}
		}
		for (auto child = splitNode->childrenNode.begin(); child != splitNode->childrenNode.end();) {
			if ((*child)->childrenNode.size() == 0 && (*child)->NodeList.size() == 0) {
				tempNode = *child;
				splitNode->childrenNode.erase(child++);
				delete tempNode;
				tempNode = nullptr;
				continue;
			}
			else if ((*child)->childrenNode.size() == 0 && (*child)->NodeList.size() > 16) {
				needSplitNode.push(*child);
			}
			child++;
		}
		needSplitNode.pop();
	}
}

void MMCODFindOutlier::InitRoot(TStream& tstream, Test& test, CircleObj* Root)
{
	for (auto& Circle : CircleSet_12R) {
		Root->NodeList.push_back(Circle.second);
	}
}

void MMCODFindOutlier::ChoosemTreeSubNode(TStream& tstream, Test& test, vector<double>& subTreecoordinate, CircleObj* node)
{
	int dimension = test.GetDimension();
	double maxNum;
	double minNum;
	double temp;
	vector<double> v1;
	vector<double> v2;
	map<double, pair<vector<double>, vector<double>>> Map;
	for (int i = 0; i < dimension; ++i) {
		maxNum = -10;
		minNum = DBL_MAX;
		for (auto CircleNode : node->NodeList) {
			temp = (*CircleNode).CenterCircle[i];
			if (temp > maxNum) {
				maxNum = temp;
				v1 = (*CircleNode).CenterCircle;
			}
			if (temp < minNum) {
				minNum = temp;
				v2 = (*CircleNode).CenterCircle;
			}
		}
		Map.emplace(maxNum - minNum, make_pair(v1, v2));
	}
	for (int i = 0; i < dimension; ++i) {
		subTreecoordinate.push_back(((*Map.rbegin()).second.first[i] * 3 + (*Map.rbegin()).second.second[i]) / 4);
	}
	for (int i = 0; i < dimension; ++i) {
		subTreecoordinate.push_back(((*Map.rbegin()).second.first[i] + (*Map.rbegin()).second.second[i] * 3) / 4);
	}
}

void MMCODFindOutlier::CreateNode(TStream& tstream, Test& test, vector<double>& subTreecoordinate, CircleObj* node, int id)
{
	int dimension = test.GetDimension();
	CircleObj* childNode = new CircleObj();
	childNode->parentNode = node;
	childNode->depth = node->depth + 1;
	childNode->radius = node->radius * 0.5;
	for (int i = 0; i < dimension; ++i) {
		childNode->CenterCircle.push_back(subTreecoordinate[id * dimension + i]);
	}
	childNode->distoparent = calculateDistanceBetweenTwoData(tstream, test, childNode->CenterCircle, node->CenterCircle);
	node->childrenNode.push_back(childNode);
}

void MMCODFindOutlier::AddDataObjToChildNode(TStream& tstream, Test& test, CircleObj* Cirnode)
{
	CircleObj* chooseNode = nullptr;
	double dis = 0;
	double minDis = 0;
	double R = test.GetR();
	for (auto node = Cirnode->NodeList.begin(); node != Cirnode->NodeList.end();) {
		minDis = DBL_MAX;
		chooseNode = nullptr;
		for (auto& child : Cirnode->childrenNode) {
			dis = calculateDistanceBetweenTwoData(tstream, test, (*node)->CenterCircle, child->CenterCircle);
			if (dis < minDis && dis <= (child->parentNode->radius * 0.5)) {
				minDis = dis;
				chooseNode = child;
			}
		}
		if (chooseNode != nullptr) {
			(*node)->parentNode = chooseNode;
			chooseNode->NodeList.push_back(*node);
			chooseNode->radius = max(chooseNode->radius, minDis + (*node)->radius);
			Cirnode->NodeList.erase(node++);
			continue;
		}
		node++;
	}
}

void MMCODFindOutlier::findOutlier(TStream& tstream, Test& test)
{
	int K = test.GetK();
	for (auto it = PD.begin(); it != PD.end(); it++) {
		FindNeiFrom23RCircle(tstream, test, (*it));
		if ((*it)->getNN() >= K) {
			if ((*it)->LaterNei.size() < K) {
				int ii = (*it)->PreNei.size() - (K - (*it)->LaterNei.size());
				auto time = next((*it)->PreNei.begin(), ii);
				int i = PointSet[(*time)]->slideID - SlideStart;
				slideVec[i].needDealDataObj.push_back((*it));
			}
		}
		else {
			FindNeiFromPDList(tstream, test, (*it));
			if ((*it)->getNN() >= K) {
				if ((*it)->LaterNei.size() < K) {
					int ii = (*it)->PreNei.size() - (K - (*it)->LaterNei.size());
					auto time = next((*it)->PreNei.begin(), ii);
					int i = PointSet[(*time)]->slideID - SlideStart;
					slideVec[i].needDealDataObj.push_back((*it));
				}
			}
			else {
				OutlierSet.insert((*it));
			}
		}
	}
}

void MMCODFindOutlier::FindNeiFrom23RCircle(TStream& tstream, Test& test, DataObj* data)
{
	int ExpDataId = tstream.GetDataStreamBegin();
	int dimension = test.GetDimension();
	double R = test.GetR();
	int K = test.GetK();
	for (auto it = data->Circle_32R.begin(); it != data->Circle_32R.end(); it++) {
		auto itt = CircleSet_12R.find(*it);
		if (itt != CircleSet_12R.end()) {
			for (auto it1 = (*itt).second->Datalist.rbegin(); it1 != (*itt).second->Datalist.rend(); it1++) {
				if ((*it1)->id >= ExpDataId) {
					double dis = calculateDistanceById(tstream, test, (*it1)->id, data->id);
					if (dis <= R) {
						if ((*it1)->id > data->id) {
							data->LaterNei.insert((*it1)->id);
							(*it1)->PreNei.insert(data->id);
						}
						else {
							data->PreNei.insert((*it1)->id);
							(*it1)->LaterNei.insert(data->id);
						}
					}
					if (data->getNN() >= 1.5 * K)
						return;
				}
			}
		}
		else {
			 data->Circle_32R.erase(it--);
		}
	}
}

void MMCODFindOutlier::FindNeiFromPDList(TStream& tstream, Test& test, DataObj* data)
{
	int ExpDataId = tstream.GetDataStreamBegin();
	int dimension = test.GetDimension();
	double R = test.GetR();
	int K = test.GetK();
	double dis = 0;
	for (auto it = PD.begin(); it != PD.end(); it++) {
		if ((*it)->id < ExpDataId) {
			PD.erase(it--);
		}
		else {
			if (data->id != (*it)->id) {
				dis = calculateDistanceById(tstream, test, data->id, (*it)->id);
				if (dis <= R) {
					if ((*it)->id > data->id) {
						data->LaterNei.insert((*it)->id);
						(*it)->PreNei.insert(data->id);
					}
					else {
						data->PreNei.insert((*it)->id);
						(*it)->LaterNei.insert(data->id);
					}
				}
			}
			if (data->getNN() >= 1.5 * K)
				return;
		}
	}
}

void MMCODFindOutlier::FindNeiFromNewDataList(TStream& tstream, Test& test, DataObj* data) {
	int ExpDataId = tstream.GetDataStreamBegin();
	int dimension = test.GetDimension();
	double R = test.GetR();
	int K = test.GetK();
	double dis = 0;
	for (auto it = newDataObjList.begin(); it != newDataObjList.end(); it++) {
		if ((*it)->id < ExpDataId) {
			newDataObjList.erase(it--);
		}
		else {
			if (data->id != (*it)->id) {
				dis = calculateDistanceById(tstream, test, data->id, (*it)->id);
				if (dis <= R) {
					if ((*it)->id > data->id) {
						data->LaterNei.insert((*it)->id);
						(*it)->PreNei.insert(data->id);
					}
					else {
						data->PreNei.insert((*it)->id);
						(*it)->LaterNei.insert(data->id);
					}
				}
			}
			if (data->getNN() >= 1.5 * K)
				return;
		}
	}
}

void MMCODFindOutlier::Update(TStream& tstream, Test& test)
{
	int dimension = test.GetDimension();
	int slideSum = test.GetWindowSize() / dimension / test.GetInFlow();
	int windowSize = test.GetWindowSize() / dimension;
	int NewPointId = tstream.GetDataStreamTag();
	int NewPointNum = tstream.GetInflow(slideSum);
	int DataStreamLength = (tstream.GetDataStreamLength() / dimension) - (tstream.GetDataStreamTag());
	int end = DataStreamLength / test.GetInFlow();
	int countSize = windowSize / test.GetInFlow();
	double R = test.GetR();
	clock_t startTime1, endTime1;
	startTime1 = clock();
	int DealDataNum = 0;
	int OutlierSetSum = 0;
	int upperbound = windowSize * 0.02;
	int lowerbound = windowSize * 0.005;
	for (int i = 0; i < end; i++) {
		if (i % countSize == 0 && i != 0)
		{
			endTime1 = clock();
			cout << "Current cursor" << tstream.GetDataStreamBegin() << "     Time = " << (double)(endTime1 - startTime1) / CLOCKS_PER_SEC << "s" << endl;
			startTime1 = endTime1;
		}
		WindowBegin.emplace(slideSum + SlideStart, tstream.GetDataStreamTag());
		tstream.AddDataStreamBegin(tstream.GetInflow(i));
		tstream.AddDataStreamTag(tstream.GetInflow(SlideStart + slideSum));
		SlideStart++;
		
		Slide1& oldSlide = slideVec[0];
		for (int k = NewPointId; k < tstream.GetDataStreamTag(); k++) {
			DataObj* data = new DataObj;
			bool flag = false;
			data->id = k;
			data->slideID = slideSum + SlideStart - 1;
			data->LaterNei.clear();
			PointSet[k] = data;
			flag = AddDataTomTreeNode(tstream, test, data, root);
			if (!flag)
				newDataObjList.push_back(data);
		}
		DealATCircle(tstream, test, oldSlide);
		DealNewData2(tstream, test);
		DealATPoint(tstream, test, oldSlide);
		if (test.GetInFlow() != windowSize) {
			for (int j = 0; j < (slideNum - 1); ++j) {
				slideVec[j] = slideVec[j + 1];
			}
			Slide1 newSlide;
			slideVec[slideNum - 1] = newSlide;
		}
		newDataObjList.clear();
		NewDataInCircle.clear();
		NewPointId = tstream.GetDataStreamTag();
		if (OutlierSet.size() < lowerbound || OutlierSet.size() > upperbound) {
			ChangeR(tstream, test);
		}
	}
}


bool MMCODFindOutlier::AddDataTomTreeNode(TStream& tstream, Test& test, DataObj* data, CircleObj* root)
{
	bool flag = false;
	queue<CircleObj*> CheckNodeQueue;
	double minDis = DBL_MAX;
	double dis;
	double D;
	double r = test.GetR();
	CheckNodeQueue.push(root);
	CircleObj* temNode = nullptr;
	while (!CheckNodeQueue.empty()) {
		temNode = CheckNodeQueue.front();
		if (temNode->childrenNode.size() == 0) {
			for (CircleObj* CircleNode : temNode->NodeList) {
				dis = calculateDistanceBycoordinate(tstream, test, data->id, CircleNode->CenterCircle);
				if (dis <= 0.5 * r) {
					flag = true;
					data->Circle_R.push_back(CircleNode->Cid);
					CircleNode->Datalist.push_back(data);
				}
				else if (dis <= 1.5 * r) {
					data->Circle_32R.push_back(CircleNode->Cid);
				}
			}
		}
		else {
			for (auto node : temNode->childrenNode) {
				dis = calculateDistanceBycoordinate(tstream, test, data->id, node->CenterCircle) - node->radius;
				if (dis <= 1.5 * r) {
					CheckNodeQueue.push(node);
				}
			}
		}
		CheckNodeQueue.pop();
	}
	return flag;
}

void MMCODFindOutlier::DealNewData2(TStream& tstream, Test& test) {
	int ExpDataId = tstream.GetDataStreamBegin();
	int NewDataId = tstream.GetDataStreamTag() - tstream.GetInflow(slideNum + SlideStart - 1);
	int k = test.GetK();
	double R = test.GetR();
	double dis = 0;
	bool flag = false; 
	int NN_R2 = 0; 
	list<int>NewCircleList;
	NewCircleList.clear();
	for (auto it = newDataObjList.begin(); it != newDataObjList.end(); it++) {
		NN_R2 = 0;
		flag = false;
		for (auto itt = NewCircleList.begin(); itt != NewCircleList.end(); itt++) {
			auto itt1 = CircleSet_12R.find(*itt);
			if (itt1 != CircleSet_12R.end()) {
				dis = calculateDistanceBycoordinate(tstream, test, (*it)->id, (*itt1).second->CenterCircle);
				if (dis <= 0.5 * R) {
					(*itt1).second->Datalist.push_back(*it);
					(*it)->Circle_R.push_back((*itt1).second->Cid);
					flag = true;
				}
				else if (dis <= 1.5 * R) {
					(*it)->Circle_32R.push_back((*itt1).second->Cid);
				}
			}
		}
		if (!flag) {
			for (auto itt2 = (*it)->PreNei.begin(); itt2 != (*it)->PreNei.end();) {
				if ((*itt2) < ExpDataId) {
					itt2 = (*it)->PreNei.erase(itt2);
				}
				else
					break;
			}
			for (auto it1 = PD.begin(); it1 != PD.end(); it1++) {
				if ((*it1)->id >= ExpDataId) {
					dis = calculateDistanceById(tstream, test, (*it)->id, (*it1)->id);
					if (dis <= 0.5 * R) {
						NN_R2++;
					}
					if (dis <= R) {
						if ((*it)->id > (*it1)->id) {
							(*it)->PreNei.insert((*it1)->id);
							(*it1)->LaterNei.insert((*it)->id);
						}
						else {
							(*it)->LaterNei.insert((*it1)->id);
							(*it1)->PreNei.insert((*it)->id);
						}
					}
					if (NN_R2 >= k + 1)
						break;
				}
				else {
					PD.erase(it1--);
				}
			}
			if (NN_R2 >= k + 1) {
				FormNewCircle(tstream, test, (*it));
				NewCircleList.push_back((*it)->id);
				flag = true;
				continue;
			}
			FindNeiFrom23RCircle(tstream, test, (*it));
			if ((*it)->getNN() >= k) {
				if ((*it)->LaterNei.size() < k) {
					int ii = (*it)->PreNei.size() - (k - (*it)->LaterNei.size());
					auto time = next((*it)->PreNei.begin(), ii);
					int i = 0;
					if ((*time) >= NewDataId)
						i = PointSet[(*time)]->slideID - SlideStart;
					else
						i = PointSet[(*time)]->slideID - SlideStart; + 1;
					slideVec[i].needDealDataObj.push_back((*it));
				}
			}
			else {
				FindNeiFromNewDataList(tstream, test, (*it));
				if ((*it)->getNN() >= k) {
					if ((*it)->LaterNei.size() < k) {
						int ii = (*it)->PreNei.size() - (k - (*it)->LaterNei.size());
						auto time = next((*it)->PreNei.begin(), ii);
						int i = 0;
						if ((*time) >= NewDataId)
							i = PointSet[(*time)]->slideID - SlideStart;
						else
							i = PointSet[(*time)]->slideID - SlideStart + 1;
						slideVec[i].needDealDataObj.push_back((*it));
					}
				}
				else {
					OutlierSet.insert(*it);
				}
			}

		}
		if (!flag)
			PD.push_back(*it);
	}
}

void MMCODFindOutlier::TestFormNewCircle(TStream& tstream, Test& test, DataObj* NewData) {
	int k = test.GetK();
	double R = test.GetR();
	vector<double>coordinates;
	coordinates = GetDataCoordinate(tstream, test, NewData->id);
	CircleObj* newCircle = new CircleObj;
	newCircle->Cid = NewData->id;
	newCircle->CenterCircle = coordinates;
	newCircle->radius = 0.5 * R;
	newCircle->Datalist.push_back(NewData);
	int ExpDataId = tstream.GetDataStreamBegin();
	auto it = distanceMap.find(NewData);
	for (auto itt = (*it).second.begin(); itt != (*it).second.end(); itt++) {
		if ((*itt)->id > ExpDataId) {
			newCircle->Datalist.push_back(*itt);
			(*itt)->Circle_R.push_back(newCircle->Cid);
		}
		else
			(*it).second.erase(itt--);
	}
	if (newCircle->Datalist.size() < k + 1)
		return;
	double dis = 0;
	for (auto it = newDataObjList.begin(); it != newDataObjList.end(); it++) {
		dis = calculateDistanceBycoordinate(tstream, test, (*it)->id, newCircle->CenterCircle);
		if (dis <= 0.5 * R) {
			newDataObjList.erase(it--);
		}
		else if (dis <= 1.5 * R) {
			(*it)->Circle_32R.push_back(newCircle->Cid);
		}
	}
	int i = newCircle->Datalist.size() - k - 1;
	auto time = next(newCircle->Datalist.begin(), i);
	int j = 0;
	if ((*time)->id >= tstream.GetDataStreamTag() - test.GetInFlow())
		j = (*time)->id / test.GetInFlow() - SlideStart;
	else
		j = (*time)->id / test.GetInFlow() - SlideStart + 1;
	slideVec[j].needDealCircleObj.push_back(newCircle->Cid);
	CircleSet_12R.emplace(NewData->id, newCircle);
	if (BulitMtree)
		NewCireAddToMTree(tstream, test, newCircle);
}

void MMCODFindOutlier::ChangeRInit(TStream& tstream, Test& test)
{
	slideNum = test.GetWindowSize() / test.GetDimension() / test.GetInFlow();
	slideVec.resize(slideNum);
	CreateCircle(tstream, test);
	PutDataInCircle(tstream, test);
	DealCirCle(tstream, test);
	splitmTree(tstream, test);
	BulitMtree = true;
	findOutlier(tstream, test);
	int windowSize = tstream.GetDataStreamTag() - tstream.GetDataStreamBegin();
	int upperbound = windowSize * 0.02;
	int lowerbound = windowSize * 0.005;
	int Threshold = OutlierSet.size();
	if (Threshold > lowerbound || Threshold < upperbound) {
		ChangeR(tstream, test);
	}
}

void MMCODFindOutlier::ReInit(TStream& tstream, Test& test)
{
	root = nullptr;
	CircleSet_12R.clear();
	PD.clear();
	distanceMap.clear();
	OutlierSet.clear();
	slideVec.clear();
	slideNum = test.GetWindowSize() / test.GetDimension() / test.GetInFlow();
	slideVec.resize(slideNum);
	ChangeRCreateCircle(tstream, test);
	ChangeRPutDataInCircle(tstream, test);
	DealCirCle(tstream, test);
	splitmTree(tstream, test);
	BulitMtree = true;
	findOutlier(tstream, test);
}

void MMCODFindOutlier::LowerBound(TStream& tstream, Test& test)
{
	int nPoints = (tstream.GetDataStreamTag() - tstream.GetDataStreamBegin()) * 0.01;
	set<DataObj*>data;
	vector<pair<int, CircleObj*>>vec(CircleSet_12R.begin(), CircleSet_12R.end());
	int k = test.GetK();
	int minDataNumCircle = -1;
	if (PD.size() > nPoints) {
		for (auto it = PD.begin(); it != PD.end(); it++) {
			data.insert(*it);
			if (data.size() == 1.5 * nPoints)
				break;
		}
	}
	else {
		for (auto it = PD.begin(); it != PD.end(); it++) {
			data.insert(*it);
		}
		sort(vec.begin(), vec.end(), [](const std::pair<int, CircleObj*>& a, const std::pair<int, CircleObj*>& b) {
			return a.second->Datalist.size() < b.second->Datalist.size();
			});
		for (auto it = vec.begin(); it != vec.end(); it++) {
			for (auto it1 = (*it).second->Datalist.begin(); it1 != (*it).second->Datalist.end(); it1++) {
				data.insert(*it1);
				if (data.size() >= 1.5 * nPoints)
					break;
			}
			if (data.size() >= 1.5 * nPoints)
				break;
		}
	}
	int i = 0;
	vector<double> kthDistances(data.size());
	for (auto it1 = data.begin(); it1 != data.end(); ++it1, ++i) {
		kthDistances[i] = FindKNNForOutlier(tstream, test, (*it1));
	}
	sort(kthDistances.begin(), kthDistances.end(),compareGreater);
	test.SetR(kthDistances[nPoints]);
}

void MMCODFindOutlier::UpperBound(TStream& tstream, Test& test)
{
	int nPoints = (tstream.GetDataStreamTag() - tstream.GetDataStreamBegin() ) * 0.01;
	vector<DataObj*>data;
	int i = 0;
	int k = test.GetK();
	for (auto it = OutlierSet.begin(); it != OutlierSet.end(); it++) {
		data.push_back(*it);
	}
	vector<double> kthDistances(data.size());
	for (int i = 0; i < data.size(); ++i) {
		kthDistances[i] = FindKNNForOutlier(tstream, test, data[i]);
	}
	sort(kthDistances.begin(), kthDistances.end(), compareGreater);
	test.SetR(kthDistances[nPoints - 1]);

}

void MMCODFindOutlier::ChangeR(TStream& tstream, Test& test)
{
	int windowSize = tstream.GetDataStreamTag() - tstream.GetDataStreamBegin();
	int upperbound = windowSize * 0.02;
	int lowerbound = windowSize * 0.005;
	double oldR = test.GetR();
	int outlierNum = OutlierSet.size();
	while (true) {
		if (OutlierSet.size() < lowerbound) {
			LowerBound(tstream, test);
		}
		else if (OutlierSet.size() > upperbound) {
			UpperBound(tstream, test);
		}
		else {
			break;
		}
		ReInit(tstream, test);
	}
	
}

void MMCODFindOutlier::ChangeRCreateCircle(TStream& tstream, Test& test)
{
	int dim = test.GetDimension();
	int slidesum = test.GetWindowSize() / dim / test.GetInFlow();
	double R = test.GetR();
	int dataFront = 0;
	int dataBack = 0;
	vector<double>coordinates;
	for (int i = SlideStart; i < SlideStart + slidesum; i++) {
		int start = WindowBegin[i];
		dataBack = start + tstream.GetInflow(i);
		for (int j = start; j < dataBack; j++) {
			bool flag = false;
			coordinates.clear();
			coordinates = GetDataCoordinate(tstream, test, j);
			for (auto& Circle : CircleSet_12R) {
				if (calculateDistanceBycoordinate(tstream, test, j, Circle.second->CenterCircle) <= 0.5 * R) {
					flag = true;
					break;
				}
			}
			if (!flag) {
				CircleObj* newCircle = new CircleObj;
				newCircle->Cid = j;
				newCircle->radius = 0.5 * R;
				newCircle->CenterCircle = coordinates;
				newCircle->depth = 0;
				CircleSet_12R.emplace(j, newCircle);
			}
		}
	}
}

void MMCODFindOutlier::ChangeRPutDataInCircle(TStream& tstream, Test& test)
{
	int dimension = test.GetDimension();
	int slideSum = test.GetWindowSize() / dimension / test.GetInFlow();
	double R = test.GetR();
	vector<double>coordinates;
	int dataFront = 0;
	int dataBack = 0;
	for (int i = SlideStart + 0; i < SlideStart + slideSum; i++) {
		int start = WindowBegin[i];
		dataBack = start + tstream.GetInflow(i);
		for (int j = start; j < dataBack; j++) {
			DataObj* data = new DataObj;
			data->id = j;
			data->slideID = i;
			data->LaterNei.clear();
			data->PreNei.clear();
			PointSet[j] = data;
			coordinates.clear();
			coordinates = GetDataCoordinate(tstream, test, j);
			for (auto& Circle : CircleSet_12R) {
				double dis = calculateDistanceBycoordinate(tstream, test, j, Circle.second->CenterCircle);
				if (dis <= 0.5 * R) {
					Circle.second->Datalist.push_back(data);
					data->Circle_R.push_back(Circle.second->Cid);
				}
				else if (dis <= 1.5 * R) {
					data->Circle_32R.push_back(Circle.second->Cid);
				}
			}
		}
	}
}

double MMCODFindOutlier::FindKNN(TStream& tstream, Test& test, DataObj* Outlier)
{
	queue<CircleObj*> CheckNodeQueue;
	double minDis = DBL_MAX;
	double dis;
	double D;
	double r = test.GetR();
	int k = test.GetK();
	CheckNodeQueue.push(root);
	CircleObj* temNode = nullptr;
	priority_queue<double> pq;
	while (!CheckNodeQueue.empty()) {
		temNode = CheckNodeQueue.front();
		if (temNode->childrenNode.size() == 0) {
			for (CircleObj* CircleNode : temNode->NodeList) {
				for (DataObj* data : CircleNode->Datalist) {
					double distance = calculateDistanceById(tstream, test, Outlier->id, data->id);
					if (pq.size() < k) {
						pq.push(distance);
					}
					else if (distance < pq.top()) {
						pq.pop();
						pq.push(distance);
					}
				}
			}
		}
		else {
			for (auto node : temNode->childrenNode) {
				dis = calculateDistanceBycoordinate(tstream, test, Outlier->id, node->CenterCircle) - node->radius;
				if (dis <= 1.5*r) {
					CheckNodeQueue.push(node);
				}
			}
		}
		CheckNodeQueue.pop();
	}
	if (pq.size() == k) {
		double kthDistance = pq.top();
		return kthDistance;
	}
}

double MMCODFindOutlier::FindKNNForOutlier(TStream& tstream, Test& test, DataObj* Outlier)
{
	queue<CircleObj*> CheckNodeQueue;
	double minDis = DBL_MAX;
	double dis;
	double D;
	double r = test.GetR();
	int k = test.GetK();
	CheckNodeQueue.push(root);
	CircleObj* temNode = nullptr;
	priority_queue<double> pq;
	for (auto it = PD.begin(); it != PD.end(); it++) {
		if ((*it)->id != Outlier->id) {
			double distance = calculateDistanceById(tstream, test, (*it)->id, Outlier->id);
			if (pq.size() < k) {
				pq.push(distance);
			}
			else if (distance < pq.top()) {
				pq.pop();
				pq.push(distance);
			}
		}
	}

	while (!CheckNodeQueue.empty()) {
		temNode = CheckNodeQueue.front();
		if (temNode->childrenNode.size() == 0) {
			for (CircleObj* CircleNode : temNode->NodeList) {
				for (DataObj* data : CircleNode->Datalist) {
					double distance = calculateDistanceById(tstream, test, Outlier->id, data->id);
					if (pq.size() < k) {
						pq.push(distance);
					}
					else if (distance < pq.top()) {
						pq.pop();
						pq.push(distance);
					}
				}
			}
		}
		else {
			for (auto node : temNode->childrenNode) {
				dis = calculateDistanceBycoordinate(tstream, test, Outlier->id, node->CenterCircle) - node->radius;
				if (dis <= 0) {
					CheckNodeQueue.push(node);
				}
			}
		}
		CheckNodeQueue.pop();
	}
	if (pq.size() == k) {
		double kthDistance = pq.top();
		return kthDistance;
	}
}

double MMCODFindOutlier::FindKNNForOutlierLower(TStream& tstream, Test& test, DataObj* Outlier, set<DataObj*>& data) {
	queue<CircleObj*> CheckNodeQueue;
	double minDis = DBL_MAX;
	double dis;
	double D;
	double r = test.GetR();
	int k = test.GetK();
	CheckNodeQueue.push(root);
	CircleObj* temNode = nullptr;
	priority_queue<double> pq;
	
	for (auto it1 = data.begin(); it1 != data.end(); ++it1) {
		if(Outlier->id != (*it1)->id){
			double distance = calculateDistanceById(tstream, test, (*it1)->id, Outlier->id);
			if (pq.size() < k) {
				pq.push(distance);
			}
			else if (distance < pq.top()) {
				pq.pop();
				pq.push(distance);
			}
		}
	}

	while (!CheckNodeQueue.empty()) {
		temNode = CheckNodeQueue.front();
		if (temNode->childrenNode.size() == 0) {
			for (CircleObj* CircleNode : temNode->NodeList) {
				for (DataObj* data : CircleNode->Datalist) {
					double distance = calculateDistanceById(tstream, test, Outlier->id, data->id);
					if (pq.size() < k) {
						pq.push(distance);
					}
					else if (distance < pq.top()) {
						pq.pop();
						pq.push(distance);
					}
				}
			}
		}
		else {
			for (auto node : temNode->childrenNode) {
				dis = calculateDistanceBycoordinate(tstream, test, Outlier->id, node->CenterCircle) - node->radius;
				if (dis <= r) {
					CheckNodeQueue.push(node);
				}
			}
		}
		CheckNodeQueue.pop();
	}
	if (pq.size() == k) {
		double kthDistance = pq.top();
		return kthDistance;
	}
}

void MMCODFindOutlier::calculateMemoryUsage(TStream& tstream, Test& test, const DataObj* node)
{
	totalMemoryUsage += sizeof(node->id);
	for (auto it = node->PreNei.begin(); it != node->PreNei.end(); it++) {
		totalMemoryUsage += sizeof(*it);
	}
	int LaterCount = node->LaterNei.size();
	totalMemoryUsage += sizeof(LaterCount);
}

void MMCODFindOutlier::FormNewCircle(TStream& tstream, Test& test, DataObj* NewData) 
{
	int k = test.GetK();
	double R = test.GetR();
	vector<double>coordinates;
	coordinates = GetDataCoordinate(tstream, test, NewData->id);
	CircleObj* newCircle = new CircleObj;
	newCircle->Cid = NewData->id;
	newCircle->CenterCircle = coordinates;
	newCircle->radius = 0.5 * R;
	int NewDataId = tstream.GetDataStreamTag() - tstream.GetInflow(slideNum + SlideStart - 1);
	int ExpDataId = tstream.GetDataStreamBegin();
	double dis = 0;
	for (auto it = PD.begin(); it != PD.end(); it++) {
		dis = calculateDistanceBycoordinate(tstream, test, (*it)->id, newCircle->CenterCircle);
		if (dis <= 0.5 * R) {
			newCircle->Datalist.push_back(*it);
			(*it)->Circle_R.push_back(newCircle->Cid);
			PD.erase(it--);
		}
		else if (dis <= 1.5 * R) {
			(*it)->Circle_32R.push_back(newCircle->Cid);
		}
	}
	if (newCircle->Datalist.size() < k + 1)
		return;
	int i = newCircle->Datalist.size() - k - 1;
	auto time = next(newCircle->Datalist.begin(), i);
	int j = 0;
	if((*time)->id >= NewDataId)
		j = (*time)->slideID - SlideStart;
	else
		j = (*time)->slideID - SlideStart + 1; 
	if (NewData->id >= NewDataId)
		newCircle->Datalist.push_back(NewData);
	slideVec[j].needDealCircleObj.push_back(newCircle->Cid);
	CircleSet_12R.emplace(NewData->id, newCircle);
	if (BulitMtree)
		NewCireAddToMTree(tstream, test, newCircle);
}

void MMCODFindOutlier::NewCireAddToMTree(TStream& tstream, Test& test, CircleObj* NewCircle)
{
	CircleObj* temNode = root;
	double R = test.GetR();
	double minDis = DBL_MAX;
	double minToIncrease = DBL_MAX;
	double disToLeafNode;
	double disTochildrenNode;
	double increase;
	CircleObj* nodeTemInRadius = nullptr;
	CircleObj* nodeTemToIncress = nullptr;
	CircleObj* targetNode = nullptr;
	while (true) {
		minDis = DBL_MAX;
		minToIncrease = DBL_MAX;
		nodeTemInRadius = nullptr;
		nodeTemToIncress = nullptr;
		if (temNode->childrenNode.size() == 0) {
			temNode->NodeList.push_back(NewCircle);
			NewCircle->parentNode = temNode;
			NewCircle->depth = temNode->depth + 1;
			disToLeafNode = calculateDistanceBetweenTwoData(tstream, test, temNode->CenterCircle, NewCircle->CenterCircle);
			temNode->radius = max(disToLeafNode, temNode->radius + 0.5 * R);
			targetNode = temNode;
			break;
		}
		else {
			for (auto child : temNode->childrenNode) {
				disTochildrenNode = calculateDistanceBetweenTwoData(tstream, test, child->CenterCircle, NewCircle->CenterCircle);
				if (disTochildrenNode <= child->radius && disTochildrenNode <= minDis) {
					nodeTemInRadius = child;
					minDis = disTochildrenNode;
				}
				else {
					increase = disTochildrenNode - child->radius;
					if (increase < minToIncrease) {
						nodeTemToIncress = child;
						minToIncrease = increase;
					}
				}
			}
			if (nodeTemInRadius != nullptr) {
				temNode = nodeTemInRadius;
			}
			else {
				if ((minToIncrease + nodeTemToIncress->radius + 0.5 * R) >= nodeTemToIncress->parentNode->radius * 0.6) {
					targetNode = createNewMiddleNode(tstream, test, nodeTemToIncress->parentNode, NewCircle);
					break;
				}
				else {
					temNode = nodeTemToIncress;
					temNode->radius = minToIncrease + temNode->radius + 0.5 * R;
				}
			}
		}
	}
	Update32RCirecleList(tstream, test, NewCircle);
}

MMCODFindOutlier::CircleObj* MMCODFindOutlier::createNewMiddleNode(TStream& tstream, Test& test, CircleObj* NewCircleParent, CircleObj* NewCircle)
{
	CircleObj* newMiddleNode = new CircleObj;
	NewCircle->parentNode = newMiddleNode;
	newMiddleNode->CenterCircle = NewCircle->CenterCircle;
	newMiddleNode->NodeList.push_back(NewCircle);
	newMiddleNode->distoparent = calculateDistanceBetweenTwoData(tstream, test, newMiddleNode->CenterCircle, NewCircleParent->CenterCircle);
	newMiddleNode->parentNode = NewCircleParent;
	newMiddleNode->radius = NewCircleParent->radius * 0.5;
	NewCircle->distoparent = calculateDistanceBetweenTwoData(tstream, test, NewCircle->CenterCircle, newMiddleNode->CenterCircle);
	NewCircleParent->childrenNode.push_back(newMiddleNode);
	NewCircleParent->radius = max(NewCircleParent->radius, newMiddleNode->distoparent + newMiddleNode->radius);
	return newMiddleNode;
}

void MMCODFindOutlier::Update32RCirecleList(TStream& tstream, Test& test, CircleObj* NewCircle)
{
	double R = test.GetR();
	double dis = 0;
	for (auto it = CircleSet_12R.begin(); it != CircleSet_12R.end(); it++) {
		if ((*it).second->Cid != NewCircle->Cid) {
			for (auto it1 = (*it).second->Datalist.begin(); it1 != (*it).second->Datalist.end(); it1++) {
				dis = calculateDistanceBycoordinate(tstream, test, (*it1)->id, NewCircle->CenterCircle);
				if (dis <= 0.5 * R)
					(*it1)->Circle_R.push_back(NewCircle->Cid);
				else if (dis <= 1.5 * R) {
					(*it1)->Circle_32R.push_back(NewCircle->Cid);
				}
			}
		}
	}
}

void MMCODFindOutlier::Check32RFromMTree(TStream& tstream, Test& test, DataObj* data, CircleObj* root)
{
	queue<CircleObj*> CheckNodeQueue;
	double minDis = DBL_MAX;
	double dis;
	double D;
	double r = test.GetR();
	CheckNodeQueue.push(root);
	CircleObj* temNode = nullptr;
	while (!CheckNodeQueue.empty()) {
		temNode = CheckNodeQueue.front();
		if (temNode->childrenNode.size() == 0) {
			for (CircleObj* CircleNode : temNode->NodeList) {
				dis = calculateDistanceBycoordinate(tstream, test, data->id, CircleNode->CenterCircle);
				if (dis >= 0.5 * r && dis <= 1.5 * r) {
					data->Circle_32R.push_back(CircleNode->Cid);
				}
			}
		}
		else {
			for (auto node : temNode->childrenNode) {
				dis = calculateDistanceBycoordinate(tstream, test, data->id, node->CenterCircle) - node->radius;
				if (dis <= 1.5 * r) {
					CheckNodeQueue.push(node);
				}
			}
		}
		CheckNodeQueue.pop();
	}
}

void MMCODFindOutlier::DealATCircle(TStream& tstream, Test& test, Slide1& Expslide)
{
	int ExpDataId = tstream.GetDataStreamBegin();
	int k = test.GetK();
	int NewDataId = tstream.GetDataStreamTag() - tstream.GetInflow(slideNum + SlideStart - 1);
	list<int>tempCircle;
	int WindowSize = test.GetWindowSize() / test.GetDimension();
	for (auto& data : Expslide.needDealCircleObj) {
		auto it = CircleSet_12R.find(data);
		if (it != CircleSet_12R.end()) {
			(*it).second->sortDatalist();
			for (auto it1 = (*it).second->Datalist.begin(); it1 != (*it).second->Datalist.end(); ) {
				if ((*it1)->id < ExpDataId) {
					it1 = (*it).second->Datalist.erase(it1);
				}
				else
					break;
			}
			if ((*it).second->Datalist.size() < k + 1) {
				for (auto it1 = (*it).second->Datalist.begin(); it1 != (*it).second->Datalist.end(); it1++) {
					for (auto it2 = (*it1)->Circle_R.begin(); it2 != (*it1)->Circle_R.end(); ) {
						if (CircleSet_12R.find(*it2) == CircleSet_12R.end()) {
							it2 = (*it1)->Circle_R.erase(it2);
						}
						if ((*it2) == (*it).second->Cid) {
							it2 = (*it1)->Circle_R.erase(it2);
						}
						else {
							it2++;
						}
					}
					if ((*it1)->Circle_R.size() == 0) {
						newDataObjList.push_back((*it1));
					}
				}
				CircleObj* Node = new CircleObj;
				Node = (*it).second->parentNode;
				for (auto it1 = Node->NodeList.begin(); it1 != Node->NodeList.end(); it1++) {
					if ((*it1)->Cid == (*it).second->Cid) {
						Node->NodeList.erase(it1);
						break;
					}
				}
				it = CircleSet_12R.erase(it);
			}
			else {
				if (test.GetInFlow() == WindowSize)
					tempCircle.push_back((*it).first);
				else {
					int i = (*it).second->Datalist.size() - k - 1;
					auto time = next((*it).second->Datalist.begin(), i);
					int j = 0;
					if ((*time)->id >= NewDataId)
						j = (*time)->slideID - SlideStart;
					else
						j = (*time)->slideID - SlideStart + 1;
					if (j != 0)
						slideVec[j].needDealCircleObj.push_back((*it).second->Cid);
					else
						slideVec[slideNum - 1].needDealCircleObj.push_back((*it).second->Cid);
				}
			}
		}
	}
	
	if (test.GetInFlow() == WindowSize)
		slideVec[0].needDealCircleObj = tempCircle;
}

void MMCODFindOutlier::DealATPoint(TStream& tstream, Test& test, Slide1& Expslide)
{
	int ExpDataId = tstream.GetDataStreamBegin();
	int k = test.GetK();
	int NewDataId = tstream.GetDataStreamTag() - tstream.GetInflow(slideNum + SlideStart - 1);
	list<DataObj*>TempData;
	list<DataObj*>TempOutlier;
	int WindowSize = test.GetWindowSize() / test.GetDimension();
	for (auto Outlier = OutlierSet.begin(); Outlier != OutlierSet.end(); ) {
		if ((*Outlier)->id >= ExpDataId) {
			for (auto it = (*Outlier)->PreNei.begin(); it != (*Outlier)->PreNei.end();) {
				if ((*it) < ExpDataId) {
					it = (*Outlier)->PreNei.erase(it);
				}
				else
					break;
			}
			FindNeiFrom23RCircle(tstream, test, (*Outlier));
			if ((*Outlier)->getNN() >= k) {
				if ((*Outlier)->LaterNei.size() < k) {
					int i = (*Outlier)->PreNei.size() - k + (*Outlier)->LaterNei.size();
					auto time = next((*Outlier)->PreNei.begin(), i);
					int j = 0;
					if ((*time) >= NewDataId)
						j = PointSet[(*time)]->slideID - SlideStart;
					else
						j = PointSet[(*time)]->slideID - SlideStart + 1;
					slideVec[j].needDealDataObj.push_back((*Outlier));
				}
				Outlier = OutlierSet.erase(Outlier);
			}
			else {
				FindNeiFromPDList(tstream, test, (*Outlier));
				if ((*Outlier)->getNN() >= k) {
					if ((*Outlier)->LaterNei.size() < k) {
						int i = (*Outlier)->PreNei.size() - k + (*Outlier)->LaterNei.size();
						auto time = next((*Outlier)->PreNei.begin(), i);
						int j = 0;
						if ((*time) >= NewDataId)
							j = PointSet[(*time)]->slideID - SlideStart;
						else
							j = PointSet[(*time)]->slideID - SlideStart + 1;
						slideVec[j].needDealDataObj.push_back((*Outlier));
					}
					Outlier = OutlierSet.erase(Outlier);
				}
				else
					Outlier++;
			}

		}
		else
			Outlier = OutlierSet.erase(Outlier);
	}
	for (auto& Inlierdata : Expslide.needDealDataObj) {
		if (Inlierdata->id >= ExpDataId) {
			for (auto it = Inlierdata->PreNei.begin(); it != Inlierdata->PreNei.end();) {
				if ((*it) < ExpDataId) {
					it = Inlierdata->PreNei.erase(it);
				}
				else
					break;
			}
			FindNeiFrom23RCircle(tstream, test, Inlierdata);
			if (Inlierdata->getNN() >= k) {
				if (Inlierdata->LaterNei.size() < k) {
					if (test.GetInFlow() == WindowSize)
						TempData.push_back(Inlierdata);
					else {
						int i = Inlierdata->PreNei.size() - k + Inlierdata->LaterNei.size();
						auto time = next(Inlierdata->PreNei.begin(), i);
						int j = 0;
						if ((*time) >= NewDataId)
							j = PointSet[(*time)]->slideID - SlideStart ;
						else
							j = PointSet[(*time)]->slideID - SlideStart + 1;
						if(j!=0)
							slideVec[j].needDealDataObj.push_back(Inlierdata);
						else
							slideVec[slideNum - 1].needDealDataObj.push_back(Inlierdata);
					}
				}
			}
			else {
				FindNeiFromPDList(tstream, test, Inlierdata);
				if (Inlierdata->getNN() >= k) {
					if (Inlierdata->LaterNei.size() < k) {
						if (test.GetInFlow() == WindowSize)
							TempData.push_back(Inlierdata);
						else {
							int i = Inlierdata->PreNei.size() - k + Inlierdata->LaterNei.size();
							auto time = next(Inlierdata->PreNei.begin(), i);
							int j = 0;
							if ((*time) >= NewDataId)
								j = PointSet[(*time)]->slideID - SlideStart;
							else
								j = PointSet[(*time)]->slideID - SlideStart + 1;
							if (j != 0)
								slideVec[j].needDealDataObj.push_back(Inlierdata);
							else
								slideVec[slideNum - 1].needDealDataObj.push_back(Inlierdata);
						}
					}
				}
				else {
					OutlierSet.insert(Inlierdata);
				}
			}
		}
	}
	if (test.GetInFlow() == WindowSize)
		slideVec[0].needDealDataObj = TempData;
}






