#include<iostream>
#include<stdio.h>
#include"Test.h"
#include"TStream.h"
#include"MMCOD.h"
#include<fstream>
#pragma warning(disable:4996)

void printlogmain(TStream& tstream, Test& test, double time1, double time2) {
	ofstream data;
	data.open("log_mainMMCOD.txt", ofstream::app);
	data << "WindowSize:" << test.GetWindowSize() << endl;
	data << "K= " << test.GetK() << "  " << "R= " << test.GetR() << "  " << endl;
	data << "InitTime��" << time1 << "s" << endl;
	data << "RunningTime��" << time2 << "s" << endl;
	data.close();
}

int main()
{
	clock_t startTime, endTime, createTime;
	double initTime;
	for (int j = 0; j < 6; j++) {
		Test t;
		TStream tstream;
		vector<Test> vecTestFile;
		t.Init(vecTestFile, j);
		tstream.Init(vecTestFile[j], j);
		for (int i = 0; i < vecTestFile.size(); i++) {
			MMCODFindOutlier MMCOD;
			tstream.SetDataStreamBegin(0);
			tstream.SetDataStreamTag(0);
			startTime = clock();
			MMCOD.ChangeRInit(tstream, vecTestFile[i]);
			endTime = clock();
			double time = (double)(endTime - startTime) / CLOCKS_PER_SEC * 1.000;
			initTime = (double)(endTime - startTime) / CLOCKS_PER_SEC * 1.000;
			cout << "Init Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC * 1.000 << 's' << endl;
			startTime = clock();
			MMCOD.Update(tstream, vecTestFile[i]);
			endTime = clock();
			cout << "Running Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
			printlogmain(tstream, vecTestFile[i], time, (double)(endTime - startTime) / CLOCKS_PER_SEC);
		}
	}
}