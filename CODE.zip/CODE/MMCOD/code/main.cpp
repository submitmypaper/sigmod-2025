#include<iostream>
#include<stdio.h>
#include"Test.h"
#include"TStream.h"
#include"MMCOD.h"
#include<fstream>
#pragma warning(disable:4996)

void printlogmain(TStream& tstream, Test& test, double time1, double time2) {
	ofstream data;
	data.open("log_mainMMCOD.txt", ofstream::app);
	data << "���ڴ�С:" << test.GetWindowSize() << " " << "�����ٶ�:" << test.GetInFlow() << " " << "�����ٶȣ�" << test.GetOutFlow() << endl;
	data << "K:" << test.GetK() << "  " << "R:" << test.GetR() << "  " << endl;
	data << "��ʼ��ʱ�䣺" << time1 << "s" << endl;
	data << "����ʱ�䣺" << time2 << "s" << endl;
	data.close();
}
void printlog(int id) {
	ofstream data;
	data.open("log_mainMMCOD.txt", ofstream::app);
	data << "dataset: ";
	switch (id) {
	case 0: {
		data << "GAS_10";
		break;
	}
	case 1: {
		data << "HPC_7";
		break;
	}
	case 2: {
		data << "TAO_3";
		break;
	}
	case 3: {
		data << "STK_2";
		break;
	}
	case 4: {
		data << "TRIP_3";
		break;
	}
	case 5: {
		data << "NORMAL_4";
		break;
	}
	case 6: {
		data << "EM_16";
		break;
	}
	};
	data << endl;
	data << "#####################################################################" << endl;
	data.close();
}
void printPara(int id) {
	/*����˳��KNSR*/
	ofstream data;
	data.open("log_mainMMCOD.txt", ofstream::app);
	data << "Para_";
	switch (id) {
	case 0: {
		data << "K";
		break;
	}
	case 1: {
		data << "N";
		break;
	}
	case 2: {
		data << "S";
		break;
	}
	case 3: {
		data << "R";
		break;
	}
	}
	data << endl << endl;
	data.close();
}

int main(int argc, char* argv[])
{
	int testnum = 0;
	int sfnum = 0;
	if (argc > 1) {
		testnum = stoi(argv[1]);
		sfnum = stoi(argv[2]);
	}
	clock_t startTime, endTime, createTime;
	double initTime;
	Test t;
	TStream tstream;
	vector<Test> vecTestFile;
	t.Init(vecTestFile, testnum);
	tstream.Init(vecTestFile[0], sfnum);
	printlog(sfnum);
	if (testnum % 5 == 0) {
		printPara(testnum % 20 / 5);
	}
	MMCODFindOutlier MMCOD;
	tstream.SetDataStreamBegin(0);
	tstream.SetDataStreamTag(vecTestFile[0].GetWindowSize() / vecTestFile[0].GetDimension());
	startTime = clock();
	MMCOD.InitCircle(tstream, vecTestFile[0]);
	endTime = clock();
	double time = (double)(endTime - startTime) / CLOCKS_PER_SEC * 1.000;
	initTime = (double)(endTime - startTime) / CLOCKS_PER_SEC * 1.000;
	cout << "Init Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC * 1.000 << 's' << endl;
	startTime = clock();
	MMCOD.Update(tstream, vecTestFile[0]);
	endTime = clock();
	cout << "Running Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
	printlogmain(tstream, vecTestFile[0], time, (double)(endTime - startTime) / CLOCKS_PER_SEC);
}