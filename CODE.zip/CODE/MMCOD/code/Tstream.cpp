#include "TStream.h"
#include <vector>
#include <list>
#include <queue>
#include <map>
#include <set>
#include <cassert>
#include <math.h>
#include <algorithm>
#include "MMCOD.h"
#include<stack>
#include<unordered_map>
#include <numeric> 
#include <string>
#pragma warning(disable:4996)
TStream::TStream()
{
}
TStream::~TStream()
{
}
void TStream::ReadDataFile(Test& test, int j)
{
	FILE* fp1;
	double dlNumber;
	int dimension = test.GetDimension();
	vector<double> minDimension(dimension, DBL_MAX);
	vector<double> maxDimension(dimension, 0.0);
	int i = 0;
	string a = to_string(j);
	string s = "SourceFile" + a + ".txt";
	if ((fp1 = fopen(s.data(), "r")) != NULL)
	{
		while (fscanf(fp1, "%lf", &dlNumber) != EOF)
		{
			if (dlNumber < minDimension[i % dimension]) {
				minDimension[i % dimension] = dlNumber;
			}
			if (dlNumber > maxDimension[i % dimension]) {
				maxDimension[i % dimension] = dlNumber;
			}
			i++;
			vecDataStream.push_back(dlNumber);
		}
	}
	maxSide = 0;
	for (i = 0; i < dimension; ++i) {
		if (maxSide < (maxDimension[i] - minDimension[i])) {
			maxSide = maxDimension[i] - minDimension[i];
		}
	}
	for (i = 0; i < dimension; ++i) {
		CentralCoordinate.push_back((maxDimension[i] + minDimension[i]) / 2);
	}
	FirstRadious = maxSide * sqrt(dimension) / 2;
}

double TStream::GetDataStream(int intObjectNumber)
{
	return vecDataStream[intObjectNumber];
}

vector<double> TStream::GetData(int dataId, int dimension) {
	vector<double> ans;
	for (int i = 0; i < dimension; ++i) {
		ans.push_back(vecDataStream[dimension * dataId + i]);
	}
	return ans;
}

double TStream::getDataInDimension(int id, int dimension, int targetDimension)
{
	return vecDataStream[dimension * id + targetDimension];
}

vector<double> TStream::GetCentralCoordinate()
{
	return CentralCoordinate;
}

double TStream::GetRadious()
{
	return FirstRadious;
}


int TStream::GetDataStreamLength()
{
	return vecDataStream.size();
}

int TStream::GetDataStreamBegin()
{
	return dataStreamBegin;
}

int TStream::GetDataStreamTag()
{
	return dataStreamTag;
}


void TStream::SetDataStreamBegin(int begin)
{
	dataStreamBegin = begin;
}

void TStream::SetDataStreamTag(int tag)
{
	dataStreamTag = tag;
}

void TStream::SetS_Change()
{
	string s = "change_s.txt";
	int tempS;
	FILE* fp;
	if ((fp = fopen(s.data(), "r")) != NULL) {
		while (fscanf(fp, "%d", &tempS) != EOF) {
			S_change.emplace_back(tempS);
		}
	}
}

int TStream::GetInflow(int idx)
{
	return S_change[idx];
}

vector<int> TStream::copyS_change()
{
	return S_change;
}

void TStream::Init(Test& test, int j)
{
	ReadDataFile(test, j);
	SetDataStreamTag(test.GetWindowSize() / test.GetDimension());
	SetDataStreamBegin(0);
	SetS_Change();
}

void TStream::AddDataStreamBegin(int outFlow)
{
	dataStreamBegin += outFlow;
}

void TStream::AddDataStreamTag(int inFlow)
{
	dataStreamTag += inFlow;
}

void TStream::AddPeakMemory(int addNum)
{
	PeakMemory += addNum;
}

int TStream::GetPeakMemory()
{
	return PeakMemory;
}

void TStream::SetPeakMemory(int initNum)
{
	PeakMemory = initNum;
}
