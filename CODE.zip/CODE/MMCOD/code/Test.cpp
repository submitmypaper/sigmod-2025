#include "Test.h"
#include<string>
#include<vector>
#pragma warning(disable:4996)

Test::Test()
{
}

Test::~Test()
{
}

int Test::GetDimension()
{
	return dimension;
}

double Test::GetR()
{
	return R;
}

int Test::GetK()
{
	return K;
}

int Test::GetWindowSize()
{
	return windowSize;
}

int Test::GetInFlow()
{
	return inFlow;
}

int Test::GetOutFlow()
{
	return outFlow;
}

int Test::GetQueryCycle()
{
	return queryCycle;
}

void Test::SetDimension(int d)
{
	dimension = d;
}

void Test::SetR(double r)
{
	R = r;
}

void Test::SetK(int k)
{
	K = k;
}


void Test::SetWindowSize(int w)
{
	windowSize = w;
}

void Test::SetInFlow(int in)
{
	inFlow = in;
}

void Test::SetOutFlow(int out)
{
	outFlow = out;
}

void Test::SetQueryCycle(int c)
{
	queryCycle = c;
}


void Test::Init(vector<Test>& vecTestFile, int j)
{
	FILE* fp;
	string a = to_string(j);
	string s = "test" + a + ".txt";
	fp = fopen(s.data(), "r");
	double n;
	int i = 0;
	Test test;
	while (fscanf(fp, "%lf", &n) != EOF)
	{
		if (i % 6 == 0)
		{
			test.SetDimension((int)n);
		}
		if (i % 6 == 1)
		{
			test.SetR(n);
		}
		if (i % 6 == 2)
		{
			test.SetK((int)n);
		}
		if (i % 6 == 3)
		{
			test.SetWindowSize((int)n);
		}
		if (i % 6 == 4)
		{
			test.SetInFlow((int)n);
		}
		if (i % 6 == 5)
		{
			test.SetQueryCycle((int)n);
		}
		i++;
		if (i % 6 == 0 && i != 0)
		{
			test.SetOutFlow(test.GetInFlow());
			vecTestFile.push_back(test);
		}
	}
}
