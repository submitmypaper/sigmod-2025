#pragma once
#include <vector>
#include <list>
#include <queue>
#include <map>
#include<unordered_map>
#include <cassert>
#include <math.h>
#include <algorithm>
#include "TStream.h"
#include "Test.h"
#include<stack>
#include <unordered_map>
#include<set>
#include <limits>
#include <fstream>
#include <sstream>
typedef vector<double> Data;
class MMCODFindOutlier {
public:
	struct DataObj {
		int id;
		int slideID;
		set<int>PreNei;
		set<int>LaterNei;
		list<int>Circle_R;
		list<int>Circle_32R;
		bool operator<(const DataObj& other) const {
			return id < other.id;
		}
		int getNN() {
			return LaterNei.size() + PreNei.size();
		}
	};
	struct CircleObj {
		int Cid = -1;
		vector<double>CenterCircle;
		CircleObj* parentNode = nullptr;
		int distoparent = 0;
		list<CircleObj*> childrenNode;
		double radius = 0; 
		int depth = 0;
		double maxRadius = 0;
		list<CircleObj*>NodeList;
		list<DataObj*>Datalist;
		void sortDatalist() {
			Datalist.sort([](const DataObj *a1, const DataObj *a2) {
				return (*a1).id < (*a2).id;
			});
		}
	};
	struct Slide1 {
		list<int> needDealCircleObj;
		list<DataObj*> needDealDataObj;
	};
	double calculateDistanceById(TStream& tstream, Test& test, int id1, int id2);
	double calculateDistanceBycoordinate(TStream& tstream, Test& test, int id, vector<double> data);
	double calculateDistanceBetweenTwoData(TStream& tstream, Test& test, Data data1, Data data2);
	vector<double> GetDataCoordinate(TStream& tstream, Test& test, int id);
	MMCODFindOutlier();
	~MMCODFindOutlier();
	void InitCircle(TStream& tstream, Test& test);
	void CreateCircle(TStream& tstream, Test& test);
	void PutDataInCircle(TStream& tstream, Test& test);
	void CheckPDFormCircle(TStream& tstream, Test& test);
	void splitmTree(TStream& tstream, Test& test);
	void InitRoot(TStream& tstream, Test& test, CircleObj* Root);
	void ChoosemTreeSubNode(TStream& tstream, Test& test, vector<double>& subTreecoordinate, CircleObj* node);
	void CreateNode(TStream& tstream, Test& test, vector<double>& subTreecoordinate, CircleObj* node, int id);
	void AddDataObjToChildNode(TStream& tstream, Test& test, CircleObj* node);
	void DealCirCle(TStream& tstream, Test& test);
	void findOutlier(TStream& tstream, Test& test);
	void FindNeiFrom23RCircle(TStream& tstream, Test& test, DataObj* data);
	void FindNeiFromPDList(TStream& tstream, Test& test, DataObj* data);
	void FindNeiFromNewDataList(TStream& tstream, Test& test, DataObj* data);
	void Update(TStream& tstream, Test& test);
	bool AddDataTomTreeNode(TStream& tstream, Test& test, DataObj* data, CircleObj* root);
	void DealATCircle(TStream& tstream, Test& test, Slide1& Expslide);
	void DealATPoint(TStream& tstream, Test& test, Slide1& Expslide);
	void DealNewData2(TStream& tstream, Test& test);
	void FormNewCircle(TStream& tstream, Test& test, DataObj* NewData);
	void NewCireAddToMTree(TStream& tstream, Test& test, CircleObj* NewCircle);
	CircleObj* createNewMiddleNode(TStream& tstream, Test& test, CircleObj* NewCircleParent, CircleObj* NewCircle);
	void Update32RCirecleList(TStream& tstream, Test& test, CircleObj* NewCircle);
	void Check32RFromMTree(TStream& tstream, Test& test, DataObj* data, CircleObj* root);
	void TestFormNewCircle(TStream& tstream, Test& test, DataObj* NewData);
	void ChangeRInit(TStream& tstream, Test& test);
	void ReInit(TStream& tstream, Test& test);
	void LowerBound(TStream& tstream, Test& test);
	void UpperBound(TStream& tstream, Test& test);
	void ChangeR(TStream& tstream, Test& test);
	void ChangeRCreateCircle(TStream& tstream, Test& test);
	void ChangeRPutDataInCircle(TStream& tstream, Test& test);
	double FindKNN(TStream& tstream, Test& test, DataObj* Outlier);
	double FindKNNForOutlier(TStream& tstream, Test& test, DataObj* Outlier);
	double FindKNNForOutlierLower(TStream& tstream, Test& test, DataObj* Outlier, set<DataObj*>& data);
	void calculateMemoryUsage(TStream& tstream, Test& test, const DataObj* node);
private:
	CircleObj* root;
	unordered_map<int, CircleObj*>CircleSet_12R;
	unordered_map<int, CircleObj*>NewDataInCircle;
	unordered_map<DataObj*, set<DataObj*>>distanceMap;
	list<DataObj*>PD;
	vector<Slide1>slideVec;
	set<DataObj*>OutlierSet;
	list<DataObj*>newDataObjList;
	bool BulitMtree = false;
	int SlideStart = 0;
	int slideNum;
	vector<int>VaryingWinStart;
	vector<int>VaryingWinEnd;
	vector<double>Varying_R;
	int Mtreetemp = 0;
	size_t totalMemoryUsage = 0;
	list<DataObj*>TempData;
	unordered_map<int, DataObj*>PointSet;
	unordered_map<int, int>WindowBegin;
};

