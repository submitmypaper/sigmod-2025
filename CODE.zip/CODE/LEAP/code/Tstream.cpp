#include "Tstream.h"
#include <vector>
#include <list>
#include <queue>
#include <map>
#include <set>
#include <cassert>
#include <math.h>
#include <algorithm>
#include "LEAP.h"
#include<stack>
#include<unordered_map>
#include <numeric> 
#include <string>
Tstream::Tstream()
{
}

Tstream::~Tstream()
{
}
void Tstream::readDataFile(Test& test, int j)
{
	FILE* fp1;
	double dlNumber;
	int dimension = test.getDimension();
	vector<double> minDimension(dimension, DBL_MAX);
	vector<double> maxDimension(dimension, 0.0);
	int i = 0;
	string a = to_string(j);
	string s = "SourceFile" + a + ".txt";
	if ((fp1 = fopen(s.data(), "r")) != NULL)
	{
		while (fscanf(fp1, "%lf", &dlNumber) != EOF)
		{
			vecDataStream.push_back(dlNumber);
		}
	}
	updateNeighborNum.resize(7340032, 0);
	setS_change(test);
}


double Tstream::getDataStream(int intObjectNumber)
{
	return vecDataStream[intObjectNumber];
}

vector<double> Tstream::getData(int dataId, int dimension) {
	vector<double> ans;
	for (int i = 0; i < dimension; ++i) {
		ans.push_back(vecDataStream[dimension * dataId + i]);
	}
	return ans;
}

int Tstream::getDataStreamLength()
{
	return vecDataStream.size();
}


int Tstream::getDataStreamBegin()
{
	return dataStreamBegin;
}

int Tstream::getDataStreamTag()
{
	return dataStreamTag;
}

void Tstream::setDataStreamBegin(int begin)
{
	dataStreamBegin = begin;
}

void Tstream::setDataStreamTag(int tag)
{
	dataStreamTag = tag;
}

void Tstream::Init(Test& test, int j)
{
	readDataFile(test, j);

	setDataStreamTag(0);
	setDataStreamBegin(0);
}

void Tstream::addDataStreamBegin(int outFlow)
{
	dataStreamBegin += outFlow;
}

void Tstream::addDataStreamTag(int inFlow)
{
	dataStreamTag += inFlow;
}

void Tstream::addUpdateNeighborNumById(Test& test, int id)
{
	if (updateNeighborNum[id] < (test.getK() + 1)) {
		updateNeighborNum[id]++;
	}
}

void Tstream::setUpdateNeighborNumById(int id, int num)
{
	updateNeighborNum[id] = num;
}

unsigned short Tstream::getUpdateNeighborNumById(int id)
{
	return updateNeighborNum[id];
}

int Tstream::getvecDataStreamNum(int dimension)
{
	return vecDataStream.size() / dimension;
}

void Tstream::resetupdateNeighborNum()
{
	for (int i = 0; i < updateNeighborNum.size(); ++i) {
		updateNeighborNum[i] = 0;
	}
}

void Tstream::setS_change(Test& test)
{
	FILE* fp = fopen("change_s.txt", "r");
	if (fp != NULL) {
		int tempS;
		while (fscanf(fp, "%d", &tempS) != EOF) {
			S_change.push_back(test.getInFlow());
		}
	}
}

int Tstream::getS_change(int idx)
{
	return S_change[idx];
}
