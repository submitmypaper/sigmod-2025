#pragma once
#include <map>
#include <cassert>
#include <math.h>
#include <algorithm>
#include "Tstream.h"
#include "Test.h"
#include<stack>
#include <unordered_map>
#include<set>
#include <queue>
typedef vector<double> Data;
class LEAP {
public:
	struct dataObj {
		int dataId;
		vector<int> vecSlideNeighbor;
		int dataidx;
		int vecNeighborNum = 0;
		int oldVecNeighborNum = 0;
		int dataObjSlide;
		bool dataState = false;
		int dataLastFindSlideNum;

		bool operator < (dataObj b) {
			return this->dataId < b.dataId;
		}
		bool operator > (dataObj b) {
			return this->dataId > b.dataId;
		}
		bool operator()(const dataObj d1, const dataObj d2) {
			return d1.dataId < d2.dataId;
		}
 	};
	struct Node {
		int nodeId;
		double radius;
		double maxRadius;
		double disToParent = 0;
		vector<double> coordinate;
		Node* parentNode = nullptr;
		list<Node*> childNodeList;
		list<int> dataObjList;
	};
	struct Slide {
		int slideId;
		Node* mtreeRoot = nullptr;
		list<dataObj> needDealDataObj;
		list<dataObj> outlierList;
	};
	LEAP();
	~LEAP();
	void setChildNodeSplitNum(int num);
	void setDataObjSplitNum(int num);
	void Init(Tstream& tstream, Test& test);
	double calculateDistanceById(Tstream& tstream, Test& test, int id1, int id2);
	double calculateDistanceBycoordinate(Tstream& tstream, Test& test, int id, Data data);
	double calculateDistanceBetweenTwoData(Tstream& tstream, Test& test, Data data1, Data data2);
	void addDataObjToSlide(Tstream& tstream, Test& test, Slide& slide);
	void splitmTree(Tstream& tstream, Test& test, Slide& slide, Node* node);
	void chooseSubInSurplusEntry(Tstream& tstream, Test& test, vector<double>& subTreecoordinate, int availableNodeNum, Node* node);
	void addNodeToVec(Tstream& tstream, Test& test, vector<double>& subTreecoordinate, int id1, int id2, int& availableNodeNum, double radius);
	bool chooseBestCoordinate(Tstream& tstream, Test& test, vector<double>& subTreecoordinate, vector<double>& temNode, double radius);
	void createNode(Tstream& tstream, Test& test, vector<double>& subTreecoordinate, Node* node, int id1);
	void addDataObjToChildNode(Tstream& tstream, Test& test, Node* node);
	void findOutlier(Tstream& tstream, Test& test);
	void findNeighborBySlide(Tstream& tstream, Test& test, Slide& slide, int curSlideId);
	void findInCurSlide(Tstream& tstream, Test& test, int dataId, int& sucNeighborNum, int slideId, bool& flag);
	void findInSucSlide(Tstream& tstream, Test& test, int dataId, int& sucNeighborNum, int slideId, bool& flag);
	void findInPreSlide(Tstream& tstream, Test& test, dataObj& data, int slideId, bool& flag);
	void dealDataObj(Tstream& tstream, Test& test, dataObj& data);
	int calNeighborNum(Tstream& tstream, Test& test, dataObj& data);
	void Update(Tstream& tstream, Test& test);
	void dealNewSlide(Tstream& tstream, Test& test);
	void updateFindNeighborForNewSlide(Tstream& tstream, Test& test, Slide& slide);
	void updateFindInPreSlide(Tstream& tstream, Test& test, dataObj& data, int slideId, bool& flag);
	void reDealOldSlide(Tstream& tstream, Test& test, Slide& slide);
	int calExpireSlideNum(Tstream& tstream, Test& test, dataObj& data);
	void updateDataObjVecSlideNeighbor(Tstream& tstream, Test& test, dataObj& data, int temNewNeighborNum);
	void reFindNeighborForDataObj(Tstream& tstream, Test& test, dataObj& data);
	int findIndex(Tstream& tstream, Test& test, int targetSlideId);
	void updateFindInSucSlide(Tstream& tstream, Test& test, int dataId, int& sucNeighborNum, int slideId, bool& flag, int targetNeighborNum);
	void findNeighborForOutlier(Tstream& tstream, Test& test, Slide& slide, int newObjId);
	void calculateMemoryUsage(Tstream& tstream, Test& test, const int num);
	void findNeiInWholeWindow(Tstream& tstream, Test& test, dataObj& data);

	bool cmp2(dataObj d1, dataObj d2) {
		return d1.dataId < d2.dataId;
	}
	void listUnique(list<dataObj>& L);

	void reInit(Tstream& ts, Test& t);
	double getNNR(Tstream& ts, Test& t, dataObj& data);
private:
	int nodeIdCount = 0;
	int slideIdCount = 0;
	int childNodeSplitNum = 0;
	int dataObjSplitNum = 0;
	vector<Slide> slideVec;
	int slideNum;
	size_t totalMemoryUsage = 0;

	unordered_map<int, int>PointSet;
	list<dataObj>outliers;
};