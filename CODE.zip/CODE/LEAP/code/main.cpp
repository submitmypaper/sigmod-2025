#include<stdio.h>
#include<iostream>
#include<fstream>
#include"LEAP.h"
#include"Test.h"
#include"Tstream.h"
#include <iomanip>
#include <ctime>
#include "string"
using namespace std;
void printlogmain(Tstream& tstream, Test& test, double time1, double time2) {

	ofstream data;
	data.clear();
	data.open("log_mainLEAP.txt", ofstream::app);
	if (data.is_open()) {
		data << endl;
		data << "WindowSize:" << test.getWindowSize() << endl;
		data << "K= " << test.getK() << "  " << "R= " << test.getR() << "  " << endl;
		data << "InitTime��" << time1 << "s" << endl;
		data << "RunningTime��" << time2 << "s" << endl;
		data.close();
	}
}
int main(int argc, char* argv[]) {
	int testnum = 0;
	int sfnum = 0;
	clock_t startTime, endTime ;
	double initTime;
	Test t;
	Tstream Tstream;
	vector<Test> vecTestFile;
	for (int i = 0; i < 7; i++) {
		t.Init(vecTestFile, i);
		Tstream.Init(vecTestFile[0], i);
		for (int j = 0; j < vecTestFile.size(); j++) {
			LEAP leap;
			leap.setChildNodeSplitNum(4);
			leap.setDataObjSplitNum(2);
			Tstream.setDataStreamBegin(0);
			startTime = clock();
			leap.Init(Tstream, vecTestFile[j]);
			endTime = clock();
			std::cout << std::fixed << std::setprecision(3);
			initTime = (double)(endTime - startTime) / CLOCKS_PER_SEC;
			cout << "Init Time = " << initTime << 's' << endl;
			startTime = clock();
			leap.Update(Tstream, vecTestFile[j]);
			endTime = clock();
			cout << "Running Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
			cout << "Process " << 1000000 / ((double)(endTime - startTime) / CLOCKS_PER_SEC) << " data per second " << endl;
			printlogmain(Tstream, vecTestFile[j], initTime, (double)(endTime - startTime) / CLOCKS_PER_SEC);
		}
	}
	return 0;

}