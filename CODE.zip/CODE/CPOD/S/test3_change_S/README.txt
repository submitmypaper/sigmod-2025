change_s0.txt corresponds to the 1st line of arguments in the test3.txt,
change_s1.txt  ->  2nd line of arguments in the test3.txt, etc. 
Note that when using 'change_s0.txt', it is necessary to rename it as ' change_s.txt' , change_s1_4.txt is also the same as above.