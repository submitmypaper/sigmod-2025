change_s0.txt corresponds to the 1st line of arguments in the test4.txt,
change_s1.txt  ->  2nd line of arguments in the test4.txt, etc. 