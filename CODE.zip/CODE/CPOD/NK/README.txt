change_s0.txt is applicable to all test data in test0.txt,
change_s1_4.txt applies to all test data from test1.txt to test5.txt,
Note that when using 'change_s0.txt', it is necessary to rename it as ' change_s.txt' , change_s1_4.txt is also the same as above.