#include<stdio.h>
#include<iostream>
#include<fstream>
#include"CPOD.h"
#include"Test.h"
#include"Tstream.h"
#include <ctime>
#include <iomanip>
#include "string"
void printlogmain(Tstream& Tstream, Test& test, double time2, double time3) {
	ofstream data;
	data.open("log_mainCPOD.txt", ofstream::app);
	data << "Window Size:" << test.getWindowSize() <<endl;
	data << "K :" << test.getK() << " " << "R :" << test.getR() << " " << endl;
	data << "InitTime��" << time2 << "s" << endl;
	data << "RunningTime��" << time3 << "s" << endl;
	data.close();
}
int main()
{
	clock_t startTime, endTime;
	double initTime;
	for (int j = 0; j < 6; j++) {
		Test t;
		Tstream Tstream;
		vector<Test> vecTestFile;
		t.Init(vecTestFile, j);
		Tstream.Init(vecTestFile[j], j);
		for (int i = 0; i < vecTestFile.size(); i++) {
			if (i != 0) {
				Tstream.resetupdateNeighborNum(); 
			}
			mTreeOfCorePoint mtreeOfCP;
			mtreeOfCP.setChildNodeSplitNum(16);
			mtreeOfCP.setDataObjSplitNum(8);
			Tstream.setDataStreamBegin(0);
			Tstream.setDataStreamTag(vecTestFile[i].getWindowSize() / vecTestFile[i].getDimension());
			startTime = clock();
			mtreeOfCP.Init(Tstream, vecTestFile[i]);
			endTime = clock();
			std::cout << std::fixed << std::setprecision(3);
			initTime = (double)(endTime - startTime) / CLOCKS_PER_SEC;
			cout << "Init Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << 's' << endl;
			startTime = clock();
			mtreeOfCP.Update(Tstream, vecTestFile[i]);
			endTime = clock();
			cout << "Running Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
			printlogmain(Tstream, vecTestFile[i], initTime, (double)(endTime - startTime) / CLOCKS_PER_SEC);
		}
	}
	return 0;
}