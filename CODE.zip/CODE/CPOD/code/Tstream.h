#pragma once
#include <vector>
#include <math.h>
#include"Test.h"
using namespace std;
class Tstream {
public:
	Tstream();
	~Tstream();

	void readDataFile(Test& test, int j);
	double getDataStream(int intObjectNumber);
	vector<double> getData(int dataId, int dimension);
	int getDataStreamLength();
	int getDataStreamBegin();
	int getDataStreamTag();
	vector<double> getCentralCoordinate();
	void setDataStreamBegin(int begin);
	void setDataStreamTag(int tag);
	void Init(Test& test, int j);
	void addDataStreamBegin(int outFlow);
	void addDataStreamTag(int inFlow);
	double getFirstRadius();
	void addPeakMemory(int addNum);
	int getPeakMemory();
	void setPeakMemory(int initNum);
	void addUpdateNeighborNumById(Test& test, int id);
	void setUpdateNeighborNumById(int id, int num);
	unsigned short getUpdateNeighborNumById(int id);
	void resetupdateNeighborNum();
	int getvecDataStreamNum(int dimension);
	void setS_change();
	int getS_change(int idx);
	void addChangeTimes();
	int getChangeTimes();
private:
	vector<double> vecDataStream;
	vector<unsigned short>	updateNeighborNum;
	int dataStreamBegin = 0;
	int dataStreamTag = 0;
	vector<double> centralCoordinate;
	double firstRadius = 0;
	int PeakMemory = 0;
	vector<int>S_change;
	int ChangeTimes = 0;
};